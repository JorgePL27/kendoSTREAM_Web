#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

echo "============================================"
echo "  Instalador de KendoSTREAM para Mac"
echo "============================================"
echo ""
echo "Carpeta del proyecto detectada:"
echo "  $PROJECT_DIR"
echo ""

cd "$PROJECT_DIR" || exit 1

if [ ! -d "node_modules" ]; then
  echo "Instalando dependencias del proyecto, esto puede tardar un minuto..."
  npm install
  if [ $? -ne 0 ]; then
    echo ""
    echo "ERROR: no se ha podido completar 'npm install'."
    echo "Consulta el manual, apartado 'Que hacer si npm install falla'."
    echo ""
    read -p "Pulsa Enter para salir..."
    exit 1
  fi
fi

# Limpieza de instalaciones anteriores: si una version previa dejo
# configurado un LaunchAgent de arranque automatico, lo quitamos.
if [ -f "$HOME/Library/LaunchAgents/com.kendostream.server.plist" ]; then
  launchctl unload "$HOME/Library/LaunchAgents/com.kendostream.server.plist" 2>/dev/null
  rm -f "$HOME/Library/LaunchAgents/com.kendostream.server.plist"
fi

echo "Creando el script de arranque manual..."
cat > "$SCRIPT_DIR/abrir-panel.command" << EOC
#!/bin/bash
cd "$PROJECT_DIR"
if ! lsof -i :3000 -sTCP:LISTEN -t >/dev/null 2>&1; then
  (npm start > "$PROJECT_DIR/data/servidor.log" 2>&1 &)
  sleep 3
fi
open http://localhost:3000/panel
EOC
chmod +x "$SCRIPT_DIR/abrir-panel.command"

echo "Creando el icono en el Escritorio..."
rm -f "$HOME/Desktop/Abrir Panel KendoSTREAM.command"
ln -s "$SCRIPT_DIR/abrir-panel.command" "$HOME/Desktop/Abrir Panel KendoSTREAM.command"

echo ""
echo "Instalacion completada."
echo ""
echo "IMPORTANTE: el servidor YA NO arranca solo al iniciar sesion."
echo "Cada vez que quieras usar KendoSTREAM, haz doble clic en el icono"
echo "'Abrir Panel KendoSTREAM' del Escritorio."
echo ""
echo "Probandolo ahora mismo..."
"$SCRIPT_DIR/abrir-panel.command"

echo ""
read -p "Pulsa Enter para cerrar..."
