// motor.test.js — pruebas de la Fase 1. Se ejecutan con:  node --test
// (desde la raíz del proyecto; no hace falta instalar nada)

const test = require("node:test");
const assert = require("node:assert/strict");
const { estadoInicial, aplicarAccion, normalizarEstado } = require("./motor");

// Aplica varias acciones seguidas
function aplicar(estado, ...acciones) {
  return acciones.reduce((e, a) => aplicarAccion(e, a), estado);
}
const punto = (lado, tecnica = "men") => ({ tipo: "PUNTO", lado, tecnica });
const hansoku = (lado) => ({ tipo: "HANSOKU", lado });
const puntos = (e, lado) => e.competidores[lado].puntos.length;

// ---------------------------------------------------------------- Deshacer

test("Deshacer quita solo el último punto", () => {
  let e = aplicar(estadoInicial(), punto("shiro", "men"), punto("aka", "kote"));
  e = aplicarAccion(e, { tipo: "DESHACER" });
  assert.equal(puntos(e, "shiro"), 1);
  assert.equal(puntos(e, "aka"), 0);
  assert.equal(e.combate.eventos.length, 1);
});

test("Deshacer no toca nombres, clubes, ronda ni ajustes", () => {
  let e = aplicar(estadoInicial(), punto("shiro"), punto("aka"));
  e = aplicar(
    e,
    { tipo: "EDITAR_COMPETIDOR", lado: "shiro", campo: "nombre", valor: "Ana" },
    { tipo: "EDITAR_COMPETIDOR", lado: "aka", campo: "club", valor: "Club B" },
    { tipo: "EDITAR_INFO_GENERAL", valor: "Semifinal 1" },
    { tipo: "CAMBIAR_IDIOMA", valor: "en" },
    { tipo: "DESHACER" }
  );
  assert.equal(puntos(e, "aka"), 0);
  assert.equal(e.competidores.shiro.nombre, "Ana");
  assert.equal(e.competidores.aka.club, "Club B");
  assert.equal(e.infoGeneral, "Semifinal 1");
  assert.equal(e.configuracion.idioma, "en");
});

test("Deshacer quita un hansoku suelto y baja el contador", () => {
  let e = aplicar(estadoInicial(), hansoku("shiro"));
  assert.equal(e.competidores.shiro.hansoku, 1);
  e = aplicarAccion(e, { tipo: "DESHACER" });
  assert.equal(e.competidores.shiro.hansoku, 0);
  assert.equal(e.combate.eventos.length, 0);
});

test("2.º hansoku: da punto al rival, registra dos eventos y deshacer restaura el contador", () => {
  let e = aplicar(estadoInicial(), hansoku("shiro"), hansoku("shiro"));
  assert.equal(e.competidores.shiro.hansoku, 0);
  assert.equal(puntos(e, "aka"), 1);
  assert.deepEqual(e.competidores.aka.puntos[0], { tipo: "ippon", origen: "hansoku" });
  assert.deepEqual(
    e.combate.eventos.map((x) => [x.lado, x.tipo, x.tecnica]),
    [
      ["shiro", "hansoku", undefined],
      ["shiro", "hansoku", undefined],
      ["aka", "punto", "hansoku"]
    ]
  );
  e = aplicarAccion(e, { tipo: "DESHACER" });
  assert.equal(puntos(e, "aka"), 0);
  assert.equal(e.competidores.shiro.hansoku, 1); // contador restaurado
  assert.equal(e.combate.eventos.length, 1); // queda solo el 1.er hansoku
  e = aplicarAccion(e, { tipo: "DESHACER" });
  assert.equal(e.competidores.shiro.hansoku, 0);
  assert.equal(e.combate.eventos.length, 0);
});

test("Deshacer sin eventos no hace nada ni falla", () => {
  const e = aplicarAccion(estadoInicial(), { tipo: "DESHACER" });
  assert.equal(e.combate.eventos.length, 0);
});

test("Los eventos llevan numeración, lado, tipo, técnica y encho", () => {
  const e = aplicar(estadoInicial(), punto("shiro", "men"), hansoku("aka"));
  assert.deepEqual(e.combate.eventos, [
    { n: 1, lado: "shiro", tipo: "punto", tecnica: "men", encho: false },
    { n: 2, lado: "aka", tipo: "hansoku", encho: false }
  ]);
});

// ---------------------------------------------------------------- Decidido

test("A 2 puntos queda decidido y no admite más puntos ni hansoku", () => {
  let e = aplicar(estadoInicial(), punto("shiro", "men"), punto("shiro", "do"));
  assert.equal(e.combate.estado, "decidido");
  const antes = JSON.stringify(e);
  e = aplicar(e, punto("aka"), punto("shiro"), hansoku("aka"), hansoku("shiro"));
  assert.equal(JSON.stringify(e), antes);
});

test("Un 2.º hansoku que da el 2.º punto deja el combate decidido", () => {
  let e = aplicar(estadoInicial(), punto("aka", "kote"), hansoku("shiro"), hansoku("shiro"));
  assert.equal(puntos(e, "aka"), 2);
  assert.equal(e.combate.estado, "decidido");
});

test("Deshacer devuelve un combate decidido a en_curso", () => {
  let e = aplicar(estadoInicial(), punto("shiro"), punto("shiro", "do"));
  e = aplicarAccion(e, { tipo: "DESHACER" });
  assert.equal(e.combate.estado, "en_curso");
});

// ---------------------------------------------------------------- Encho

test("El encho solo se activa con el marcador igualado", () => {
  let e = aplicar(estadoInicial(), punto("shiro"));
  e = aplicarAccion(e, { tipo: "TOGGLE_ENCHO" });
  assert.equal(e.encho, false);
  e = aplicar(e, punto("aka", "kote"), { tipo: "TOGGLE_ENCHO" });
  assert.equal(e.encho, true);
  e = aplicarAccion(e, { tipo: "TOGGLE_ENCHO" }); // se puede apagar
  assert.equal(e.encho, false);
});

test("En encho el primer punto decide y gana quien lo marca", () => {
  let e = aplicar(estadoInicial(), { tipo: "TOGGLE_ENCHO" }, punto("aka", "kote"));
  assert.equal(e.combate.estado, "decidido");
  assert.equal(e.combate.eventos[0].encho, true);
  e = aplicar(e, { tipo: "FINALIZAR_COMBATE" });
  assert.deepEqual(e.combate.resultado, { ganador: "aka", tipo: "encho", motivo: null });
  assert.equal(puntos(e, "shiro"), 0); // marcador real 0-1
});

test("Con el combate decidido en encho ya no se puede apagar el encho", () => {
  let e = aplicar(estadoInicial(), { tipo: "TOGGLE_ENCHO" }, punto("aka"));
  e = aplicarAccion(e, { tipo: "TOGGLE_ENCHO" });
  assert.equal(e.encho, true);
});

test("Si deshacer deja el marcador desigual con encho activo, el encho se apaga solo", () => {
  let e = aplicar(estadoInicial(), punto("shiro"), punto("aka", "kote"), { tipo: "TOGGLE_ENCHO" });
  assert.equal(e.encho, true);
  e = aplicarAccion(e, { tipo: "DESHACER" }); // marcador 1-0
  assert.equal(e.encho, false);
});

test("Deshacer el punto de encho vuelve a en_curso con el encho activo", () => {
  let e = aplicar(estadoInicial(), { tipo: "TOGGLE_ENCHO" }, punto("shiro"));
  e = aplicarAccion(e, { tipo: "DESHACER" });
  assert.equal(e.combate.estado, "en_curso");
  assert.equal(e.encho, true);
});

test("Un hansoku en encho se registra con encho=true y no decide", () => {
  const e = aplicar(estadoInicial(), { tipo: "TOGGLE_ENCHO" }, hansoku("shiro"));
  assert.equal(e.combate.eventos[0].encho, true);
  assert.equal(e.combate.estado, "en_curso");
});

// ---------------------------------------------------------------- Finalizar

test("Fin de tiempo con más puntos: gana ese competidor ('tiempo')", () => {
  const e = aplicar(estadoInicial(), punto("shiro"), { tipo: "FINALIZAR_COMBATE" });
  assert.deepEqual(e.combate.resultado, { ganador: "shiro", tipo: "puntos", motivo: "tiempo" });
  assert.equal(e.combate.estado, "finalizado");
});

test("Combate terminado a 2 puntos: 'dos_puntos'", () => {
  const e = aplicar(estadoInicial(), punto("aka"), punto("aka", "kote"), { tipo: "FINALIZAR_COMBATE" });
  assert.deepEqual(e.combate.resultado, { ganador: "aka", tipo: "puntos", motivo: "dos_puntos" });
});

test("Igualado y sin encho: empate (también 1-1 y 0-0)", () => {
  let e = aplicar(estadoInicial(), { tipo: "FINALIZAR_COMBATE" });
  assert.deepEqual(e.combate.resultado, { ganador: "empate", tipo: "empate", motivo: null });
  e = aplicar(estadoInicial(), punto("shiro"), punto("aka", "kote"), { tipo: "FINALIZAR_COMBATE" });
  assert.equal(e.combate.resultado.tipo, "empate");
});

test("Igualado con encho: sin decisión no se finaliza; pide Hantei", () => {
  let e = aplicar(estadoInicial(), punto("shiro"), punto("aka", "kote"), { tipo: "TOGGLE_ENCHO" });
  assert.equal(e.combate.requiereHantei, true);
  e = aplicarAccion(e, { tipo: "FINALIZAR_COMBATE" });
  assert.equal(e.combate.resultado, null);
  assert.equal(e.combate.estado, "en_curso");
});

test("Hantei fija ganador pero NO añade puntos", () => {
  let e = aplicar(
    estadoInicial(),
    punto("shiro"),
    punto("aka", "kote"),
    { tipo: "TOGGLE_ENCHO" },
    { tipo: "FINALIZAR_COMBATE", decision: "aka" }
  );
  assert.deepEqual(e.combate.resultado, { ganador: "aka", tipo: "hantei", motivo: null });
  assert.equal(puntos(e, "shiro"), 1);
  assert.equal(puntos(e, "aka"), 1);
});

test("Con encho activo también se puede elegir Empate", () => {
  const e = aplicar(estadoInicial(), { tipo: "TOGGLE_ENCHO" }, { tipo: "FINALIZAR_COMBATE", decision: "empate" });
  assert.deepEqual(e.combate.resultado, { ganador: "empate", tipo: "empate", motivo: null });
});

test("La decisión Hantei se ignora si no hace falta", () => {
  const e = aplicar(estadoInicial(), punto("shiro"), { tipo: "FINALIZAR_COMBATE", decision: "aka" });
  assert.equal(e.combate.resultado.ganador, "shiro");
});

test("Finalizar dos veces no cambia el resultado", () => {
  let e = aplicar(estadoInicial(), punto("shiro"), { tipo: "FINALIZAR_COMBATE" });
  const antes = JSON.stringify(e);
  e = aplicarAccion(e, { tipo: "FINALIZAR_COMBATE", decision: "aka" });
  assert.equal(JSON.stringify(e), antes);
});

// ---------------------------------------------------------------- Victoria técnica

test("Victoria técnica sin puntos: añade 2 puntos técnicos al ganador", () => {
  let e = aplicarAccion(estadoInicial(), { tipo: "VICTORIA_TECNICA", ganador: "aka", motivo: "lesion" });
  assert.equal(puntos(e, "aka"), 2);
  assert.ok(e.competidores.aka.puntos.every((p) => p.tipo === "tecnico"));
  assert.equal(e.combate.estado, "decidido");
  e = aplicarAccion(e, { tipo: "FINALIZAR_COMBATE" });
  assert.deepEqual(e.combate.resultado, { ganador: "aka", tipo: "tecnica", motivo: "lesion" });
});

test("Victoria técnica con 1 punto previo: añade solo 1 y conserva el punto real", () => {
  const e = aplicar(
    estadoInicial(),
    punto("shiro", "men"),
    punto("aka", "kote"),
    { tipo: "VICTORIA_TECNICA", ganador: "shiro", motivo: "incomparecencia" }
  );
  assert.deepEqual(
    e.competidores.shiro.puntos.map((p) => p.tipo),
    ["men", "tecnico"]
  );
  assert.equal(puntos(e, "aka"), 1);
  assert.deepEqual(
    e.combate.eventos.filter((x) => x.tecnica === "tecnico").length,
    1
  );
});

test("Victoria técnica: motivo o lado inválido se ignoran; no vale con el combate decidido", () => {
  let e = aplicarAccion(estadoInicial(), { tipo: "VICTORIA_TECNICA", ganador: "shiro", motivo: "inventado" });
  assert.equal(e.combate.eventos.length, 0);
  e = aplicarAccion(e, { tipo: "VICTORIA_TECNICA", ganador: "rojo", motivo: "otro" });
  assert.equal(e.combate.eventos.length, 0);
  e = aplicar(estadoInicial(), punto("shiro"), punto("shiro", "do"));
  e = aplicarAccion(e, { tipo: "VICTORIA_TECNICA", ganador: "aka", motivo: "otro" });
  assert.equal(puntos(e, "aka"), 0);
});

test("Deshacer una victoria técnica quita todos sus puntos y el motivo", () => {
  let e = aplicar(estadoInicial(), punto("aka", "kote"), { tipo: "VICTORIA_TECNICA", ganador: "shiro", motivo: "otro" });
  assert.equal(puntos(e, "shiro"), 2);
  e = aplicarAccion(e, { tipo: "DESHACER" });
  assert.equal(puntos(e, "shiro"), 0);
  assert.equal(puntos(e, "aka"), 1);
  assert.equal(e.combate.tecnica, null);
  assert.equal(e.combate.estado, "en_curso");
});

// ---------------------------------------------------------------- Reabrir y bloqueos

test("Reabrir deshace el resultado, desbloquea y conserva el id", () => {
  let e = aplicar(estadoInicial(), punto("shiro"), { tipo: "FINALIZAR_COMBATE" });
  const id = e.combate.id;
  e = aplicarAccion(e, { tipo: "REABRIR_COMBATE" });
  assert.equal(e.combate.resultado, null);
  assert.equal(e.combate.estado, "en_curso");
  assert.equal(e.combate.id, id);
  e = aplicar(e, punto("shiro", "do"), { tipo: "FINALIZAR_COMBATE" }); // vuelve a finalizar
  assert.equal(e.combate.id, id);
  assert.equal(e.combate.resultado.motivo, "dos_puntos");
});

test("Reabrir solo funciona con el combate finalizado", () => {
  const antes = aplicar(estadoInicial(), punto("shiro"));
  const despues = aplicarAccion(antes, { tipo: "REABRIR_COMBATE" });
  assert.equal(JSON.stringify(antes), JSON.stringify(despues));
});

test("Con el combate finalizado se bloquean datos, puntos, hansoku, deshacer y encho", () => {
  let e = aplicar(estadoInicial(), punto("shiro"), punto("aka", "kote"), { tipo: "FINALIZAR_COMBATE" });
  const antes = JSON.stringify(e);
  e = aplicar(
    e,
    { tipo: "EDITAR_COMPETIDOR", lado: "shiro", campo: "nombre", valor: "X" },
    { tipo: "EDITAR_INFO_GENERAL", valor: "X" },
    { tipo: "CAMBIAR_CATEGORIA", opcion: "femenino" },
    { tipo: "CAMBIAR_MODALIDAD", opcion: "equipos" },
    { tipo: "CAMBIAR_FOTO_COMPETIDOR", lado: "shiro", archivo: "x.png" },
    { tipo: "CAMBIAR_LOGO_CLUB", lado: "aka", archivo: "x.png" },
    { tipo: "INTERCAMBIAR_COMPETIDORES" },
    { tipo: "TOGGLE_ENCHO" },
    punto("shiro"),
    hansoku("aka"),
    { tipo: "DESHACER" }
  );
  assert.equal(JSON.stringify(e), antes);
});

test("Con el combate finalizado siguen funcionando los ajustes globales y los contadores de equipo", () => {
  let e = aplicar(estadoInicial(), { tipo: "FINALIZAR_COMBATE" });
  e = aplicar(
    e,
    { tipo: "CAMBIAR_IDIOMA", valor: "en" },
    { tipo: "EDITAR_EQUIPO", lado: "shiro", campo: "victorias", valor: 2 }
  );
  assert.equal(e.configuracion.idioma, "en");
  assert.equal(e.equipos.shiro.victorias, 2);
});

test("Intercambiar competidores solo vale sin eventos", () => {
  let e = aplicar(estadoInicial(), { tipo: "EDITAR_COMPETIDOR", lado: "shiro", campo: "nombre", valor: "Ana" });
  e = aplicarAccion(e, { tipo: "INTERCAMBIAR_COMPETIDORES" });
  assert.equal(e.competidores.aka.nombre, "Ana");
  e = aplicar(e, punto("shiro"), { tipo: "INTERCAMBIAR_COMPETIDORES" });
  assert.equal(e.competidores.aka.nombre, "Ana"); // no se intercambió
});

// ---------------------------------------------------------------- Reiniciar

test("Reiniciar crea un combate nuevo (id nuevo) y mantiene lo que debe", () => {
  let e = aplicar(
    estadoInicial(),
    { tipo: "EDITAR_NOMBRE_TORNEO", valor: "Aragón" },
    { tipo: "EDITAR_COMPETIDOR", lado: "shiro", campo: "nombre", valor: "Ana" },
    { tipo: "CAMBIAR_CATEGORIA", opcion: "femenino" },
    punto("shiro"),
    { tipo: "FINALIZAR_COMBATE" }
  );
  const idViejo = e.combate.id;
  const n = aplicarAccion(e, { tipo: "REINICIAR_COMBATE", mantenerCompetidores: true });
  assert.notEqual(n.combate.id, idViejo);
  assert.deepEqual(n.combate.eventos, []);
  assert.equal(n.combate.resultado, null);
  assert.equal(n.combate.estado, "en_curso");
  assert.equal(n.encho, false);
  assert.equal(n.competidores.shiro.nombre, "Ana");
  assert.equal(n.competidores.shiro.puntos.length, 0);
  assert.equal(n.evento.nombreTorneo, "Aragón");
  assert.equal(n.categoria.opcion, "femenino");
  const m = aplicarAccion(e, { tipo: "REINICIAR_COMBATE", mantenerCompetidores: false });
  assert.equal(m.competidores.shiro.nombre, "");
});

// ---------------------------------------------------------------- Robustez y persistencia

test("aplicarAccion no modifica el estado original", () => {
  const original = aplicar(estadoInicial(), punto("shiro"));
  const copia = JSON.stringify(original);
  aplicar(original, punto("aka"), hansoku("shiro"), { tipo: "FINALIZAR_COMBATE" });
  assert.equal(JSON.stringify(original), copia);
});

test("Acciones inválidas o desconocidas no fallan ni cambian nada", () => {
  const e = estadoInicial();
  const antes = JSON.stringify(e);
  const basura = [
    null,
    undefined,
    {},
    { tipo: 5 },
    { tipo: "NO_EXISTE" },
    { tipo: "PUNTO", lado: "verde", tecnica: "men" },
    { tipo: "PUNTO", lado: "shiro", tecnica: "patada" },
    { tipo: "HANSOKU" },
    { tipo: "EDITAR_COMPETIDOR", lado: "shiro", campo: "puntos", valor: 5 },
    { tipo: "EDITAR_COMPETIDOR", campo: "nombre", valor: "x" }
  ];
  basura.forEach((a) => assert.equal(JSON.stringify(aplicarAccion(e, a)), antes));
});

test("El estado sobrevive a guardarse y leerse (el registro de eventos incluido)", () => {
  let e = aplicar(estadoInicial(), punto("shiro", "men"), hansoku("aka"), hansoku("aka"));
  const leido = normalizarEstado(JSON.parse(JSON.stringify(e)));
  assert.deepEqual(leido, e);
  const despues = aplicarAccion(leido, { tipo: "DESHACER" });
  assert.equal(despues.competidores.aka.hansoku, 1);
  assert.equal(puntos(despues, "shiro"), 1);
});

// ---------------------------------------------------------------- Estados antiguos

test("Un estado.json antiguo (sin 'combate') arranca sin errores", () => {
  const antiguo = {
    version: 1,
    evento: { nombreTorneo: "Torneo viejo", logo: "" },
    infoGeneral: "Final",
    encho: false,
    modoEquipos: false,
    categoria: { opcion: "masculino", textoPersonalizado: "" },
    modalidad: { opcion: "individual", textoPersonalizado: "" },
    configuracion: { disenoMarcador: "clasico", marcaAguaVisible: false, idioma: "es" }, // sin modoCampeonatoImportante
    equipos: {
      shiro: { nombre: "", victorias: 0, empates: 0, ippones: 0 },
      aka: { nombre: "", victorias: 0, empates: 0, ippones: 0 }
    },
    competidores: {
      shiro: { nombre: "Ana", club: "A", puntos: [{ tipo: "men", origen: "tecnica" }], hansoku: 1 }, // sin foto/logo
      aka: { nombre: "Bea", club: "B", puntos: [{ tipo: "ippon", origen: "hansoku" }], hansoku: 0, foto: "", logoClub: "" }
    }
  };
  const e = normalizarEstado(antiguo);
  assert.equal(e.version, 2);
  assert.equal(e.evento.nombreTorneo, "Torneo viejo");
  assert.equal(e.competidores.shiro.foto, "");
  assert.equal(e.configuracion.modoCampeonatoImportante, false);
  assert.ok(e.combate.id);
  assert.equal(e.combate.estado, "en_curso");
  // se reconstruyen eventos a partir de lo que había
  assert.equal(e.combate.eventos.length, 3);
  assert.deepEqual(
    e.combate.eventos.map((x) => x.n),
    [1, 2, 3]
  );
  // y el motor sigue funcionando sobre él
  const f = aplicar(e, punto("shiro", "do"), { tipo: "DESHACER" });
  assert.equal(f.combate.eventos.length, 3); // vuelve a lo reconstruido
  // deshacer el punto automático por hansoku restaura el contador del infractor
  const g = aplicarAccion(f, { tipo: "DESHACER" });
  assert.equal(puntos(g, "aka"), 0);
  assert.equal(g.competidores.shiro.hansoku, 1);
});

test("Un estado antiguo con 2 puntos arranca como decidido", () => {
  const e = estadoInicial();
  e.competidores.aka.puntos = [
    { tipo: "men", origen: "tecnica" },
    { tipo: "do", origen: "tecnica" }
  ];
  delete e.combate;
  assert.equal(normalizarEstado(e).combate.estado, "decidido");
});

test("normalizarEstado rechaza lo que no es un estado", () => {
  assert.equal(normalizarEstado(null), null);
  assert.equal(normalizarEstado("hola"), null);
  assert.equal(normalizarEstado([1, 2]), null);
});

test("normalizarEstado es idempotente", () => {
  const e = aplicar(estadoInicial(), punto("shiro"), hansoku("aka"));
  assert.deepEqual(normalizarEstado(normalizarEstado(e)), e);
});
