// i18n.js — diccionario de traducciones de la INTERFAZ DEL PANEL.
// KendoSTREAM — © 2026 Jorge Pascual Lansac. Distribuido bajo PolyForm
// Noncommercial License 1.0.0 — ver LICENSE.txt en la raíz del proyecto.
//
// Importante: esto traduce el panel del operador únicamente. El overlay
// (lo que ve el público) NO se traduce — los datos que muestra los escribe
// el propio operador en el idioma que quiera, así que no hace falta.

const TRADUCCIONES = {
  es: {
    config_enlace: "Configuración ⚙",
    torneo_placeholder: "Campeonato Nacional 2026",
    info_general_placeholder: "Final — Combate 12",
    torneo_label: "Torneo / evento",
    info_general_label: "Información general (ronda, combate, pool…)",
    modo_equipos: "Modo equipos",
    marca_agua: "Mostrar marca de agua",
    encho: "Encho / Prórroga",
    categoria_label: "Categoría",
    modalidad_label: "Modalidad",
    categoria_texto_placeholder: "Escribe la categoría",
    modalidad_texto_placeholder: "Escribe la modalidad",
    cat_masculino: "Masculino",
    cat_femenino: "Femenino",
    cat_junior: "Junior",
    cat_otro: "Otro (texto libre)",
    mod_individual: "Individual",
    mod_equipos: "Equipos",
    mod_otro: "Otro (texto libre)",
    equipo_blanco_titulo: "Equipo Blanco",
    equipo_rojo_titulo: "Equipo Rojo",
    equipo_nombre_placeholder: "Nombre del equipo",
    victorias: "Victorias",
    empates: "Empates",
    ippones: "Ippones",
    blanco_titulo: "Blanco",
    rojo_titulo: "Rojo",
    nombre_placeholder: "Nombre",
    club_placeholder: "Club / selección",
    foto_label: "Foto",
    foto_sin: "— Sin foto —",
    logo_label: "Logo del club",
    logo_sin: "— Sin logo —",
    hansoku_boton: "Hansoku",
    deshacer: "Deshacer",
    intercambiar: "Intercambiar competidores",
    reiniciar_mismos: "Reiniciar (mismos competidores)",
    reiniciar_todo: "Reiniciar combate completo",
    confirmar_intercambiar: "¿Intercambiar Blanco y Rojo?",
    confirmar_reiniciar_mismos: "¿Reiniciar el combate manteniendo los competidores actuales?",
    confirmar_reiniciar_todo: "¿Reiniciar el combate por completo, borrando también los competidores?",
    conectado: "conectado",
    sin_conexion: "sin conexión — reintentando…",
    conectando: "conectando…",
    diseno_marcador: "Diseño del marcador",
    diseno_ayuda: "Elige el aspecto visual del overlay. El desplegable detecta automáticamente los diseños disponibles en la carpeta del proyecto.",
    torneo_mode: "Modo Campeonato",
    torneo_ayuda: "Activa categoría/modalidad en la parte superior del overlay, y las fotos/logos de club por competidor. Se combina con cualquiera de los diseños anteriores.",
    activar: "Activar",
    marca_agua: "Marca de agua",
    marca_ayuda: " Se activa o desactiva desde el propio panel del operador (para poder encenderla/apagarla rápido durante la retransmisión), no desde aquí.",
    panel_idioma: "Idioma del panel",
    idioma_ayuda: "Cambia el idioma de la interfaz del panel de control (botones, campos, mensajes). El overlay que ve el público no se traduce — los datos que muestra los escribe el propio operador.",
    espanol: "Español",
    english: "Inglés"
  },
  en: {
    config_enlace: "Settings ⚙",
    torneo_placeholder: "National Championship 2026",
    info_general_placeholder: "Final — Match 12",
    torneo_label: "Tournament / event",
    info_general_label: "General info (round, match, pool…)",
    modo_equipos: "Team mode",
    marca_agua: "Show watermark",
    encho: "Encho / Overtime",
    categoria_label: "Category",
    modalidad_label: "Format",
    categoria_texto_placeholder: "Type the category",
    modalidad_texto_placeholder: "Type the format",
    cat_masculino: "Men",
    cat_femenino: "Women",
    cat_junior: "Junior",
    cat_otro: "Other (free text)",
    mod_individual: "Single",
    mod_equipos: "Team",
    mod_otro: "Other (free text)",
    equipo_blanco_titulo: "White Team",
    equipo_rojo_titulo: "Red Team",
    equipo_nombre_placeholder: "Team name",
    victorias: "Wins",
    empates: "Draws",
    ippones: "Ippons",
    blanco_titulo: "White",
    rojo_titulo: "Red",
    nombre_placeholder: "Name",
    club_placeholder: "Club / selection",
    foto_label: "Photo",
    foto_sin: "— No photo —",
    logo_label: "Club logo",
    logo_sin: "— No logo —",
    hansoku_boton: "Hansoku",
    deshacer: "Undo",
    intercambiar: "Swap competitors",
    reiniciar_mismos: "Reset (same competitors)",
    reiniciar_todo: "Full match reset",
    confirmar_intercambiar: "Swap White and Red?",
    confirmar_reiniciar_mismos: "Reset the match keeping the current competitors?",
    confirmar_reiniciar_todo: "Reset the match completely, also clearing the competitors?",
    conectado: "connected",
    sin_conexion: "disconnected — retrying…",
    conectando: "connecting…",
    diseno_marcador: "Scoreboard Design",
    diseno_ayuda: "Choose the overlays visuals. The dropdown detects the available designs in the project folder automatically",
    torneo_mode: "Championship Mode",
    torneo_ayuda: "Activates category/mode on the overlays upper section, and the competitors/club photos/flags. It can be combined with both designs",
    activar: "Activate",
    marca_agua: "Watermark",
    marca_ayuda: "It can be activated or deactivated from the main panel",
    panel_idioma: "Panel Language",
    idioma_ayuda: "Changes the panels language (buttons, fields, messages). The overlay seen by the public is not translated — the operator fills this info manually",
    espanol: "Spanish",
    english: "English"
  }
};

// Aplica el idioma dado a todos los elementos marcados con data-i18n /
// data-i18n-placeholder. Los <select> con data-i18n-opciones reciben sus
// <option> reescritos a partir de la lista de claves indicada, conservando
// siempre el value original (el dato guardado nunca cambia, solo su rótulo).
function aplicarIdioma(idioma) {
  const t = TRADUCCIONES[idioma] || TRADUCCIONES.es;

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const clave = el.getAttribute("data-i18n");
    if (t[clave] !== undefined) el.textContent = t[clave];
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const clave = el.getAttribute("data-i18n-placeholder");
    if (t[clave] !== undefined) el.placeholder = t[clave];
  });

  document.querySelectorAll("[data-i18n-opciones]").forEach((select) => {
    const claves = select.getAttribute("data-i18n-opciones").split(",");
    Array.from(select.options).forEach((opcion, i) => {
      const clave = claves[i];
      if (clave && t[clave] !== undefined) opcion.textContent = t[clave];
    });
  });

  document.documentElement.lang = idioma;
}
