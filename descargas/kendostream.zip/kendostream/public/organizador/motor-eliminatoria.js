// motor-eliminatoria.js
// KendoSTREAM — Organizador de torneos
// Lógica pura de generación del cuadro de eliminatoria directa.
// Sin dependencias de red ni de interfaz: recibe una lista de competidores
// y devuelve la estructura del cuadro completo.

/**
 * Genera el orden de siembra estándar para un cuadro de "tamano" plazas
 * (tamano debe ser potencia de 2). Es el algoritmo clásico de torneos:
 * garantiza que la semilla 1 y la semilla 2 solo puedan encontrarse en la
 * final, las semillas 1-4 solo en semifinales, etc.
 *
 * generarOrdenSiembra(8) → [1, 8, 4, 5, 2, 7, 3, 6]
 * Esto se lee como: la plaza 1 del cuadro es para la semilla 1, la plaza 2
 * para la semilla 8, la plaza 3 para la semilla 4, etc. Los combates de la
 * primera ronda son (plaza1 vs plaza2), (plaza3 vs plaza4)...
 */
function generarOrdenSiembra(tamano) {
  if (tamano === 1) return [1];
  const anterior = generarOrdenSiembra(tamano / 2);
  const resultado = [];
  anterior.forEach((semilla) => {
    resultado.push(semilla);
    resultado.push(tamano + 1 - semilla);
  });
  return resultado;
}

function siguientePotenciaDeDos(n) {
  let p = 1;
  while (p < n) p *= 2;
  return p;
}

/**
 * Cuenta cuántos combates de primera ronda enfrentan a dos competidores
 * reales (no BYE) del mismo club, dada una asignación completa de plazas.
 */
function contarChoquesDeClub(plazas) {
  let choques = 0;
  for (let i = 0; i < plazas.length; i += 2) {
    const a = plazas[i];
    const b = plazas[i + 1];
    if (a && b && a.club && b.club && a.club.trim().toLowerCase() === b.club.trim().toLowerCase()) {
      choques++;
    }
  }
  return choques;
}

function mezclar(array) {
  const copia = array.slice();
  for (let i = copia.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copia[i], copia[j]] = [copia[j], copia[i]];
  }
  return copia;
}

/**
 * Genera el cuadro completo de eliminatoria directa.
 *
 * @param {Array} competidores - [{ id, nombre, club, dan, cabezaDeSerie }]
 * @param {Object} opciones - { intentosAntiChoque: number }
 * @returns {Object} { tamanoCuadro, numByes, rondas }
 *   rondas: [{ nombre, combates: [{ id, posicion, compA, compB, ganadorId }] }]
 *   compA/compB pueden ser un competidor, o null si es un BYE.
 */
function generarEliminatoria(competidores, opciones = {}) {
  const intentosAntiChoque = opciones.intentosAntiChoque || 300;
  const n = competidores.length;
  if (n < 2) {
    throw new Error("Hacen falta al menos 2 competidores para generar un cuadro.");
  }

  const tamanoCuadro = siguientePotenciaDeDos(n);
  const numByes = tamanoCuadro - n;
  const ordenSiembra = generarOrdenSiembra(tamanoCuadro); // posición → nº de semilla

  const cabezasDeSerie = competidores.filter((c) => c.cabezaDeSerie);
  const resto = competidores.filter((c) => !c.cabezaDeSerie);

  // Los BYES se reparten prioritariamente entre las cabezas de serie (si las
  // hay); si sobran BYES sin cabezas de serie a las que asignar, se dan a
  // los primeros competidores del "resto" en el orden de la lista — el
  // organizador puede reordenar su lista si quiere controlar quién los recibe.
  const cantidadByesParaSemillas = Math.min(numByes, cabezasDeSerie.length);
  let byesRestantes = numByes - cantidadByesParaSemillas;
  const competidoresConByeExtra = byesRestantes > 0 ? resto.slice(0, byesRestantes) : [];
  const restoSinByeExtra = resto.slice(competidoresConByeExtra.length);

  // Mapa de nº de semilla → competidor. Semillas 1..cabezasDeSerie.length
  // son las cabezas de serie, en el orden en que se introdujeron.
  const semillaACompetidor = new Array(tamanoCuadro + 1).fill(undefined);
  cabezasDeSerie.forEach((c, i) => { semillaACompetidor[i + 1] = c; });

  const posicionDeSemilla = new Array(tamanoCuadro + 1);
  ordenSiembra.forEach((semilla, posicion) => { posicionDeSemilla[semilla] = posicion; });

  function posicionParejaEnRonda1(posicion) {
    return posicion % 2 === 0 ? posicion + 1 : posicion - 1;
  }

  // Semillas ya "ocupadas" en este momento (por una cabeza de serie), para
  // saber cuáles siguen disponibles al repartir byes extra y competidores normales.
  const semillasOcupadas = new Set();
  for (let s = 1; s <= cabezasDeSerie.length; s++) semillasOcupadas.add(s);

  const semillasConByeReal = new Set(); // semillas que quedan vacías (BYE)

  // 1) Byes de las cabezas de serie: la semilla que les hace pareja en la
  // 1ª ronda queda vacía.
  cabezasDeSerie.slice(0, cantidadByesParaSemillas).forEach((c, i) => {
    const semillaCabeza = i + 1;
    const posPareja = posicionParejaEnRonda1(posicionDeSemilla[semillaCabeza]);
    const semillaPareja = ordenSiembra[posPareja];
    semillasConByeReal.add(semillaPareja);
    semillasOcupadas.add(semillaPareja);
  });

  // 2) Byes "extra" (sin cabezas de serie suficientes): a cada competidor
  // del resto que recibe uno, se le busca una semilla libre cualquiera, y
  // se marca como vacía la semilla que le haría pareja en la 1ª ronda —
  // exactamente el paso que faltaba antes y causaba el error.
  competidoresConByeExtra.forEach((competidor) => {
    let semillaElegida = null;
    for (let s = 1; s <= tamanoCuadro; s++) {
      if (!semillasOcupadas.has(s)) { semillaElegida = s; break; }
    }
    semillaACompetidor[semillaElegida] = competidor;
    semillasOcupadas.add(semillaElegida);
    const posPareja = posicionParejaEnRonda1(posicionDeSemilla[semillaElegida]);
    const semillaPareja = ordenSiembra[posPareja];
    semillasConByeReal.add(semillaPareja);
    semillasOcupadas.add(semillaPareja);
  });

  // Semillas aún libres, para el resto de competidores normales (sin bye):
  const semillasLibres = [];
  for (let s = 1; s <= tamanoCuadro; s++) {
    if (!semillasOcupadas.has(s)) semillasLibres.push(s);
  }
  const competidoresLibres = restoSinByeExtra.slice();

  if (semillasLibres.length !== competidoresLibres.length) {
    throw new Error("Error interno cuadrando semillas libres con competidores libres — revisa el cálculo de byes.");
  }

  // Probamos varias asignaciones aleatorias de competidoresLibres a
  // semillasLibres, y nos quedamos con la que menos choques de mismo club
  // produce en la primera ronda (mejor esfuerzo, no garantiza cero choques).
  let mejorAsignacion = null;
  let mejorPuntuacion = Infinity;

  for (let intento = 0; intento < intentosAntiChoque; intento++) {
    const orden = mezclar(competidoresLibres);
    const pruebaSemillaACompetidor = semillaACompetidor.slice();
    semillasLibres.forEach((semilla, i) => { pruebaSemillaACompetidor[semilla] = orden[i]; });

    const plazas = ordenSiembra.map((semilla) => {
      if (semillasConByeReal.has(semilla)) return null; // BYE
      return pruebaSemillaACompetidor[semilla] || null;
    });

    const puntuacion = contarChoquesDeClub(plazas);
    if (puntuacion < mejorPuntuacion) {
      mejorPuntuacion = puntuacion;
      mejorAsignacion = pruebaSemillaACompetidor;
    }
    if (mejorPuntuacion === 0) break; // no se puede mejorar más
  }

  const plazasFinal = ordenSiembra.map((semilla) => {
    if (semillasConByeReal.has(semilla)) return null;
    return mejorAsignacion[semilla] || null;
  });

  // --- Construcción de todas las rondas del cuadro ---
  const nombresRonda = calcularNombresRondas(tamanoCuadro);
  const rondas = [];
  let idContador = 1;

  // Ronda 1, con los emparejamientos ya resueltos (incluye BYEs)
  const combatesRonda1 = [];
  for (let i = 0; i < plazasFinal.length; i += 2) {
    const compA = plazasFinal[i];
    const compB = plazasFinal[i + 1];
    let ganadorId = null;
    // Si uno de los dos es BYE, el otro pasa automáticamente.
    if (compA && !compB) ganadorId = compA.id;
    if (compB && !compA) ganadorId = compB.id;
    combatesRonda1.push({
      id: idContador++,
      posicion: i / 2,
      compA: compA ? { id: compA.id, nombre: compA.nombre, club: compA.club } : null,
      compB: compB ? { id: compB.id, nombre: compB.nombre, club: compB.club } : null,
      ganadorId
    });
  }
  rondas.push({ nombre: nombresRonda[0], combates: combatesRonda1 });

  // Rondas siguientes: vacías, a la espera de resultados. El número de
  // combates de cada ronda es la mitad de la anterior.
  let numCombatesRondaAnterior = combatesRonda1.length;
  for (let r = 1; r < nombresRonda.length; r++) {
    const numCombates = numCombatesRondaAnterior / 2;
    const combates = [];
    for (let i = 0; i < numCombates; i++) {
      combates.push({ id: idContador++, posicion: i, compA: null, compB: null, ganadorId: null });
    }
    rondas.push({ nombre: nombresRonda[r], combates });
    numCombatesRondaAnterior = numCombates;
  }

  // Propagamos automáticamente los BYEs de la ronda 1 a la ronda 2 (un BYE
  // hace que el ganador ya se conozca sin jugar, así que su rival de ronda 2
  // ya puede mostrarse en cuanto generamos el cuadro).
  propagarGanadores(rondas);

  return { tamanoCuadro, numByes, choquesDeClubRonda1: mejorPuntuacion, rondas };
}

function calcularNombresRondas(tamanoCuadro) {
  const nombresConocidos = { 2: ["Final"], 4: ["Semifinales", "Final"], 8: ["Cuartos de final", "Semifinales", "Final"] };
  if (nombresConocidos[tamanoCuadro]) return nombresConocidos[tamanoCuadro];
  const nombres = [];
  let tamano = tamanoCuadro;
  while (tamano > 8) {
    nombres.push(`Ronda de ${tamano}`);
    tamano /= 2;
  }
  nombres.push("Cuartos de final", "Semifinales", "Final");
  return nombres;
}

/**
 * Recorre las rondas y, cuando un combate ya tiene ganador (por ejemplo, un
 * BYE recién generado, o un resultado que el organizador acaba de marcar),
 * coloca a ese ganador en el hueco que le corresponde en la ronda siguiente.
 */
function propagarGanadores(rondas) {
  for (let r = 0; r < rondas.length - 1; r++) {
    const rondaActual = rondas[r];
    const rondaSiguiente = rondas[r + 1];
    rondaActual.combates.forEach((combate) => {
      if (!combate.ganadorId) return;
      const ganador = combate.compA && combate.compA.id === combate.ganadorId ? combate.compA : combate.compB;
      const combateSiguiente = rondaSiguiente.combates[Math.floor(combate.posicion / 2)];
      const esSlotA = combate.posicion % 2 === 0;
      if (esSlotA) combateSiguiente.compA = ganador;
      else combateSiguiente.compB = ganador;
    });
  }
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { generarEliminatoria, generarOrdenSiembra, propagarGanadores, siguientePotenciaDeDos };
}
