// motor.js
// KendoSTREAM — © 2026 Jorge Pascual Lansac. Distribuido bajo PolyForm
// Noncommercial License 1.0.0 — ver LICENSE.txt en la raíz del proyecto.
//
// Lógica pura del combate. No sabe nada de red, WebSockets ni ficheros:
// solo recibe un estado y una acción, y devuelve el nuevo estado.
// Esto hace que sea fácil de testear y de razonar sobre ella.

const crypto = require("crypto");

const LADOS = ["shiro", "aka"];
const TECNICAS = ["men", "kote", "do", "tsuki"];
const MOTIVOS_TECNICOS = ["incomparecencia", "lesion", "descalificacion", "otro"];
const PUNTOS_PARA_GANAR = 2;

function estadoInicial() {
  return {
    version: 2,
    evento: {
      nombreTorneo: "",
      logo: ""
    },
    infoGeneral: "", // ronda del combate (en el registro se guarda como "ronda")
    encho: false, // true cuando el combate está en Encho / Prórroga
    modoEquipos: false,
    categoria: { opcion: "masculino", textoPersonalizado: "" }, // opcion: 'masculino'|'femenino'|'junior'|'otro'
    modalidad: { opcion: "individual", textoPersonalizado: "" }, // opcion: 'individual'|'equipos'|'otro'
    configuracion: {
      disenoMarcador: "clasico", // identificador del diseño de overlay activo
      marcaAguaVisible: false,
      modoCampeonatoImportante: false, // activa categoría/modalidad arriba, fotos y logos de club
      idioma: "es" // idioma de la INTERFAZ DEL PANEL únicamente ('es'|'en'); el overlay no se traduce
    },
    equipos: {
      shiro: { nombre: "", victorias: 0, empates: 0, ippones: 0 },
      aka: { nombre: "", victorias: 0, empates: 0, ippones: 0 }
    },
    competidores: {
      shiro: crearCompetidorVacio(),
      aka: crearCompetidorVacio()
    },
    combate: crearCombateNuevo(),
    // Encuentro por equipos en curso (Fase 5). null = combates sueltos, contadores de equipo a mano.
    // { id, integrantes: 3|5, eliminatoria, estado: 'en_curso'|'pendiente_desempate'|'finalizado',
    //   combates: [{ id, posicion, desempate, ganador, tipo, motivo, nombres:{shiro,aka}, ippones:{shiro,aka} }],
    //   resultado: {ganador, motivo}|null }
    encuentro: null
  };
}

function crearCompetidorVacio() {
  return {
    nombre: "",
    club: "",
    // { tipo: 'men'|'kote'|'do'|'tsuki', origen: 'tecnica' }
    // { tipo: 'ippon',   origen: 'hansoku' }   (punto por el 2.º hansoku del rival)
    // { tipo: 'tecnico', origen: 'tecnico' }   (punto de victoria técnica)
    puntos: [],
    hansoku: 0,
    foto: "", // nombre de archivo dentro de public/fotos-competidores/
    logoClub: "" // nombre de archivo dentro de public/logos-clubes/
  };
}

// Datos propios del combate en curso. Todo lo que está aquí viaja dentro del
// estado, así que sobrevive a un reinicio del servidor (data/estado.json).
function crearCombateNuevo() {
  return {
    id: crypto.randomUUID(),
    pista: 1, // de momento un solo shiaijo
    estado: "en_curso", // 'en_curso' | 'decidido' | 'finalizado' (se recalcula tras cada acción)
    requiereHantei: false, // true si "Fin de tiempo" debe preguntar Hantei Blanco / Rojo / Empate
    eventos: [], // { n, lado, tipo:'punto'|'hansoku', tecnica?, encho }
    tecnica: null, // { ganador, motivo } si se concedió una victoria técnica
    resultado: null, // { ganador, tipo, motivo } cuando el operador finaliza el combate
    encuentro: null // { id, posicion, desempate } si el combate forma parte de un encuentro por equipos
  };
}

// ---------------------------------------------------------------------------
// Utilidades
// ---------------------------------------------------------------------------

function otroLado(lado) {
  return lado === "shiro" ? "aka" : "shiro";
}

function ladoValido(lado) {
  return LADOS.includes(lado);
}

function puntosDe(estado, lado) {
  return estado.competidores[lado].puntos.length;
}

function marcadorIgualado(estado) {
  return puntosDe(estado, "shiro") === puntosDe(estado, "aka");
}

function hayPuntoEnEncho(estado) {
  return estado.combate.eventos.some((e) => e.tipo === "punto" && e.encho === true);
}

// Un combate queda decidido cuando alguien llega a 2 puntos o cuando se marca
// un punto en encho (el primero decide). Se calcula, no se guarda aparte.
function combateDecidido(estado) {
  return (
    puntosDe(estado, "shiro") >= PUNTOS_PARA_GANAR ||
    puntosDe(estado, "aka") >= PUNTOS_PARA_GANAR ||
    hayPuntoEnEncho(estado)
  );
}

function combateFinalizado(estado) {
  return estado.combate.resultado !== null;
}

// No se pueden anotar puntos ni hansoku si está decidido o finalizado.
function combateBloqueado(estado) {
  return combateFinalizado(estado) || combateDecidido(estado);
}

// clona profundamente el estado (evita mutaciones accidentales compartidas)
function clonar(estado) {
  return JSON.parse(JSON.stringify(estado));
}

function crearEvento(n, lado, tipo, tecnica, encho) {
  const evento = { n, lado, tipo };
  if (tipo === "punto") evento.tecnica = tecnica;
  evento.encho = encho === true;
  return evento;
}

function registrarEvento(estado, lado, tipo, tecnica) {
  const eventos = estado.combate.eventos;
  eventos.push(crearEvento(eventos.length + 1, lado, tipo, tecnica, estado.encho));
}

// Anota un punto: lo añade al competidor (lo que ve el overlay) y al registro de eventos.
// tecnica: 'men'|'kote'|'do'|'tsuki' | 'hansoku' (automático) | 'tecnico' (victoria técnica)
function anotarPunto(estado, lado, tecnica) {
  let punto;
  if (tecnica === "hansoku") punto = { tipo: "ippon", origen: "hansoku" };
  else if (tecnica === "tecnico") punto = { tipo: "tecnico", origen: "tecnico" };
  else punto = { tipo: tecnica, origen: "tecnica" };
  estado.competidores[lado].puntos.push(punto);
  registrarEvento(estado, lado, "punto", tecnica);
}

// Deshacer: quita solo el último punto u hansoku del combate en curso.
// No toca nombres, clubes, ronda ni ajustes.
function deshacerUltimoEvento(estado) {
  const eventos = estado.combate.eventos;
  if (combateFinalizado(estado) || eventos.length === 0) return;
  const ultimo = eventos[eventos.length - 1];

  if (ultimo.tipo === "hansoku") {
    // hansoku suelto: se quita y baja el contador
    eventos.pop();
    const c = estado.competidores[ultimo.lado];
    c.hansoku = Math.max(0, c.hansoku - 1);
  } else if (ultimo.tecnica === "hansoku") {
    // punto automático por el 2.º hansoku del rival: se quita el punto, se quita
    // ese 2.º hansoku y el contador del infractor vuelve a 1
    eventos.pop();
    estado.competidores[ultimo.lado].puntos.pop();
    const infractor = otroLado(ultimo.lado);
    const previo = eventos[eventos.length - 1];
    if (previo && previo.tipo === "hansoku" && previo.lado === infractor) eventos.pop();
    estado.competidores[infractor].hansoku = 1;
  } else if (ultimo.tecnica === "tecnico") {
    // victoria técnica: se quitan juntos los puntos técnicos que añadió (1 o 2)
    while (eventos.length > 0 && eventos[eventos.length - 1].tecnica === "tecnico") {
      const e = eventos.pop();
      estado.competidores[e.lado].puntos.pop();
    }
    estado.combate.tecnica = null;
  } else {
    eventos.pop();
    estado.competidores[ultimo.lado].puntos.pop();
  }
}

// Resultado al finalizar. Devuelve null si falta una decisión (Hantei) que el operador debe dar.
// El combate de desempate de un encuentro no puede acabar en empate: tiene que haber ganador.
function calcularResultado(estado, decision) {
  const resultado = calcularResultadoBase(estado, decision);
  const ref = estado.combate.encuentro;
  if (resultado && resultado.ganador === "empate" && ref && ref.desempate) return null;
  return resultado;
}

function calcularResultadoBase(estado, decision) {
  const combate = estado.combate;
  if (combate.tecnica) {
    return { ganador: combate.tecnica.ganador, tipo: "tecnica", motivo: combate.tecnica.motivo };
  }
  const puntoEncho = combate.eventos.find((e) => e.tipo === "punto" && e.encho === true);
  if (puntoEncho) {
    return { ganador: puntoEncho.lado, tipo: "encho", motivo: null };
  }
  const ps = puntosDe(estado, "shiro");
  const pa = puntosDe(estado, "aka");
  if (ps >= PUNTOS_PARA_GANAR || pa >= PUNTOS_PARA_GANAR) {
    return { ganador: ps > pa ? "shiro" : "aka", tipo: "puntos", motivo: "dos_puntos" };
  }
  if (ps !== pa) {
    return { ganador: ps > pa ? "shiro" : "aka", tipo: "puntos", motivo: "tiempo" };
  }
  // marcador igualado
  if (!estado.encho) return { ganador: "empate", tipo: "empate", motivo: null };
  if (decision === "shiro" || decision === "aka") return { ganador: decision, tipo: "hantei", motivo: null };
  if (decision === "empate") return { ganador: "empate", tipo: "empate", motivo: null };
  return null; // encho agotado: hay que elegir Hantei Blanco / Hantei Rojo / Empate
}

// --- Encuentros por equipos (Fase 5) ---
// Los contadores de cada equipo (victorias, empates, ippones) se calculan desde los
// combates del encuentro. El desempate decide el encuentro pero no suma a los contadores.
// Un punto de victoria técnica cuenta como ippon del equipo (victoria 2-0 por reglamento).
function recalcularEncuentro(estado) {
  const enc = estado.encuentro;
  if (!enc) return;
  const regulares = enc.combates.filter((c) => !c.desempate);

  LADOS.forEach((lado) => {
    const equipo = estado.equipos[lado];
    equipo.victorias = regulares.filter((c) => c.ganador === lado).length;
    equipo.empates = regulares.filter((c) => c.ganador === "empate").length;
    equipo.ippones = regulares.reduce((suma, c) => suma + c.ippones[lado], 0);
  });

  enc.estado = "en_curso";
  enc.resultado = null;
  if (regulares.length < enc.integrantes) return; // faltan combates por jugar

  const v = estado.equipos;
  if (v.shiro.victorias !== v.aka.victorias) {
    enc.resultado = { ganador: v.shiro.victorias > v.aka.victorias ? "shiro" : "aka", motivo: "victorias" };
  } else if (v.shiro.ippones !== v.aka.ippones) {
    enc.resultado = { ganador: v.shiro.ippones > v.aka.ippones ? "shiro" : "aka", motivo: "ippones" };
  } else if (enc.eliminatoria) {
    const desempate = enc.combates.find((c) => c.desempate && c.ganador !== "empate");
    if (desempate) enc.resultado = { ganador: desempate.ganador, motivo: "desempate" };
    else {
      enc.estado = "pendiente_desempate";
      return;
    }
  } else {
    enc.resultado = { ganador: "empate", motivo: "empate" }; // en grupos, el encuentro queda empatado
  }
  enc.estado = "finalizado";
}

// Al finalizar un combate de un encuentro, su resultado se anota en el encuentro (una entrada por combate).
function confirmarEnEncuentro(estado) {
  const enc = estado.encuentro;
  const ref = estado.combate.encuentro;
  if (!enc || !ref || ref.id !== enc.id) return;
  const entrada = {
    id: estado.combate.id,
    posicion: ref.posicion,
    desempate: ref.desempate === true,
    ganador: estado.combate.resultado.ganador,
    tipo: estado.combate.resultado.tipo, // 'puntos' | 'encho' | 'hantei' | 'empate' | 'tecnica'
    motivo: estado.combate.resultado.motivo,
    nombres: {
      shiro: String(estado.competidores.shiro.nombre || "").trim(),
      aka: String(estado.competidores.aka.nombre || "").trim()
    },
    ippones: { shiro: puntosDe(estado, "shiro"), aka: puntosDe(estado, "aka") }
  };
  const indice = enc.combates.findIndex((c) => c.id === entrada.id);
  if (indice >= 0) enc.combates[indice] = entrada;
  else enc.combates.push(entrada);
  enc.combates.sort((a, b) => a.posicion - b.posicion);
}

// Al reabrir un combate, deja de contar en el encuentro hasta que se vuelva a finalizar.
function retirarDeEncuentro(estado) {
  const enc = estado.encuentro;
  if (!enc) return;
  enc.combates = enc.combates.filter((c) => c.id !== estado.combate.id);
}

// Crea el siguiente combate de un encuentro: los equipos conservan su lado, los competidores cambian.
// El club se rellena con el nombre del equipo (se puede editar). El desempate empieza ya en encho:
// el primer punto decide, o Hantei.
function nuevoCombateDeEncuentro(estado, { posicion, desempate, mantenerCompetidores }) {
  const previos = estado.competidores;
  const combate = crearCombateNuevo();
  combate.encuentro = { id: estado.encuentro.id, posicion, desempate };
  estado.combate = combate;
  estado.encho = desempate === true;
  LADOS.forEach((lado) => {
    const nuevo = crearCompetidorVacio();
    nuevo.logoClub = previos[lado].logoClub;
    if (mantenerCompetidores) {
      nuevo.nombre = previos[lado].nombre;
      nuevo.club = previos[lado].club;
      nuevo.foto = previos[lado].foto;
    } else {
      nuevo.club = estado.equipos[lado].nombre || "";
    }
    estado.competidores[lado] = nuevo;
  });
}

// Combate suelto ya finalizado: pasa al siguiente. Se vacían los datos del combate (competidores, clubes,
// fotos, logos y ronda); se conservan el torneo, la categoría, la modalidad, los ajustes y los contadores
// de equipo manuales. No hace falta confirmar: el combate ya está finalizado (y guardado, si se registra).
function siguienteCombateSuelto(estado) {
  if (!combateFinalizado(estado)) return estado;
  const nuevo = estadoInicial();
  nuevo.evento = estado.evento;
  nuevo.modoEquipos = estado.modoEquipos;
  nuevo.categoria = estado.categoria;
  nuevo.modalidad = estado.modalidad;
  nuevo.configuracion = estado.configuracion;
  nuevo.equipos = estado.equipos;
  return nuevo;
}

function siguienteCombateDeEncuentro(estado) {
  const enc = estado.encuentro;
  if (!enc || !combateFinalizado(estado) || enc.estado === "finalizado") return estado;
  if (enc.estado === "pendiente_desempate") {
    nuevoCombateDeEncuentro(estado, { posicion: enc.integrantes + 1, desempate: true, mantenerCompetidores: false });
  } else {
    const jugados = enc.combates.filter((c) => !c.desempate).length;
    nuevoCombateDeEncuentro(estado, { posicion: jugados + 1, desempate: false, mantenerCompetidores: false });
  }
  return estado;
}

// Recalcula lo que se deriva del estado. Se ejecuta tras cada acción.
function recalcular(estado) {
  const combate = estado.combate;
  recalcularEncuentro(estado);

  // El encho solo tiene sentido con el marcador igualado: si deshacer deja el
  // marcador desigual y todavía no hay punto en encho, se apaga solo.
  if (estado.encho && !marcadorIgualado(estado) && !hayPuntoEnEncho(estado)) {
    estado.encho = false;
  }

  if (combateFinalizado(estado)) combate.estado = "finalizado";
  else if (combateDecidido(estado)) combate.estado = "decidido";
  else combate.estado = "en_curso";

  combate.requiereHantei =
    combate.estado === "en_curso" && estado.encho === true && marcadorIgualado(estado);
  return estado;
}

// ---------------------------------------------------------------------------
// Compatibilidad con estados antiguos (data/estado.json de la v2.0 o anteriores)
// ---------------------------------------------------------------------------

function esObjetoPlano(valor) {
  return valor !== null && typeof valor === "object" && !Array.isArray(valor);
}

// Rellena en "destino" lo que falte respecto a "base", sin tocar lo que ya existe.
function completar(destino, base) {
  Object.keys(base).forEach((clave) => {
    if (destino[clave] === undefined) {
      destino[clave] = clonar(base[clave]);
    } else if (esObjetoPlano(destino[clave]) && esObjetoPlano(base[clave])) {
      completar(destino[clave], base[clave]);
    }
  });
}

// Reconstruye (en lo posible) el registro de eventos de un combate que se
// guardó antes de existir. El orden entre lados no se conoce: se agrupa por lado.
function reconstruirEventos(estado) {
  const eventos = [];
  LADOS.forEach((lado) => {
    const c = estado.competidores[lado];
    (c.puntos || []).forEach((p) => {
      const tecnica = p.origen === "hansoku" ? "hansoku" : p.tipo;
      eventos.push(crearEvento(eventos.length + 1, lado, "punto", tecnica, false));
    });
    for (let i = 0; i < (c.hansoku || 0); i++) {
      eventos.push(crearEvento(eventos.length + 1, lado, "hansoku", null, false));
    }
  });
  return eventos;
}

/**
 * Prepara un estado leído del disco: completa lo que falte y recalcula lo derivado.
 * Devuelve null si lo recibido no es un estado utilizable (se usará el inicial).
 */
function normalizarEstado(guardado) {
  if (!esObjetoPlano(guardado)) return null;
  const estado = clonar(guardado);
  const base = estadoInicial();

  const combateBase = base.combate;
  delete base.combate;
  const teniaCombate = esObjetoPlano(estado.combate);
  completar(estado, base); // el resto del estado (el combate se trata aparte)

  if (teniaCombate) {
    completar(estado.combate, combateBase);
    if (!Array.isArray(estado.combate.eventos)) estado.combate.eventos = [];
  } else {
    // estado anterior a la v2.1: se crea el combate y se reconstruyen sus eventos
    estado.combate = combateBase;
    estado.combate.eventos = reconstruirEventos(estado);
  }

  estado.version = 2;
  return recalcular(estado);
}

// ---------------------------------------------------------------------------
// Acciones
// ---------------------------------------------------------------------------

/**
 * Aplica una acción sobre el estado actual y devuelve el nuevo estado.
 * No modifica el estado recibido.
 *
 * Tipos de acción soportados:
 *  - PUNTO            { lado: 'shiro'|'aka', tecnica: 'men'|'kote'|'do'|'tsuki' }
 *  - HANSOKU          { lado }
 *  - DESHACER         {}  quita solo el último punto u hansoku (no con el combate finalizado)
 *  - FINALIZAR_COMBATE { decision?: 'shiro'|'aka'|'empate' }
 *                     decision solo hace falta con encho activo y marcador igualado
 *                     (estado.combate.requiereHantei): 'shiro'/'aka' = Hantei, 'empate' = empate.
 *  - VICTORIA_TECNICA { ganador: 'shiro'|'aka', motivo: 'incomparecencia'|'lesion'|'descalificacion'|'otro' }
 *  - REABRIR_COMBATE  {}  solo con el combate finalizado
 *  - INICIAR_ENCUENTRO { integrantes: 3|5, eliminatoria: boolean }  (nombres de equipo: EDITAR_EQUIPO)
 *  - SIGUIENTE_COMBATE {}  solo con el combate finalizado. Vacía los datos y pasa al siguiente. En un
 *                          encuentro por equipos, tras un empate total en una eliminatoria, el siguiente
 *                          es el combate de desempate
 *  - CERRAR_ENCUENTRO  {}  los contadores quedan como están y vuelven a ser manuales
 *  - QUITAR_ULTIMO_PUNTO   { lado }  (OBSOLETA: sustituida por DESHACER; se retirará en la Fase 2)
 *  - REINICIAR_COMBATE     { mantenerCompetidores: boolean }
 *  - INTERCAMBIAR_COMPETIDORES   (solo si el combate aún no tiene eventos)
 *  - EDITAR_COMPETIDOR     { lado, campo: 'nombre'|'club', valor }
 *  - EDITAR_INFO_GENERAL   { valor }
 *  - EDITAR_NOMBRE_TORNEO  { valor }
 *  - TOGGLE_MODO_EQUIPOS
 *  - EDITAR_EQUIPO         { lado, campo: 'nombre'|'victorias'|'empates'|'ippones', valor }
 *  - CAMBIAR_DISENO_MARCADOR   { valor: identificador del diseño de overlay }
 *  - TOGGLE_MARCA_AGUA
 *  - TOGGLE_ENCHO             (solo se activa con el marcador igualado)
 *  - CAMBIAR_CATEGORIA        { opcion: 'masculino'|'femenino'|'junior'|'otro', textoPersonalizado }
 *  - CAMBIAR_MODALIDAD        { opcion: 'individual'|'equipos'|'otro', textoPersonalizado }
 *  - CAMBIAR_FOTO_COMPETIDOR  { lado, archivo: nombre de archivo en public/fotos-competidores/ }
 *  - CAMBIAR_LOGO_CLUB        { lado, archivo: nombre de archivo en public/logos-clubes/ }
 *  - TOGGLE_MODO_CAMPEONATO_IMPORTANTE
 *  - CAMBIAR_IDIOMA           { valor: 'es'|'en' — solo afecta a la interfaz del panel }
 *
 * Reglas del propio motor (no dependen de acciones externas):
 *  - Un combate queda "decidido" cuando un competidor llega a 2 puntos o cuando
 *    se marca un punto en encho; entonces PUNTO y HANSOKU se ignoran hasta que
 *    se deshaga algo o se reinicie el combate.
 *  - Un combate "finalizado" bloquea además competidores, ronda, categoría,
 *    modalidad y encho, hasta REINICIAR_COMBATE o REABRIR_COMBATE.
 *  - Una acción no válida o no permitida en el estado actual se ignora.
 */
function aplicarAccion(estadoActual, accion) {
  const estado = clonar(estadoActual);
  if (!accion || typeof accion.tipo !== "string") return estado;
  return recalcular(ejecutarAccion(estado, accion));
}

function ejecutarAccion(estado, accion) {
  switch (accion.tipo) {
    case "PUNTO": {
      if (!ladoValido(accion.lado) || !TECNICAS.includes(accion.tecnica)) return estado;
      if (combateBloqueado(estado)) return estado; // decidido o finalizado: no se anota más
      anotarPunto(estado, accion.lado, accion.tecnica);
      return estado;
    }

    case "HANSOKU": {
      if (!ladoValido(accion.lado)) return estado;
      if (combateBloqueado(estado)) return estado; // decidido o finalizado: no se registran más hansoku
      const lado = accion.lado;
      const rival = otroLado(lado);
      const competidor = estado.competidores[lado];
      competidor.hansoku += 1;
      registrarEvento(estado, lado, "hansoku");

      // al segundo hansoku, el rival recibe un ippon automático
      if (competidor.hansoku === 2) {
        anotarPunto(estado, rival, "hansoku");
        competidor.hansoku = 0; // se resetea tras penalizar
      }
      return estado;
    }

    case "DESHACER": {
      deshacerUltimoEvento(estado);
      return estado;
    }

    case "FINALIZAR_COMBATE": {
      if (combateFinalizado(estado)) return estado;
      const resultado = calcularResultado(estado, accion.decision);
      if (resultado) {
        estado.combate.resultado = resultado;
        confirmarEnEncuentro(estado);
      }
      return estado;
    }

    case "VICTORIA_TECNICA": {
      if (!ladoValido(accion.ganador) || !MOTIVOS_TECNICOS.includes(accion.motivo)) return estado;
      if (combateBloqueado(estado)) return estado;
      // completa al ganador hasta 2 puntos (si tenía 1, se añade 1)
      const faltan = PUNTOS_PARA_GANAR - puntosDe(estado, accion.ganador);
      for (let i = 0; i < faltan; i++) anotarPunto(estado, accion.ganador, "tecnico");
      estado.combate.tecnica = { ganador: accion.ganador, motivo: accion.motivo };
      return estado;
    }

    case "REABRIR_COMBATE": {
      if (!combateFinalizado(estado)) return estado;
      retirarDeEncuentro(estado);
      if (!estado.encuentro) estado.combate.encuentro = null; // el encuentro ya se cerró: vuelve a ser un combate suelto
      estado.combate.resultado = null; // mismo id: al volver a finalizar se sobrescribe el mismo registro
      return estado;
    }

    case "QUITAR_ULTIMO_PUNTO": {
      // OBSOLETA (la sustituye DESHACER). Se mantiene coherente con el registro de eventos.
      if (!ladoValido(accion.lado) || combateFinalizado(estado)) return estado;
      const eventos = estado.combate.eventos;
      for (let i = eventos.length - 1; i >= 0; i--) {
        if (eventos[i].tipo === "punto" && eventos[i].lado === accion.lado) {
          if (eventos[i].tecnica === "tecnico") estado.combate.tecnica = null;
          eventos.splice(i, 1);
          eventos.forEach((e, idx) => (e.n = idx + 1));
          break;
        }
      }
      estado.competidores[accion.lado].puntos.pop();
      return estado;
    }

    case "INICIAR_ENCUENTRO": {
      if (estado.encuentro) return estado; // ya hay uno en curso
      const integrantes = Number(accion.integrantes);
      if (![3, 5].includes(integrantes)) return estado;
      // no se descarta un combate a medias: solo se empieza con uno finalizado o sin eventos
      if (!combateFinalizado(estado) && estado.combate.eventos.length > 0) return estado;

      estado.encuentro = {
        id: crypto.randomUUID(),
        integrantes,
        eliminatoria: accion.eliminatoria === true,
        estado: "en_curso",
        combates: [],
        resultado: null
      };
      estado.modoEquipos = true;
      // los combates del encuentro van a la competición "equipos" (salvo que se haya escrito una modalidad propia)
      if (estado.modalidad.opcion !== "otro") estado.modalidad = { opcion: "equipos", textoPersonalizado: "" };
      LADOS.forEach((lado) => {
        estado.equipos[lado].victorias = 0;
        estado.equipos[lado].empates = 0;
        estado.equipos[lado].ippones = 0;
      });
      nuevoCombateDeEncuentro(estado, { posicion: 1, desempate: false, mantenerCompetidores: false });
      return estado;
    }

    case "SIGUIENTE_COMBATE": {
      return estado.encuentro ? siguienteCombateDeEncuentro(estado) : siguienteCombateSuelto(estado);
    }

    case "CERRAR_ENCUENTRO": {
      if (!estado.encuentro) return estado;
      estado.encuentro = null; // los contadores se quedan como están y vuelven a ser editables a mano
      if (!combateFinalizado(estado)) estado.combate.encuentro = null;
      return estado;
    }

    case "REINICIAR_COMBATE": {
      if (estado.encuentro) {
        // En un encuentro, reiniciar conserva equipos y encuentro. Con el combate ya finalizado
        // equivale a pasar al siguiente; si estaba a medias, repite la misma posición.
        if (combateFinalizado(estado)) return siguienteCombateDeEncuentro(estado);
        const ref = estado.combate.encuentro;
        const jugados = estado.encuentro.combates.filter((c) => !c.desempate).length;
        nuevoCombateDeEncuentro(estado, {
          posicion: ref ? ref.posicion : jugados + 1,
          desempate: ref ? ref.desempate === true : false,
          mantenerCompetidores: accion.mantenerCompetidores === true
        });
        return estado;
      }
      const nuevo = estadoInicial(); // trae un combate nuevo, con id nuevo
      nuevo.evento = estado.evento;
      nuevo.modoEquipos = estado.modoEquipos;
      nuevo.categoria = estado.categoria; // información del evento, no del combate: se mantiene
      nuevo.modalidad = estado.modalidad;
      nuevo.configuracion = estado.configuracion; // la configuración es global, no se reinicia con el combate
      nuevo.equipos = accion.mantenerCompetidores ? estado.equipos : estadoInicial().equipos;
      if (accion.mantenerCompetidores) {
        LADOS.forEach((lado) => {
          nuevo.competidores[lado].nombre = estado.competidores[lado].nombre;
          nuevo.competidores[lado].club = estado.competidores[lado].club;
          nuevo.competidores[lado].foto = estado.competidores[lado].foto;
          nuevo.competidores[lado].logoClub = estado.competidores[lado].logoClub;
        });
      }
      return nuevo;
    }

    case "INTERCAMBIAR_COMPETIDORES": {
      if (estado.encuentro) return estado; // cada equipo conserva su lado durante el encuentro
      if (combateFinalizado(estado) || estado.combate.eventos.length > 0) return estado;
      const temp = estado.competidores.shiro;
      estado.competidores.shiro = estado.competidores.aka;
      estado.competidores.aka = temp;
      return estado;
    }

    case "EDITAR_COMPETIDOR": {
      if (!ladoValido(accion.lado) || !["nombre", "club"].includes(accion.campo)) return estado;
      if (combateFinalizado(estado)) return estado;
      estado.competidores[accion.lado][accion.campo] = accion.valor;
      return estado;
    }

    case "EDITAR_INFO_GENERAL": {
      if (combateFinalizado(estado)) return estado; // es la ronda: bloqueada con el combate finalizado
      estado.infoGeneral = accion.valor;
      return estado;
    }

    case "EDITAR_NOMBRE_TORNEO": {
      estado.evento.nombreTorneo = accion.valor;
      return estado;
    }

    case "TOGGLE_MODO_EQUIPOS": {
      if (estado.encuentro) return estado; // con un encuentro en curso el modo equipos no se apaga
      estado.modoEquipos = !estado.modoEquipos;
      return estado;
    }

    case "EDITAR_EQUIPO": {
      if (!ladoValido(accion.lado)) return estado;
      // con un encuentro en curso los contadores se calculan solos; el nombre sí se puede editar
      if (estado.encuentro && ["victorias", "empates", "ippones"].includes(accion.campo)) return estado;
      estado.equipos[accion.lado][accion.campo] = accion.valor;
      return estado;
    }

    case "CAMBIAR_DISENO_MARCADOR": {
      estado.configuracion.disenoMarcador = accion.valor;
      return estado;
    }

    case "TOGGLE_MARCA_AGUA": {
      estado.configuracion.marcaAguaVisible = !estado.configuracion.marcaAguaVisible;
      return estado;
    }

    case "TOGGLE_ENCHO": {
      if (combateBloqueado(estado)) return estado; // decidido o finalizado: el encho ya no se toca
      if (!estado.encho && !marcadorIgualado(estado)) return estado; // solo se activa con el marcador igualado
      estado.encho = !estado.encho;
      return estado;
    }

    case "CAMBIAR_CATEGORIA": {
      if (combateFinalizado(estado) || estado.encuentro) return estado;
      estado.categoria = { opcion: accion.opcion, textoPersonalizado: accion.textoPersonalizado || "" };
      return estado;
    }

    case "CAMBIAR_MODALIDAD": {
      if (combateFinalizado(estado) || estado.encuentro) return estado;
      estado.modalidad = { opcion: accion.opcion, textoPersonalizado: accion.textoPersonalizado || "" };
      return estado;
    }

    case "CAMBIAR_FOTO_COMPETIDOR": {
      if (!ladoValido(accion.lado) || combateFinalizado(estado)) return estado;
      estado.competidores[accion.lado].foto = accion.archivo;
      return estado;
    }

    case "CAMBIAR_LOGO_CLUB": {
      if (!ladoValido(accion.lado) || combateFinalizado(estado)) return estado;
      estado.competidores[accion.lado].logoClub = accion.archivo;
      return estado;
    }

    case "TOGGLE_MODO_CAMPEONATO_IMPORTANTE": {
      estado.configuracion.modoCampeonatoImportante = !estado.configuracion.modoCampeonatoImportante;
      return estado;
    }

    case "CAMBIAR_IDIOMA": {
      estado.configuracion.idioma = accion.valor;
      return estado;
    }

    default:
      // acción desconocida: no se modifica el estado
      return estado;
  }
}

module.exports = { estadoInicial, aplicarAccion, clonar, normalizarEstado };
