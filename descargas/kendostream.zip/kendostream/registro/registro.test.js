// registro.test.js — pruebas de la Fase 4. Se ejecutan con:  node --test
// Usan carpetas temporales: no tocan nada de tu proyecto.

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { estadoInicial, aplicarAccion, normalizarEstado } = require("../motor/motor");
const { crearRegistro, slug, resolverCarpeta, validarDatos, carpetaPorDefecto } = require("./registro");

// ---------------------------------------------------------------- utilidades

function entorno() {
  const raiz = fs.mkdtempSync(path.join(os.tmpdir(), "kendo-"));
  const carpeta = path.join(raiz, "resultados");
  const rutaAjustes = path.join(raiz, "data", "ajustes.json");
  const carpetaRespaldo = path.join(raiz, "data", "respaldo");
  fs.mkdirSync(path.dirname(rutaAjustes), { recursive: true });
  fs.writeFileSync(rutaAjustes, JSON.stringify({ carpetaResultados: carpeta }));
  const avisos = [];
  const registro = crearRegistro({
    rutaAjustes,
    carpetaRespaldo,
    version: "2.1.0",
    alCambiar: () => avisos.push(1),
    reintentoMs: 0 // en las pruebas el reintento se lanza a mano
  });
  return { raiz, carpeta, rutaAjustes, carpetaRespaldo, registro, avisos };
}

function aplicar(estado, ...acciones) {
  return acciones.reduce((e, a) => aplicarAccion(e, a), estado);
}
const punto = (lado, tecnica = "men") => ({ tipo: "PUNTO", lado, tecnica });
const nuevoEstado = () => normalizarEstado(estadoInicial());

// Un combate finalizado: Blanco gana por 2 puntos
function combateFinalizado(extra = []) {
  return aplicar(
    nuevoEstado(),
    { tipo: "EDITAR_COMPETIDOR", lado: "shiro", campo: "nombre", valor: "  Ana  " },
    { tipo: "EDITAR_COMPETIDOR", lado: "shiro", campo: "club", valor: "Club A" },
    { tipo: "EDITAR_COMPETIDOR", lado: "aka", campo: "nombre", valor: "Bea" },
    { tipo: "EDITAR_INFO_GENERAL", valor: " Semifinal 1 " },
    punto("shiro"),
    punto("shiro", "do"),
    ...extra,
    { tipo: "FINALIZAR_COMBATE" }
  );
}

const LADOS = ["shiro", "aka"];
const TECNICAS = ["men", "kote", "do", "tsuki", "hansoku", "tecnico"];
const TIPOS_RESULTADO = ["puntos", "encho", "empate", "hantei", "tecnica"];
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

// Comprueba el archivo contra el contrato del §6
function comprobarEsquema(datos) {
  assert.equal(datos.esquema, 1);
  assert.equal(datos.programa.nombre, "KendoSTREAM");
  assert.ok(datos.programa.version);
  assert.match(datos.evento.id, UUID);
  assert.equal(typeof datos.evento.nombre, "string");
  assert.match(datos.evento.fecha, /^\d{4}-\d{2}-\d{2}$/);
  assert.ok(Array.isArray(datos.competiciones));
  for (const comp of datos.competiciones) {
    assert.match(comp.id, UUID);
    assert.ok(["opcion", "texto"].every((k) => k in comp.categoria));
    assert.ok(["opcion", "texto"].every((k) => k in comp.modalidad));
    assert.ok(comp.integrantesEquipo === null || [3, 5].includes(comp.integrantesEquipo));
    assert.deepEqual(Object.keys(comp.podio).sort(), ["origen", "primero", "segundo", "terceros"]);
    assert.ok(Array.isArray(comp.encuentros));
    for (const enc of comp.encuentros) {
      assert.match(enc.id, UUID);
      assert.equal(typeof enc.shiro.nombre, "string");
      assert.equal(typeof enc.aka.nombre, "string");
      assert.ok([3, 5].includes(enc.integrantes));
      assert.equal(enc.integrantes, comp.integrantesEquipo);
      assert.equal(typeof enc.eliminatoria, "boolean");
      if (enc.resultado !== null) {
        assert.ok([...LADOS, "empate"].includes(enc.resultado.ganador));
        assert.ok(["victorias", "ippones", "desempate", "empate"].includes(enc.resultado.motivo));
      }
    }
    for (const b of comp.combates) {
      assert.match(b.id, UUID);
      assert.equal(typeof b.numero, "number");
      assert.match(b.fecha, /^\d{4}-\d{2}-\d{2}$/);
      assert.equal(b.pista, 1);
      assert.equal(typeof b.ronda, "string");
      for (const l of LADOS) assert.deepEqual(Object.keys(b[l]).sort(), ["club", "nombre"]);
      assert.equal(typeof b.encho, "boolean");
      b.eventos.forEach((e, i) => {
        assert.equal(e.n, i + 1);
        assert.ok(LADOS.includes(e.lado));
        assert.ok(["punto", "hansoku"].includes(e.tipo));
        assert.equal(typeof e.encho, "boolean");
        if (e.tipo === "punto") assert.ok(TECNICAS.includes(e.tecnica));
        else assert.equal("tecnica" in e, false);
      });
      assert.ok(LADOS.every((l) => Number.isInteger(b.marcador[l])));
      assert.ok([...LADOS, "empate"].includes(b.resultado.ganador));
      assert.ok(TIPOS_RESULTADO.includes(b.resultado.tipo));
      if (b.encuentro === null) {
        assert.equal(comp.integrantesEquipo, null);
      } else {
        assert.match(b.encuentro.id, UUID);
        assert.ok(Number.isInteger(b.encuentro.posicion) && b.encuentro.posicion >= 1);
        assert.equal(typeof b.encuentro.desempate, "boolean");
        assert.ok(comp.encuentros.some((x) => x.id === b.encuentro.id)); // el encuentro existe en la misma competición
      }
    }
  }
}

const leer = (ruta) => JSON.parse(fs.readFileSync(ruta, "utf8"));

// ---------------------------------------------------------------- utilidades puras

test("slug quita acentos y signos", () => {
  assert.equal(slug("Campeonato de Aragón 2026"), "campeonato-de-aragon-2026");
  assert.equal(slug("  ¡¡Copa!!  "), "copa");
  assert.equal(slug(""), "sin-nombre");
  assert.equal(slug("???"), "sin-nombre");
});

test("Las rutas relativas se entienden desde la carpeta personal", () => {
  assert.equal(resolverCarpeta("Documentos/Kendo"), path.join(os.homedir(), "Documentos", "Kendo"));
  assert.equal(resolverCarpeta(""), carpetaPorDefecto());
  assert.equal(resolverCarpeta("~/Kendo"), path.join(os.homedir(), "Kendo"));
  const absoluta = path.resolve("/tmp/x");
  assert.equal(resolverCarpeta(absoluta), absoluta);
});

// ---------------------------------------------------------------- Nuevo

test("Nuevo crea la carpeta y un archivo válido según el esquema", () => {
  const e = entorno();
  const estado = e.registro.nuevo({ nombre: "Campeonato de Aragón 2026" });
  assert.equal(estado.activo, true);
  assert.equal(estado.combates, 0);
  assert.match(estado.archivo, /^\d{4}-\d{2}-\d{2}_campeonato-de-aragon-2026\.json$/);
  const datos = leer(path.join(e.carpeta, estado.archivo));
  comprobarEsquema(datos);
  assert.equal(datos.evento.nombre, "Campeonato de Aragón 2026");
  assert.equal(datos.programa.version, "2.1.0");
  assert.deepEqual(datos.competiciones, []);
  e.registro.cerrar();
});

test("Si el archivo ya existe se añade -2, -3…", () => {
  const e = entorno();
  const a = e.registro.nuevo({ nombre: "Copa" }).archivo;
  const b = e.registro.nuevo({ nombre: "Copa" }).archivo;
  const c = e.registro.nuevo({ nombre: "Copa" }).archivo;
  assert.match(b, /^\d{4}-\d{2}-\d{2}_copa-2\.json$/);
  assert.match(c, /^\d{4}-\d{2}-\d{2}_copa-3\.json$/);
  assert.notEqual(a, b);
  e.registro.cerrar();
});

test("Con el registro apagado no se escribe nada", () => {
  const e = entorno();
  const r = e.registro.guardarCombate(combateFinalizado());
  assert.equal(r.guardado, false);
  assert.equal(fs.existsSync(e.carpeta), false);
});

// ---------------------------------------------------------------- Guardar combates

test("Un combate finalizado se guarda con todos sus datos", () => {
  const e = entorno();
  const { archivo } = e.registro.nuevo({ nombre: "Copa" });
  const estado = combateFinalizado();
  assert.equal(e.registro.guardarCombate(estado).guardado, true);

  const datos = leer(path.join(e.carpeta, archivo));
  comprobarEsquema(datos);
  assert.equal(datos.competiciones.length, 1);
  const comp = datos.competiciones[0];
  assert.deepEqual(comp.categoria, { opcion: "masculino", texto: "" });
  assert.deepEqual(comp.modalidad, { opcion: "individual", texto: "" });
  const b = comp.combates[0];
  assert.equal(b.id, estado.combate.id);
  assert.equal(b.numero, 1);
  assert.equal(b.pista, 1);
  assert.equal(b.ronda, "Semifinal 1"); // recortado
  assert.deepEqual(b.shiro, { nombre: "Ana", club: "Club A" }); // recortado
  assert.deepEqual(b.aka, { nombre: "Bea", club: "" });
  assert.deepEqual(b.marcador, { shiro: 2, aka: 0 });
  assert.deepEqual(b.resultado, { ganador: "shiro", tipo: "puntos", motivo: "dos_puntos" });
  assert.equal(b.eventos.length, 2);
  assert.equal(e.registro.estado().combates, 1);
  e.registro.cerrar();
});

test("Hansoku, encho y victoria técnica quedan como dicta el esquema", () => {
  const e = entorno();
  const { archivo } = e.registro.nuevo({ nombre: "Copa" });

  // 2.º hansoku de Blanco: punto automático para Rojo; luego 1-1 y encho; Rojo marca en encho
  let a = aplicar(
    nuevoEstado(),
    punto("shiro", "men"),
    { tipo: "HANSOKU", lado: "shiro" },
    { tipo: "HANSOKU", lado: "shiro" }, // da punto a Rojo (1-1)
    { tipo: "TOGGLE_ENCHO" },
    { tipo: "HANSOKU", lado: "aka" },
    punto("aka", "do"),
    { tipo: "FINALIZAR_COMBATE" }
  );
  e.registro.guardarCombate(a);

  let t = aplicar(
    nuevoEstado(),
    punto("aka", "kote"),
    { tipo: "VICTORIA_TECNICA", ganador: "shiro", motivo: "lesion" },
    { tipo: "FINALIZAR_COMBATE" }
  );
  e.registro.guardarCombate(t);

  const datos = leer(path.join(e.carpeta, archivo));
  comprobarEsquema(datos);
  const [b1, b2] = datos.competiciones[0].combates;
  assert.equal(b1.encho, true);
  assert.deepEqual(
    b1.eventos.map((x) => [x.lado, x.tipo, x.tecnica ?? null, x.encho]),
    [
      ["shiro", "punto", "men", false],
      ["shiro", "hansoku", null, false],
      ["shiro", "hansoku", null, false],
      ["aka", "punto", "hansoku", false],
      ["aka", "hansoku", null, true],
      ["aka", "punto", "do", true]
    ]
  );
  assert.deepEqual(b1.resultado, { ganador: "aka", tipo: "encho", motivo: null });
  assert.deepEqual(b1.marcador, { shiro: 1, aka: 2 });

  assert.deepEqual(b2.resultado, { ganador: "shiro", tipo: "tecnica", motivo: "lesion" });
  assert.deepEqual(b2.marcador, { shiro: 2, aka: 1 }); // ganador completado a 2
  assert.equal(b2.eventos.filter((x) => x.tecnica === "tecnico").length, 2);
  assert.equal(b2.numero, 2);
  e.registro.cerrar();
});

test("Hantei y empate se guardan sin tocar el marcador", () => {
  const e = entorno();
  const { archivo } = e.registro.nuevo({ nombre: "Copa" });
  const base = () => aplicar(nuevoEstado(), punto("shiro"), punto("aka", "kote"), { tipo: "TOGGLE_ENCHO" });
  e.registro.guardarCombate(aplicarAccion(base(), { tipo: "FINALIZAR_COMBATE", decision: "aka" }));
  e.registro.guardarCombate(aplicar(nuevoEstado(), { tipo: "FINALIZAR_COMBATE" }));
  const [h, d] = leer(path.join(e.carpeta, archivo)).competiciones[0].combates;
  assert.deepEqual(h.resultado, { ganador: "aka", tipo: "hantei", motivo: null });
  assert.deepEqual(h.marcador, { shiro: 1, aka: 1 });
  assert.deepEqual(d.resultado, { ganador: "empate", tipo: "empate", motivo: null });
  e.registro.cerrar();
});

test("Cada combate se asigna a su competición según categoría y modalidad", () => {
  const e = entorno();
  const { archivo } = e.registro.nuevo({ nombre: "Copa" });
  const masc = combateFinalizado();
  const fem = aplicar(nuevoEstado(), { tipo: "CAMBIAR_CATEGORIA", opcion: "femenino" }, punto("aka"), punto("aka", "do"), { tipo: "FINALIZAR_COMBATE" });
  const otro1 = aplicar(nuevoEstado(), { tipo: "CAMBIAR_CATEGORIA", opcion: "otro", textoPersonalizado: " Veteranos  +50 " }, { tipo: "FINALIZAR_COMBATE" });
  const otro2 = aplicar(nuevoEstado(), { tipo: "CAMBIAR_CATEGORIA", opcion: "otro", textoPersonalizado: "veteranos +50" }, { tipo: "FINALIZAR_COMBATE" });
  const equipos = aplicar(nuevoEstado(), { tipo: "CAMBIAR_MODALIDAD", opcion: "equipos" }, { tipo: "FINALIZAR_COMBATE" });
  [masc, fem, otro1, otro2, equipos].forEach((s) => e.registro.guardarCombate(s));

  const datos = leer(path.join(e.carpeta, archivo));
  comprobarEsquema(datos);
  assert.equal(datos.competiciones.length, 4); // masc/ind, fem/ind, veteranos, masc/equipos
  const veteranos = datos.competiciones.find((c) => c.categoria.opcion === "otro");
  assert.equal(veteranos.categoria.texto, "Veteranos  +50"); // se conserva tal cual, solo recortado
  assert.equal(veteranos.combates.length, 2); // mayúsculas/espacios no separan la competición
  assert.equal(datos.competiciones.find((c) => c.modalidad.opcion === "equipos").combates.length, 1);
  e.registro.cerrar();
});

// ---------------------------------------------------------------- Reabrir

test("Reabrir y finalizar de nuevo sobrescribe el mismo registro, sin duplicar", () => {
  const e = entorno();
  const { archivo } = e.registro.nuevo({ nombre: "Copa" });
  let s = combateFinalizado();
  e.registro.guardarCombate(s);
  e.registro.guardarCombate(combateFinalizado()); // otro combate distinto (otro id)
  let antes = leer(path.join(e.carpeta, archivo)).competiciones[0].combates;
  assert.equal(antes.length, 2);

  // reabrir el primero, corregir (Rojo marca un punto) y finalizar otra vez
  s = aplicar(s, { tipo: "REABRIR_COMBATE" }, { tipo: "DESHACER" }, { tipo: "FINALIZAR_COMBATE" });
  e.registro.guardarCombate(s);

  const despues = leer(path.join(e.carpeta, archivo)).competiciones[0].combates;
  assert.equal(despues.length, 2); // no se duplicó
  assert.equal(despues[0].id, s.combate.id);
  assert.equal(despues[0].numero, 1); // conserva su número
  assert.equal(despues[0].fecha, antes[0].fecha);
  assert.deepEqual(despues[0].marcador, { shiro: 1, aka: 0 });
  assert.deepEqual(despues[0].resultado, { ganador: "shiro", tipo: "puntos", motivo: "tiempo" });
  e.registro.cerrar();
});

test("Si al reabrir cambia la categoría, el combate se mueve de competición", () => {
  const e = entorno();
  const { archivo } = e.registro.nuevo({ nombre: "Copa" });
  let s = combateFinalizado();
  e.registro.guardarCombate(s);
  s = aplicar(s, { tipo: "REABRIR_COMBATE" }, { tipo: "CAMBIAR_CATEGORIA", opcion: "junior" }, { tipo: "FINALIZAR_COMBATE" });
  e.registro.guardarCombate(s);
  const datos = leer(path.join(e.carpeta, archivo));
  assert.equal(datos.competiciones.length, 1); // la competición masculina quedó vacía y se retira
  assert.equal(datos.competiciones[0].categoria.opcion, "junior");
  assert.equal(datos.competiciones[0].combates.length, 1);
  e.registro.cerrar();
});

// ---------------------------------------------------------------- Escritura segura y fallos

test("No quedan temporales y existe la copia espejo", () => {
  const e = entorno();
  const { archivo } = e.registro.nuevo({ nombre: "Copa" });
  e.registro.guardarCombate(combateFinalizado());
  const ficheros = fs.readdirSync(e.carpeta);
  assert.ok(!ficheros.some((f) => f.endsWith(".tmp")));
  const espejo = leer(path.join(e.carpetaRespaldo, archivo));
  assert.deepEqual(espejo, leer(path.join(e.carpeta, archivo)));
  e.registro.cerrar();
});

test("Con la carpeta borrada: aviso, combate pendiente en la copia espejo y se recupera al volver", () => {
  const e = entorno();
  const { archivo } = e.registro.nuevo({ nombre: "Copa" });
  e.registro.guardarCombate(combateFinalizado());

  fs.rmSync(e.carpeta, { recursive: true, force: true });
  const r = e.registro.guardarCombate(combateFinalizado());
  assert.equal(r.guardado, false); // no lanza
  let st = e.registro.estado();
  assert.equal(st.error.codigo, "carpeta_no_existe");
  assert.equal(st.pendientes, 1);
  assert.equal(st.activo, true);
  assert.equal(leer(path.join(e.carpetaRespaldo, archivo)).competiciones[0].combates.length, 2); // no se pierde

  // un tercer combate con la carpeta aún rota: dos pendientes
  e.registro.guardarCombate(combateFinalizado());
  assert.equal(e.registro.estado().pendientes, 2);

  // el operador recupera la carpeta: el siguiente combate escribe todo
  fs.mkdirSync(e.carpeta, { recursive: true });
  e.registro.guardarCombate(combateFinalizado());
  st = e.registro.estado();
  assert.equal(st.error, null);
  assert.equal(st.pendientes, 0);
  const datos = leer(path.join(e.carpeta, archivo));
  comprobarEsquema(datos);
  assert.equal(datos.competiciones[0].combates.length, 4);
  e.registro.cerrar();
});

test("Con la carpeta no escribible también avisa y no pierde el combate", () => {
  const e = entorno();
  const { archivo } = e.registro.nuevo({ nombre: "Copa" });
  // se sustituye la carpeta por un archivo: no se puede escribir dentro
  fs.rmSync(e.carpeta, { recursive: true, force: true });
  fs.writeFileSync(e.carpeta, "no soy una carpeta");
  const r = e.registro.guardarCombate(combateFinalizado());
  assert.equal(r.guardado, false);
  const st = e.registro.estado();
  assert.ok(st.error);
  assert.equal(st.pendientes, 1);
  assert.equal(leer(path.join(e.carpetaRespaldo, archivo)).competiciones[0].combates.length, 1);
  e.registro.cerrar();
});

test("El reintento automático guarda lo pendiente cuando la carpeta vuelve", async () => {
  const e = entorno();
  const avisos = [];
  const registro = crearRegistro({
    rutaAjustes: e.rutaAjustes,
    carpetaRespaldo: e.carpetaRespaldo,
    version: "2.1.0",
    alCambiar: () => avisos.push(1),
    reintentoMs: 30
  });
  const { archivo } = registro.nuevo({ nombre: "Copa" });
  fs.rmSync(e.carpeta, { recursive: true, force: true });
  registro.guardarCombate(combateFinalizado());
  assert.ok(registro.estado().error);
  fs.mkdirSync(e.carpeta, { recursive: true });
  await new Promise((r) => setTimeout(r, 150));
  assert.equal(registro.estado().error, null);
  assert.equal(leer(path.join(e.carpeta, archivo)).competiciones[0].combates.length, 1);
  registro.cerrar();
});

// ---------------------------------------------------------------- Continuar, bloqueo y listado

test("Continuar retoma un archivo y sigue añadiendo combates", () => {
  const e = entorno();
  const { archivo } = e.registro.nuevo({ nombre: "Copa" });
  e.registro.guardarCombate(combateFinalizado());
  e.registro.cerrar(); // el servidor se cierra

  const e2 = crearRegistro({ rutaAjustes: e.rutaAjustes, carpetaRespaldo: e.carpetaRespaldo, version: "2.1.0", reintentoMs: 0 });
  const st = e2.estado();
  assert.equal(st.activo, false);
  assert.equal(st.ultimo.archivo, archivo); // propone continuar con el último
  e2.continuar({ ultimo: true });
  assert.equal(e2.estado().combates, 1);
  e2.guardarCombate(combateFinalizado());
  const datos = leer(path.join(e.carpeta, archivo));
  comprobarEsquema(datos);
  assert.equal(datos.competiciones[0].combates.length, 2);
  assert.equal(datos.competiciones[0].combates[1].numero, 2);
  e2.cerrar();
});

test("Continuar rechaza archivos ilegibles, de un esquema más nuevo o con nombres peligrosos", () => {
  const e = entorno();
  e.registro.nuevo({ nombre: "Copa" });
  e.registro.cerrar();
  fs.writeFileSync(path.join(e.carpeta, "2026-10-18_roto.json"), "{ esto no es json");
  fs.writeFileSync(path.join(e.carpeta, "2026-10-18_futuro.json"), JSON.stringify({ esquema: 2, evento: {}, competiciones: [] }));
  fs.writeFileSync(path.join(e.carpeta, "2026-10-18_raro.json"), JSON.stringify({ esquema: 1, evento: {}, competiciones: [{}] }));
  const codigo = (f) => { try { f(); } catch (err) { return err.codigo; } return null; };
  assert.equal(codigo(() => e.registro.continuar({ archivo: "2026-10-18_roto.json" })), "ilegible");
  assert.equal(codigo(() => e.registro.continuar({ archivo: "2026-10-18_futuro.json" })), "esquema_nuevo");
  assert.equal(codigo(() => e.registro.continuar({ archivo: "2026-10-18_raro.json" })), "ilegible");
  assert.equal(codigo(() => e.registro.continuar({ archivo: "no-existe.json" })), "no_existe");
  assert.equal(codigo(() => e.registro.continuar({ archivo: "../fuera.json" })), "ilegible");
  assert.equal(codigo(() => e.registro.continuar({ archivo: "/etc/passwd" })), "ilegible");
  assert.equal(e.registro.estado().activo, false);
});

test("Un archivo usado por otra instancia viva no se puede continuar; un bloqueo abandonado sí", () => {
  const e = entorno();
  const { archivo } = e.registro.nuevo({ nombre: "Copa" });
  e.registro.cerrar();
  const ruta = path.join(e.carpeta, archivo);

  // otra instancia viva (el proceso padre de las pruebas hace de "otra instancia")
  fs.writeFileSync(ruta + ".lock", JSON.stringify({ pid: process.ppid }));
  let codigo = null;
  try { e.registro.continuar({ archivo }); } catch (err) { codigo = err.codigo; }
  assert.equal(codigo, "en_uso");
  const fila = e.registro.listarArchivos().archivos.find((f) => f.archivo === archivo);
  assert.equal(fila.enUso, true);

  // bloqueo abandonado: el proceso ya no existe
  fs.writeFileSync(ruta + ".lock", JSON.stringify({ pid: 2 ** 22 - 3 }));
  assert.equal(e.registro.estado().activo, false);
  e.registro.continuar({ archivo });
  assert.equal(e.registro.estado().activo, true);

  // mientras está activo hay .lock nuestro; al detener desaparece
  assert.ok(fs.existsSync(ruta + ".lock"));
  e.registro.detener();
  assert.ok(!fs.existsSync(ruta + ".lock"));
});

test("Nuevo no reutiliza un archivo con bloqueo ajeno", () => {
  const e = entorno();
  const primero = e.registro.nuevo({ nombre: "Copa" }).archivo;
  e.registro.cerrar();
  fs.writeFileSync(path.join(e.carpeta, primero + ".lock"), JSON.stringify({ pid: process.ppid }));
  fs.rmSync(path.join(e.carpeta, primero));
  const segundo = e.registro.nuevo({ nombre: "Copa" }).archivo;
  assert.notEqual(primero, segundo);
  e.registro.cerrar();
});

test("El listado distingue archivos válidos, ilegibles y ajenos", () => {
  const e = entorno();
  const { archivo } = e.registro.nuevo({ nombre: "Copa de Zaragoza" });
  e.registro.guardarCombate(combateFinalizado());
  fs.writeFileSync(path.join(e.carpeta, "2026-10-01_roto.json"), "{ no");
  fs.writeFileSync(path.join(e.carpeta, "notas.json"), "{ no");
  fs.writeFileSync(path.join(e.carpeta, "otra-cosa.json"), JSON.stringify({ hola: 1 }));
  fs.writeFileSync(path.join(e.carpeta, "readme.txt"), "x");

  const { existe, archivos } = e.registro.listarArchivos();
  assert.equal(existe, true);
  const nombres = archivos.map((f) => f.archivo).sort();
  assert.deepEqual(nombres, [archivo, "2026-10-01_roto.json"].sort());
  const bueno = archivos.find((f) => f.archivo === archivo);
  assert.equal(bueno.ok, true);
  assert.equal(bueno.combates, 1);
  assert.equal(bueno.evento, "Copa de Zaragoza");
  assert.equal(bueno.actual, true);
  assert.equal(archivos.find((f) => f.archivo === "2026-10-01_roto.json").ok, false);
  e.registro.cerrar();
});

test("Listar con la carpeta inexistente no falla", () => {
  const e = entorno();
  assert.deepEqual(e.registro.listarArchivos().archivos, []);
  assert.equal(e.registro.listarArchivos().existe, false);
});

test("Cambiar de archivo libera el anterior", () => {
  const e = entorno();
  const a = e.registro.nuevo({ nombre: "Uno" }).archivo;
  const b = e.registro.nuevo({ nombre: "Dos" }).archivo;
  assert.ok(!fs.existsSync(path.join(e.carpeta, a + ".lock")));
  assert.ok(fs.existsSync(path.join(e.carpeta, b + ".lock")));
  e.registro.cerrar();
  assert.ok(!fs.existsSync(path.join(e.carpeta, b + ".lock")));
});

// ---------------------------------------------------------------- Carpeta y ajustes

test("Probar carpeta crea la que falta y comprueba que se puede escribir", () => {
  const e = entorno();
  const nueva = path.join(e.raiz, "otra", "carpeta");
  const r = e.registro.probarCarpeta(nueva);
  assert.equal(r.ok, true);
  assert.equal(r.creada, true);
  assert.ok(fs.existsSync(nueva));
  assert.deepEqual(fs.readdirSync(nueva), []); // sin restos de la prueba
  assert.equal(e.registro.probarCarpeta(nueva).creada, false);

  const archivo = path.join(e.raiz, "soy-un-archivo");
  fs.writeFileSync(archivo, "x");
  const mala = e.registro.probarCarpeta(archivo);
  assert.equal(mala.ok, false);
});

test("La carpeta elegida se guarda en ajustes.json", () => {
  const e = entorno();
  const destino = path.join(e.raiz, "mis-resultados");
  e.registro.guardarCarpeta(destino);
  assert.equal(leer(e.rutaAjustes).carpetaResultados, destino);
  assert.equal(e.registro.ajustes().carpeta, destino);
  const st = e.registro.nuevo({ nombre: "Copa" });
  assert.ok(fs.existsSync(path.join(destino, st.archivo)));
  e.registro.cerrar();
});

test("validarDatos acepta lo nuestro y rechaza lo demás", () => {
  assert.equal(validarDatos({ esquema: 1, evento: {}, competiciones: [] }).ok, true);
  assert.equal(validarDatos(null).ok, false);
  assert.equal(validarDatos([]).ok, false);
  assert.equal(validarDatos({ esquema: "1", evento: {}, competiciones: [] }).ok, false);
});

test("Un fallo interno al guardar no lanza (el marcador no se ve afectado)", () => {
  const e = entorno();
  e.registro.nuevo({ nombre: "Copa" });
  const r = e.registro.guardarCombate({ combate: { id: "x", resultado: {}, eventos: [] } }); // estado incompleto
  assert.equal(r.guardado, false);
  e.registro.cerrar();
});

// ---------------------------------------------------------------- Equipos (Fase 5)

const FIN = { tipo: "FINALIZAR_COMBATE" };
const SIGUIENTE = { tipo: "SIGUIENTE_COMBATE" };
function inicioEncuentro(integrantes, eliminatoria) {
  return aplicar(
    nuevoEstado(),
    { tipo: "EDITAR_EQUIPO", lado: "shiro", campo: "nombre", valor: " Zaragoza " },
    { tipo: "EDITAR_EQUIPO", lado: "aka", campo: "nombre", valor: "Huesca" },
    { tipo: "INICIAR_ENCUENTRO", integrantes, eliminatoria }
  );
}
// finaliza el combate actual con el resultado indicado y lo registra
function jugarYGuardar(registro, estado, gana) {
  let e = gana === "empate" ? aplicarAccion(estado, FIN) : aplicar(estado, punto(gana), punto(gana, "do"), FIN);
  registro.guardarCombate(e);
  return e;
}

test("Un encuentro completo se guarda: competición de equipos, integrantes, encuentro y combates enlazados", () => {
  const e = entorno();
  const { archivo } = e.registro.nuevo({ nombre: "Copa" });
  let s = inicioEncuentro(3, true);
  s = aplicarAccion(jugarYGuardar(e.registro, s, "shiro"), SIGUIENTE);

  let datos = leer(path.join(e.carpeta, archivo));
  comprobarEsquema(datos);
  let comp = datos.competiciones[0];
  assert.deepEqual(comp.modalidad, { opcion: "equipos", texto: "" });
  assert.equal(comp.integrantesEquipo, 3);
  assert.equal(comp.encuentros.length, 1);
  assert.deepEqual(comp.encuentros[0].shiro, { nombre: "Zaragoza" }); // recortado
  assert.equal(comp.encuentros[0].eliminatoria, true);
  assert.equal(comp.encuentros[0].resultado, null); // aún no está decidido
  assert.deepEqual(comp.combates[0].encuentro, { id: comp.encuentros[0].id, posicion: 1, desempate: false });
  assert.equal(comp.combates[0].shiro.club, "Zaragoza"); // club = nombre del equipo (recortado al guardar)

  s = aplicarAccion(jugarYGuardar(e.registro, s, "aka"), SIGUIENTE);
  s = jugarYGuardar(e.registro, s, "empate"); // 1-1 y 2-2: empate total en eliminatoria
  datos = leer(path.join(e.carpeta, archivo));
  comp = datos.competiciones[0];
  assert.equal(comp.encuentros.length, 1); // el mismo encuentro, actualizado, no duplicado
  assert.equal(comp.encuentros[0].resultado, null); // pendiente de desempate

  // combate de desempate
  s = aplicarAccion(s, SIGUIENTE);
  s = jugarYGuardar(e.registro, s, "aka");
  datos = leer(path.join(e.carpeta, archivo));
  comprobarEsquema(datos);
  comp = datos.competiciones[0];
  assert.equal(comp.combates.length, 4);
  assert.deepEqual(comp.combates.map((c) => [c.encuentro.posicion, c.encuentro.desempate]), [[1, false], [2, false], [3, false], [4, true]]);
  assert.deepEqual(comp.encuentros[0].resultado, { ganador: "aka", motivo: "desempate" });
  assert.equal(comp.combates[3].encho, true);
  e.registro.cerrar();
});

test("Reabrir y finalizar de nuevo un combate de equipos no duplica el combate ni el encuentro", () => {
  const e = entorno();
  const { archivo } = e.registro.nuevo({ nombre: "Copa" });
  let s = inicioEncuentro(3, false);
  s = aplicarAccion(jugarYGuardar(e.registro, s, "shiro"), SIGUIENTE);
  s = aplicarAccion(jugarYGuardar(e.registro, s, "shiro"), SIGUIENTE);
  s = jugarYGuardar(e.registro, s, "shiro");
  let comp = leer(path.join(e.carpeta, archivo)).competiciones[0];
  assert.deepEqual(comp.encuentros[0].resultado, { ganador: "shiro", motivo: "victorias" });

  // corrección del último: reabrir, deshacer un punto (queda 1-0 al tiempo) y finalizar
  s = aplicar(s, { tipo: "REABRIR_COMBATE" }, { tipo: "DESHACER" }, FIN);
  e.registro.guardarCombate(s);
  comp = leer(path.join(e.carpeta, archivo)).competiciones[0];
  assert.equal(comp.combates.length, 3);
  assert.equal(comp.encuentros.length, 1);
  assert.deepEqual(comp.combates[2].resultado, { ganador: "shiro", tipo: "puntos", motivo: "tiempo" });
  assert.deepEqual(comp.encuentros[0].resultado, { ganador: "shiro", motivo: "victorias" });
  e.registro.cerrar();
});

test("Encuentros de 3 y de 5 integrantes van a competiciones distintas; los combates sueltos, a la suya", () => {
  const e = entorno();
  const { archivo } = e.registro.nuevo({ nombre: "Copa" });
  jugarYGuardar(e.registro, inicioEncuentro(3, false), "shiro");
  jugarYGuardar(e.registro, inicioEncuentro(5, false), "aka");
  e.registro.guardarCombate(combateFinalizado()); // un individual
  const datos = leer(path.join(e.carpeta, archivo));
  comprobarEsquema(datos);
  assert.equal(datos.competiciones.length, 3);
  const por = (n) => datos.competiciones.find((c) => c.integrantesEquipo === n);
  assert.equal(por(3).combates.length, 1);
  assert.equal(por(5).combates.length, 1);
  const suelta = por(null);
  assert.equal(suelta.modalidad.opcion, "individual");
  assert.deepEqual(suelta.encuentros, []);
  assert.equal(suelta.combates[0].encuentro, null);
  e.registro.cerrar();
});
