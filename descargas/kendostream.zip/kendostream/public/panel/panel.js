// panel.js — lógica del panel de control del operador
// KendoSTREAM — © 2026 Jorge Pascual Lansac. Distribuido bajo PolyForm
// Noncommercial License 1.0.0 — ver LICENSE.txt en la raíz del proyecto.

const ICONOS = { men: "M", kote: "K", do: "D", tsuki: "T", ippon: "IP", tecnico: "★" };

let ws;
let estadoActual = null;
let escribiendoEnCampo = false; // evita que el render pise lo que el operador está tecleando
let idiomaActual = "es";
let mostrandoHantei = false; // el subpanel Hantei Blanco / Rojo / Empate está abierto
let mostrandoTecnica = false; // el subpanel de victoria técnica está abierto
let registroEstado = null; // estado del registro de resultados (lo envía el servidor)
let conectado = false; // si el panel tiene conexión con el servidor ahora mismo

function textos() {
  if (typeof TRADUCCIONES === "undefined") return {}; // i18n.js no se ha cargado: el panel sigue, sin traducir
  return TRADUCCIONES[idiomaActual] || TRADUCCIONES.es || {};
}

// --- Robustez: un fallo en una parte de la pantalla no debe dejar el panel muerto ---

// Ejecuta una parte del dibujado; si falla, lo cuenta en la consola y sigue con el resto.
function seguro(nombre, funcion) {
  try {
    funcion();
  } catch (err) {
    console.error(`KendoSTREAM: error al dibujar «${nombre}»:`, err);
  }
}

// addEventListener que no falla si el elemento no existe en el HTML.
function escuchar(id, evento, manejador) {
  const el = document.getElementById(id);
  if (!el) {
    console.error(`KendoSTREAM: falta en index.html el elemento «${id}»; su botón o campo no funcionará.`);
    return;
  }
  el.addEventListener(evento, manejador);
}

// Elementos que el panel necesita. Si falta alguno (por ejemplo, un cambio de index.html sin aplicar),
// se avisa con un banner rojo en lugar de fallar en silencio.
const ELEMENTOS_NECESARIOS = [
  "ayudaDecidido",
  "bloqueCampeonato",
  "bloqueEquipos",
  "bloqueRegistro",
  "botonDeshacer",
  "botonEncuentroCerrar",
  "botonEncuentroIniciar",
  "botonFinalizar",
  "botonHanteiCancelar",
  "botonIntercambiar",
  "botonListaCerrar",
  "botonReabrir",
  "botonRegistroContinuar",
  "botonRegistroDetener",
  "botonRegistroNuevo",
  "botonRegistroUltimo",
  "botonReiniciarMismos",
  "botonReiniciarTodo",
  "botonSiguienteCombate",
  "botonTecnica",
  "botonTecnicaCancelar",
  "botonTecnicaConfirmar",
  "categoriaOpcion",
  "categoriaTexto",
  "encho",
  "encuentroActivo",
  "encuentroCombates",
  "encuentroConfig",
  "encuentroEliminatoria",
  "encuentroIntegrantes",
  "encuentroLista",
  "encuentroResultado",
  "encuentroTitulo",
  "estadoCombate",
  "estadoConexion",
  "listaArchivos",
  "marcaAgua",
  "modalidadOpcion",
  "modalidadTexto",
  "modoEquipos",
  "panelContinuar",
  "panelHantei",
  "panelTecnica",
  "registroAviso",
  "registroIndicador",
  "tecnicaGanador",
  "tecnicaMotivo",
  "textoResultado"
];

function verificarHtml() {
  const faltan = ELEMENTOS_NECESARIOS.filter((id) => !document.getElementById(id));
  if (faltan.length === 0) return;
  console.error("KendoSTREAM: faltan elementos en index.html:", faltan.join(", "));
  const aviso = document.createElement("div");
  aviso.style = "background:#E02424;color:#fff;padding:10px 16px;text-align:center;font-weight:600;font-size:0.9rem;";
  aviso.textContent = "⚠ El index.html del panel está incompleto o dañado. Faltan estos elementos: " + faltan.join(", ") + ". Revisa los cambios de las Fases 2 y 4.";
  document.body.insertBefore(aviso, document.body.firstChild);
}

// true mientras el registro de resultados esté activo
// (entonces categoría y modalidad se muestran siempre).
function registroActivo() {
  return !!(registroEstado && registroEstado.activo);
}

// "Gana Rojo (Encho)", "Empate", "Gana Blanco (Lesión)"… en el idioma del panel
function textoResultado(resultado, t) {
  if (!resultado) return "";
  const base = resultado.ganador === "shiro" ? t.gana_blanco : resultado.ganador === "aka" ? t.gana_rojo : t.empate;
  let sufijo = "";
  if (resultado.tipo === "encho") sufijo = t.sufijo_encho;
  else if (resultado.tipo === "hantei") sufijo = t.sufijo_hantei;
  else if (resultado.tipo === "tecnica") sufijo = t["sufijo_" + resultado.motivo] || "";
  return sufijo ? `${base} ${sufijo}` : base;
}

function conectar() {
  ws = new WebSocket(`ws://${location.host}`);

  ws.onopen = () => marcarConexion(true);
  ws.onclose = () => {
    marcarConexion(false);
    setTimeout(conectar, 1500); // reintento automático si se pierde la conexión
  };
  ws.onerror = () => marcarConexion(false);

  ws.onmessage = (evento) => {
    const mensaje = JSON.parse(evento.data);
    if (mensaje.tipo === "ESTADO") {
      estadoActual = mensaje.estado;
      if (!escribiendoEnCampo) render();
    } else if (mensaje.tipo === "REGISTRO") {
      registroEstado = mensaje.registro;
      renderRegistro();
      if (estadoActual && !escribiendoEnCampo) render(); // categoría y modalidad dependen de si se registra
    }
  };
}

function marcarConexion(ok) {
  conectado = ok;
  const t = textos();
  const el = document.getElementById("estadoConexion");
  if (!el) return;
  el.removeAttribute("data-i18n"); // a partir de aquí el texto lo gestiona esta función, no aplicarIdioma()
  el.textContent = ok ? t.conectado || "conectado" : t.sin_conexion || "sin conexión";
  el.className = "estado-conexion " + (ok ? "ok" : "error");
}

function enviarAccion(accion) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ tipo: "ACCION", accion }));
  }
}

function render() {
  if (!estadoActual) return;
  const e = estadoActual;

  // Estado del combate (lo calcula el motor). Un estado sin "combate" se trata como en curso.
  const combate = e.combate || { estado: "en_curso", eventos: [], resultado: null, requiereHantei: false };
  const decidido = combate.estado === "decidido";
  const finalizado = combate.estado === "finalizado";
  const hayEventos = combate.eventos.length > 0;
  const marcadorIgualado = e.competidores.shiro.puntos.length === e.competidores.aka.puntos.length;

  idiomaActual = e.configuracion.idioma || "es";
  const t = textos();
  seguro("idioma", () => {
    // el botón de finalizar cambia de texto según el estado
    const botonFinalizar = document.getElementById("botonFinalizar");
    if (botonFinalizar) botonFinalizar.setAttribute("data-i18n", decidido ? "combate_terminado" : "fin_tiempo");
    if (typeof aplicarIdioma === "function") aplicarIdioma(idiomaActual);
    if (ws) marcarConexion(conectado); // mantiene el texto de conexión en el idioma actual
  });

  seguro("datos del torneo", () => {
    setValor("nombreTorneo", e.evento.nombreTorneo);
    setValor("infoGeneral", e.infoGeneral);
    document.getElementById("modoEquipos").checked = e.modoEquipos;
    document.getElementById("bloqueEquipos").classList.toggle("oculto", !e.modoEquipos);
    document.getElementById("modoEquipos").disabled = !!e.encuentro; // con un encuentro en curso no se apaga
    document.getElementById("marcaAgua").checked = e.configuracion.marcaAguaVisible;
    document.getElementById("encho").checked = e.encho;
    // el encho solo se activa con el marcador igualado y no se toca con el combate decidido o finalizado
    document.getElementById("encho").disabled = decidido || finalizado || (!e.encho && !marcadorIgualado);

    const modoCampeonato = e.configuracion.modoCampeonatoImportante;
    // categoría y modalidad: con Modo Campeonato, o siempre que se esté registrando
    document.getElementById("bloqueCampeonato").style.display = modoCampeonato || registroActivo() ? "flex" : "none";
    document.querySelectorAll(".campo-campeonato").forEach((el) => (el.style.display = modoCampeonato ? "flex" : "none"));

    setValor("categoriaOpcion", e.categoria.opcion);
    document.getElementById("categoriaTexto").hidden = e.categoria.opcion !== "otro";
    setValor("categoriaTexto", e.categoria.textoPersonalizado);
    setValor("modalidadOpcion", e.modalidad.opcion);
    document.getElementById("modalidadTexto").hidden = e.modalidad.opcion !== "otro";
    setValor("modalidadTexto", e.modalidad.textoPersonalizado);
  });

  seguro("botones de punto y bloqueos", () => {
    // Combate decidido o finalizado: se desactivan los botones de punto y hansoku
    // de los dos lados hasta deshacer, reabrir o reiniciar.
    document.querySelectorAll(".botones-tecnica button, .boton-hansoku").forEach((boton) => {
      boton.disabled = decidido || finalizado;
    });

    // Con el combate finalizado se bloquean los datos del combate (el motor también los ignora).
    document
      .querySelectorAll(
        ".competidor-nombre, .competidor-club, .competidor-foto, .competidor-logo, #infoGeneral, " +
          "#categoriaOpcion, #categoriaTexto, #modalidadOpcion, #modalidadTexto"
      )
      .forEach((el) => (el.disabled = finalizado));
    if (e.encuentro) {
      ["categoriaOpcion", "categoriaTexto", "modalidadOpcion", "modalidadTexto"].forEach((id) => {
        const el = document.getElementById(id);
        if (el) el.disabled = true;
      });
    }
  });

  seguro("resultado del combate", () => {
    // Botones de resultado según el estado
    document.getElementById("botonFinalizar").classList.toggle("oculto", finalizado);
    document.getElementById("botonTecnica").classList.toggle("oculto", finalizado);
    document.getElementById("botonTecnica").disabled = decidido;
    document.getElementById("botonReabrir").classList.toggle("oculto", !finalizado);
    // "Siguiente combate": con el combate finalizado. En un encuentro, tras un empate total pasa a ser el de desempate;
    // con el encuentro ya decidido no se ofrece (se cierra el encuentro).
    const enc = e.encuentro;
    const siguiente = document.getElementById("botonSiguienteCombate");
    siguiente.classList.toggle("oculto", !(finalizado && !(enc && enc.estado === "finalizado")));
    siguiente.textContent = enc && enc.estado === "pendiente_desempate" ? t.enc_desempate : t.enc_siguiente;
    document.getElementById("botonDeshacer").disabled = finalizado || !hayEventos;
    document.getElementById("botonIntercambiar").disabled = finalizado || hayEventos || !!e.encuentro;
    const esDesempate = !!(combate.encuentro && combate.encuentro.desempate);
    document.querySelectorAll('#panelHantei [data-decision="empate"]').forEach((b) => b.classList.toggle("oculto", esDesempate));

    if (!combate.requiereHantei) mostrandoHantei = false;
    if (combate.estado !== "en_curso") mostrandoTecnica = false;
    document.getElementById("panelHantei").classList.toggle("oculto", !mostrandoHantei);
    document.getElementById("panelTecnica").classList.toggle("oculto", !mostrandoTecnica);

    const pastilla = document.getElementById("estadoCombate");
    pastilla.textContent = t["estado_" + combate.estado] || "";
    pastilla.className = "estado-combate " + combate.estado;
    document.getElementById("textoResultado").textContent = finalizado ? textoResultado(combate.resultado, t) : "";
    document.getElementById("ayudaDecidido").classList.toggle("oculto", !decidido);
  });

  seguro("encuentro", () => renderEncuentro(e, t, combate));

  seguro("registro", renderRegistro);

  seguro("competidores", () => {
    ["shiro", "aka"].forEach((lado) => {
      const comp = e.competidores[lado];
      const raiz = document.querySelector(`.competidor-${lado}`);
      setValor(raiz.querySelector(".competidor-nombre"), comp.nombre);
      setValor(raiz.querySelector(".competidor-club"), comp.club);
      setValor(raiz.querySelector(".competidor-foto"), comp.foto);
      setValor(raiz.querySelector(".competidor-logo"), comp.logoClub);
      raiz.querySelector(".contador-hansoku").textContent = comp.hansoku;

      const contenedor = raiz.querySelector(".puntos-registrados");
      contenedor.innerHTML = "";
      comp.puntos.forEach((p) => {
        const span = document.createElement("span");
        let clase = "punto-icono";
        let titulo = p.tipo;
        if (p.origen === "hansoku") {
          clase += " hansoku";
          titulo = "Ippon por hansoku";
        } else if (p.tipo === "tecnico") {
          clase += " tecnico";
          titulo = t.punto_tecnico;
        }
        span.className = clase;
        span.textContent = ICONOS[p.tipo] || "?";
        span.title = titulo;
        contenedor.appendChild(span);
      });

      const editorEquipo = document.querySelector(`.equipo-editor[data-lado="${lado}"]`);
      setValor(editorEquipo.querySelector(".equipo-nombre"), e.equipos[lado].nombre);
      setValor(editorEquipo.querySelector(".equipo-victorias"), e.equipos[lado].victorias);
      setValor(editorEquipo.querySelector(".equipo-empates"), e.equipos[lado].empates);
      setValor(editorEquipo.querySelector(".equipo-ippones"), e.equipos[lado].ippones);
    });
  });
}

// --- Encuentros por equipos ---
function nombreDeEquipo(e, lado, t) {
  return (e.equipos[lado].nombre || "").trim() || (lado === "shiro" ? t.blanco_titulo : t.rojo_titulo) || lado;
}

function renderEncuentro(e, t, combate) {
  const enc = e.encuentro;
  document.getElementById("encuentroConfig").classList.toggle("oculto", !!enc);
  document.getElementById("encuentroActivo").classList.toggle("oculto", !enc);
  document.getElementById("encuentroCombates").classList.toggle("oculto", !enc);
  // con un encuentro en curso los contadores se calculan solos
  document
    .querySelectorAll(".equipo-victorias, .equipo-empates, .equipo-ippones")
    .forEach((el) => (el.disabled = !!enc));
  if (!enc) return;

  const ref = combate.encuentro;
  const modo = enc.eliminatoria ? t.enc_eliminatoria : t.enc_grupos;
  document.getElementById("encuentroTitulo").textContent =
    `${nombreDeEquipo(e, "shiro", t)} vs ${nombreDeEquipo(e, "aka", t)} · ${enc.integrantes} ${t.enc_integrantes_corto} · ${modo}`;

  // lista de combates: una fila por combate, con quién combatió y el marcador
  const lista = document.getElementById("encuentroLista");
  lista.innerHTML = "";
  const nombre = (n) => ((n || "").trim() || "—");
  const sufijoDe = (c) => {
    if (c.tipo === "encho") return t.sufijo_encho || "";
    if (c.tipo === "hantei") return t.sufijo_hantei || "";
    if (c.tipo === "tecnica") return t["sufijo_" + c.motivo] || "";
    if (c.tipo === "empate" || c.ganador === "empate") return t.empate || "";
    return "";
  };
  const celda = (clase, texto) => {
    const span = document.createElement("span");
    span.className = clase;
    span.textContent = texto;
    return span;
  };
  // datos: { etiqueta, shiro, aka, marcador, ganador, nota, estado: 'jugado'|'actual'|'pendiente' }
  const fila = (d) => {
    const div = document.createElement("div");
    div.className = "fila-combate " + d.estado;
    div.appendChild(celda("pos", d.etiqueta));
    div.appendChild(celda("nom nom-shiro" + (d.ganador === "shiro" ? " gana" : ""), d.shiro));
    div.appendChild(celda("marcador", d.marcador));
    div.appendChild(celda("nom nom-aka" + (d.ganador === "aka" ? " gana" : ""), d.aka));
    div.appendChild(celda("nota", d.nota));
    lista.appendChild(div);
  };
  const deEntrada = (c, etiqueta, actual) => ({
    etiqueta,
    shiro: nombre(c.nombres && c.nombres.shiro),
    aka: nombre(c.nombres && c.nombres.aka),
    marcador: `${c.ippones.shiro} – ${c.ippones.aka}`,
    ganador: c.ganador,
    nota: sufijoDe(c),
    estado: actual ? "actual" : "jugado"
  });
  // el combate que se está jugando ahora (aún sin finalizar): nombres y marcador en directo
  const enCurso = (etiqueta) => ({
    etiqueta,
    shiro: nombre(e.competidores.shiro.nombre),
    aka: nombre(e.competidores.aka.nombre),
    marcador: `${e.competidores.shiro.puntos.length} – ${e.competidores.aka.puntos.length}`,
    ganador: null,
    nota: t.enc_en_curso,
    estado: "actual"
  });

  for (let pos = 1; pos <= enc.integrantes; pos++) {
    const entrada = enc.combates.find((c) => !c.desempate && c.posicion === pos);
    const actual = !!(ref && !ref.desempate && ref.posicion === pos);
    if (entrada) fila(deEntrada(entrada, String(pos), actual));
    else if (actual) fila(enCurso(String(pos)));
    else fila({ etiqueta: String(pos), shiro: "—", aka: "—", marcador: "", ganador: null, nota: "", estado: "pendiente" });
  }
  const desempate = enc.combates.find((c) => c.desempate);
  const desempateActual = !!(ref && ref.desempate);
  if (desempate) fila(deEntrada(desempate, t.enc_fila_desempate, desempateActual));
  else if (desempateActual) fila(enCurso(t.enc_fila_desempate));

  // resultado del encuentro
  const resultado = document.getElementById("encuentroResultado");
  if (enc.estado === "finalizado" && enc.resultado) {
    if (enc.resultado.ganador === "empate") resultado.textContent = t.enc_empatado;
    else {
      const equipo = nombreDeEquipo(e, enc.resultado.ganador, t);
      resultado.textContent = `${plantilla(t.enc_gana, { equipo })} ${t["enc_motivo_" + enc.resultado.motivo] || ""}`.trim();
    }
  } else if (enc.estado === "pendiente_desempate") {
    resultado.textContent = t.enc_necesita_desempate;
  } else {
    resultado.textContent = "";
  }
}

// --- Registro de resultados ---
function plantilla(texto, valores) {
  if (typeof texto !== "string") return ""; // texto que falta en i18n.js: no se rompe el botón (ver verificarTextos)
  return Object.keys(valores).reduce((t, k) => t.split("{" + k + "}").join(valores[k]), texto);
}

function mensajeDeError(respuesta) {
  const t = textos();
  return t["reg_err_" + respuesta.codigo] || respuesta.mensaje || t.reg_err_generico;
}

async function llamarApi(url, metodo, cuerpo) {
  try {
    const respuesta = await fetch(url, {
      method: metodo || "GET",
      headers: cuerpo ? { "Content-Type": "application/json" } : undefined,
      body: cuerpo ? JSON.stringify(cuerpo) : undefined
    });
    return await respuesta.json();
  } catch (err) {
    return { ok: false, codigo: "red", mensaje: err.message };
  }
}

function renderRegistro() {
  if (!document.getElementById("registroIndicador")) return; // el HTML no tiene el bloque de registro
  const t = textos();
  const r = registroEstado;
  const activo = registroActivo();

  const indicador = document.getElementById("registroIndicador");
  if (activo) {
    const palabra = r.combates === 1 ? t.reg_combate : t.reg_combates;
    indicador.textContent = `● ${t.reg_registrando} · ${r.combates} ${palabra} · ${r.archivo}`;
    indicador.className = "registro-indicador registrando";
    indicador.removeAttribute("data-i18n");
  } else {
    indicador.textContent = t.reg_apagado;
    indicador.className = "registro-indicador apagado";
    indicador.setAttribute("data-i18n", "reg_apagado");
  }
  document.getElementById("bloqueRegistro").classList.toggle("registrando", activo);

  document.getElementById("botonRegistroNuevo").classList.toggle("oculto", activo);
  document.getElementById("botonRegistroContinuar").classList.toggle("oculto", activo);
  document.getElementById("botonRegistroDetener").classList.toggle("oculto", !activo);

  const ultimo = document.getElementById("botonRegistroUltimo");
  const hayUltimo = !activo && !!(r && r.ultimo);
  ultimo.classList.toggle("oculto", !hayUltimo);
  if (hayUltimo) ultimo.textContent = `${t.reg_ultimo} ${r.ultimo.archivo}`;

  // aviso rojo si no se puede guardar
  const aviso = document.getElementById("registroAviso");
  if (activo && r.error) {
    const detalle = t["reg_err_" + r.error.codigo] || r.error.mensaje;
    aviso.textContent = `${t.reg_aviso_error} ${detalle} ${plantilla(t.reg_aviso_pendientes, { n: r.pendientes })}`;
    aviso.classList.remove("oculto");
  } else {
    aviso.classList.add("oculto");
  }
  if (activo) document.getElementById("panelContinuar").classList.add("oculto");
}

async function abrirListaArchivos() {
  const panel = document.getElementById("panelContinuar");
  if (!panel.classList.contains("oculto")) {
    panel.classList.add("oculto");
    return;
  }
  const t = textos();
  const respuesta = await llamarApi("/api/registro/archivos");
  const lista = document.getElementById("listaArchivos");
  lista.innerHTML = "";
  const archivos = respuesta.archivos || [];
  if (archivos.length === 0) {
    const vacio = document.createElement("div");
    vacio.className = "fila-detalle";
    vacio.textContent = t.reg_sin_archivos;
    lista.appendChild(vacio);
  }
  archivos.forEach((a) => {
    const boton = document.createElement("button");
    const nombre = document.createElement("span");
    nombre.textContent = a.archivo; // textContent: el contenido del archivo nunca se interpreta como HTML
    boton.appendChild(nombre);

    if (a.ok) {
      const detalle = document.createElement("span");
      detalle.className = "fila-detalle";
      const palabra = a.combates === 1 ? t.reg_combate : t.reg_combates;
      detalle.textContent = [a.evento, a.fecha, `${a.combates} ${palabra}`].filter(Boolean).join(" · ");
      boton.appendChild(detalle);
    }
    let etiqueta = "";
    if (!a.ok) etiqueta = t["reg_" + a.codigo] || t.reg_ilegible;
    else if (a.enUso) etiqueta = t.reg_en_uso;
    else if (a.actual) etiqueta = t.reg_actual;
    if (etiqueta) {
      const marca = document.createElement("span");
      marca.className = "fila-etiqueta";
      marca.textContent = etiqueta;
      boton.appendChild(marca);
    }
    boton.disabled = !a.ok || a.enUso || a.actual;
    boton.addEventListener("click", () => continuarRegistro({ archivo: a.archivo }));
    lista.appendChild(boton);
  });
  panel.classList.remove("oculto");
}

async function continuarRegistro(cuerpo) {
  const respuesta = await llamarApi("/api/registro/continuar", "POST", cuerpo);
  if (!respuesta.ok) {
    alert(mensajeDeError(respuesta));
    return;
  }
  document.getElementById("panelContinuar").classList.add("oculto");
}

escuchar("botonRegistroNuevo", "click", async () => {
  const t = textos();
  const nombre = ((estadoActual && estadoActual.evento.nombreTorneo) || "").trim();
  if (!nombre) {
    alert(t.reg_falta_nombre);
    return;
  }
  if (!confirm(plantilla(t.reg_confirmar_nuevo, { nombre }))) return;
  const respuesta = await llamarApi("/api/registro/nuevo", "POST", {});
  if (!respuesta.ok) alert(mensajeDeError(respuesta));
});

escuchar("botonRegistroContinuar", "click", abrirListaArchivos);
escuchar("botonListaCerrar", "click", () => {
  document.getElementById("panelContinuar").classList.add("oculto");
});
escuchar("botonRegistroUltimo", "click", () => continuarRegistro({ ultimo: true }));

escuchar("botonRegistroDetener", "click", async () => {
  const t = textos();
  const pendientes = registroEstado ? registroEstado.pendientes : 0;
  const mensaje = pendientes > 0 ? plantilla(t.reg_confirmar_detener_pendientes, { n: pendientes }) : t.reg_confirmar_detener;
  if (!confirm(mensaje)) return;
  const respuesta = await llamarApi("/api/registro/detener", "POST", {});
  if (!respuesta.ok) alert(mensajeDeError(respuesta));
});

// Al cerrar o recargar la pestaña con un combate sin finalizar (y registrando), el navegador avisa.
window.addEventListener("beforeunload", (evento) => {
  const c = estadoActual && estadoActual.combate;
  if (registroActivo() && c && c.eventos.length > 0 && c.estado !== "finalizado") {
    evento.preventDefault();
    evento.returnValue = "";
  }
});

function setValor(idOrEl, valor) {
  const el = typeof idOrEl === "string" ? document.getElementById(idOrEl) : idOrEl;
  if (!el) return; // elemento ausente en el HTML: se ignora
  if (document.activeElement !== el) el.value = valor ?? "";
}

// --- Listas de fotos y logos disponibles (las coloca el organizador en las
// carpetas public/fotos-competidores/ y public/logos-clubes/) ---
async function cargarListasDeArchivos() {
  try {
    const [fotos, logos] = await Promise.all([
      fetch("/api/fotos-competidores").then((r) => r.json()),
      fetch("/api/logos-clubes").then((r) => r.json())
    ]);
    document.querySelectorAll(".competidor-foto").forEach((select) => rellenarOpciones(select, fotos));
    document.querySelectorAll(".competidor-logo").forEach((select) => rellenarOpciones(select, logos));
    if (estadoActual) render(); // vuelve a marcar el valor seleccionado ahora que ya hay opciones
  } catch (err) {
    console.error("No se pudieron cargar las listas de fotos/logos:", err.message);
  }
}

function rellenarOpciones(select, archivos) {
  const valorActual = select.value;
  const primeraOpcion = select.querySelector("option[value='']");
  select.innerHTML = "";
  if (primeraOpcion) select.appendChild(primeraOpcion);
  archivos.forEach((archivo) => {
    const opcion = document.createElement("option");
    opcion.value = archivo;
    opcion.textContent = archivo;
    select.appendChild(opcion);
  });
  select.value = valorActual;
}

// --- Listeners de botones de puntos y hansoku ---
document.querySelectorAll(".botones-tecnica button").forEach((boton) => {
  boton.addEventListener("click", () => {
    const lado = boton.closest(".competidor").dataset.lado;
    enviarAccion({ tipo: "PUNTO", lado, tecnica: boton.dataset.tecnica });
  });
});

document.querySelectorAll(".boton-hansoku").forEach((boton) => {
  boton.addEventListener("click", () => {
    enviarAccion({ tipo: "HANSOKU", lado: boton.dataset.lado });
  });
});

// --- Controles generales ---
escuchar("botonDeshacer", "click", () => {
  enviarAccion({ tipo: "DESHACER" });
});

escuchar("botonIntercambiar", "click", () => {
  if (confirm(textos().confirmar_intercambiar)) {
    enviarAccion({ tipo: "INTERCAMBIAR_COMPETIDORES" });
  }
});

// Reiniciar pide confirmación; si el combate tiene eventos y no está finalizado, avisa de que no se guardará.
function confirmarReinicio(clave) {
  const t = textos();
  let mensaje = t[clave];
  const c = estadoActual && estadoActual.combate;
  if (c && c.eventos.length > 0 && c.estado !== "finalizado") mensaje += "\n\n" + t.aviso_sin_finalizar;
  return confirm(mensaje);
}

escuchar("botonReiniciarMismos", "click", () => {
  if (confirmarReinicio("confirmar_reiniciar_mismos")) {
    enviarAccion({ tipo: "REINICIAR_COMBATE", mantenerCompetidores: true });
  }
});

escuchar("botonReiniciarTodo", "click", () => {
  if (confirmarReinicio("confirmar_reiniciar_todo")) {
    enviarAccion({ tipo: "REINICIAR_COMBATE", mantenerCompetidores: false });
  }
});

// --- Encuentros por equipos ---
escuchar("botonEncuentroIniciar", "click", () => {
  const t = textos();
  const e = estadoActual;
  if (!e) return;
  const a = (e.equipos.shiro.nombre || "").trim();
  const b = (e.equipos.aka.nombre || "").trim();
  if (!a || !b) {
    alert(t.enc_falta_nombres);
    return;
  }
  const c = e.combate;
  if (c && c.eventos.length > 0 && c.estado !== "finalizado") {
    alert(t.enc_combate_en_curso);
    return;
  }
  const integrantes = Number(document.getElementById("encuentroIntegrantes").value);
  if (!confirm(plantilla(t.enc_confirmar_iniciar, { n: integrantes, a, b }))) return;
  enviarAccion({
    tipo: "INICIAR_ENCUENTRO",
    integrantes,
    eliminatoria: document.getElementById("encuentroEliminatoria").checked
  });
});


escuchar("botonEncuentroCerrar", "click", () => {
  const t = textos();
  const c = estadoActual && estadoActual.combate;
  let mensaje = t.enc_confirmar_cerrar;
  if (c && c.eventos.length > 0 && c.estado !== "finalizado") mensaje += "\n\n" + t.aviso_sin_finalizar;
  if (confirm(mensaje)) enviarAccion({ tipo: "CERRAR_ENCUENTRO" });
});

// --- Resultado del combate ---
// "Fin de tiempo" / "Combate terminado": con encho agotado y marcador igualado
// abre la pregunta Hantei Blanco / Hantei Rojo / Empate; si no, finaliza directamente.
escuchar("botonFinalizar", "click", () => {
  const c = estadoActual && estadoActual.combate;
  if (c && c.requiereHantei) {
    mostrandoHantei = !mostrandoHantei;
    mostrandoTecnica = false;
    render();
  } else {
    enviarAccion({ tipo: "FINALIZAR_COMBATE" });
  }
});

document.querySelectorAll("#panelHantei [data-decision]").forEach((boton) => {
  boton.addEventListener("click", () => {
    mostrandoHantei = false;
    enviarAccion({ tipo: "FINALIZAR_COMBATE", decision: boton.dataset.decision });
  });
});

escuchar("botonHanteiCancelar", "click", () => {
  mostrandoHantei = false;
  render();
});

escuchar("botonTecnica", "click", () => {
  mostrandoTecnica = !mostrandoTecnica;
  mostrandoHantei = false;
  render();
});

escuchar("botonTecnicaConfirmar", "click", () => {
  mostrandoTecnica = false;
  enviarAccion({
    tipo: "VICTORIA_TECNICA",
    ganador: document.getElementById("tecnicaGanador").value,
    motivo: document.getElementById("tecnicaMotivo").value
  });
});

escuchar("botonTecnicaCancelar", "click", () => {
  mostrandoTecnica = false;
  render();
});

escuchar("botonSiguienteCombate", "click", () => enviarAccion({ tipo: "SIGUIENTE_COMBATE" }));

escuchar("botonReabrir", "click", () => {
  enviarAccion({ tipo: "REABRIR_COMBATE" });
});

// --- Campos de texto / edición en tiempo real ---
function conectarCampoTexto(id, construirAccion) {
  const el = document.getElementById(id);
  if (!el) return;
  el.addEventListener("focus", () => (escribiendoEnCampo = true));
  el.addEventListener("blur", () => (escribiendoEnCampo = false));
  el.addEventListener("input", () => enviarAccion(construirAccion(el.value)));
}

conectarCampoTexto("nombreTorneo", (valor) => ({ tipo: "EDITAR_NOMBRE_TORNEO", valor }));
conectarCampoTexto("infoGeneral", (valor) => ({ tipo: "EDITAR_INFO_GENERAL", valor }));

escuchar("modoEquipos", "change", () => {
  enviarAccion({ tipo: "TOGGLE_MODO_EQUIPOS" });
});

escuchar("marcaAgua", "change", () => {
  enviarAccion({ tipo: "TOGGLE_MARCA_AGUA" });
});

escuchar("encho", "change", () => {
  enviarAccion({ tipo: "TOGGLE_ENCHO" });
});

function enviarCategoria() {
  enviarAccion({
    tipo: "CAMBIAR_CATEGORIA",
    opcion: document.getElementById("categoriaOpcion").value,
    textoPersonalizado: document.getElementById("categoriaTexto").value
  });
}
function enviarModalidad() {
  enviarAccion({
    tipo: "CAMBIAR_MODALIDAD",
    opcion: document.getElementById("modalidadOpcion").value,
    textoPersonalizado: document.getElementById("modalidadTexto").value
  });
}
escuchar("categoriaOpcion", "change", enviarCategoria);
escuchar("categoriaTexto", "focus", () => (escribiendoEnCampo = true));
escuchar("categoriaTexto", "blur", () => (escribiendoEnCampo = false));
escuchar("categoriaTexto", "input", enviarCategoria);
escuchar("modalidadOpcion", "change", enviarModalidad);
escuchar("modalidadTexto", "focus", () => (escribiendoEnCampo = true));
escuchar("modalidadTexto", "blur", () => (escribiendoEnCampo = false));
escuchar("modalidadTexto", "input", enviarModalidad);

["shiro", "aka"].forEach((lado) => {
  const raiz = document.querySelector(`.competidor-${lado}`);
  const nombreEl = raiz.querySelector(".competidor-nombre");
  const clubEl = raiz.querySelector(".competidor-club");

  [nombreEl, clubEl].forEach((el) => {
    el.addEventListener("focus", () => (escribiendoEnCampo = true));
    el.addEventListener("blur", () => (escribiendoEnCampo = false));
  });

  nombreEl.addEventListener("input", () =>
    enviarAccion({ tipo: "EDITAR_COMPETIDOR", lado, campo: "nombre", valor: nombreEl.value })
  );
  clubEl.addEventListener("input", () =>
    enviarAccion({ tipo: "EDITAR_COMPETIDOR", lado, campo: "club", valor: clubEl.value })
  );

  const fotoEl = raiz.querySelector(".competidor-foto");
  fotoEl.addEventListener("change", () =>
    enviarAccion({ tipo: "CAMBIAR_FOTO_COMPETIDOR", lado, archivo: fotoEl.value })
  );
  const logoEl = raiz.querySelector(".competidor-logo");
  logoEl.addEventListener("change", () =>
    enviarAccion({ tipo: "CAMBIAR_LOGO_CLUB", lado, archivo: logoEl.value })
  );

  const editorEquipo = document.querySelector(`.equipo-editor[data-lado="${lado}"]`);
  const campoEquipo = {
    ".equipo-nombre": "nombre",
    ".equipo-victorias": "victorias",
    ".equipo-empates": "empates",
    ".equipo-ippones": "ippones"
  };
  Object.entries(campoEquipo).forEach(([selector, campo]) => {
    const el = editorEquipo.querySelector(selector);
    el.addEventListener("focus", () => (escribiendoEnCampo = true));
    el.addEventListener("blur", () => (escribiendoEnCampo = false));
    el.addEventListener("input", () =>
      enviarAccion({ tipo: "EDITAR_EQUIPO", lado, campo, valor: el.value })
    );
  });
});

// --- Atajos de teclado ---
const TECLA_A_ACCION = {
  q: { tipo: "PUNTO", lado: "shiro", tecnica: "men" },
  w: { tipo: "PUNTO", lado: "shiro", tecnica: "kote" },
  e: { tipo: "PUNTO", lado: "shiro", tecnica: "do" },
  r: { tipo: "PUNTO", lado: "shiro", tecnica: "tsuki" },
  a: { tipo: "HANSOKU", lado: "shiro" },
  u: { tipo: "PUNTO", lado: "aka", tecnica: "men" },
  i: { tipo: "PUNTO", lado: "aka", tecnica: "kote" },
  o: { tipo: "PUNTO", lado: "aka", tecnica: "do" },
  p: { tipo: "PUNTO", lado: "aka", tecnica: "tsuki" },
  l: { tipo: "HANSOKU", lado: "aka" },
  z: { tipo: "DESHACER" }
};

document.addEventListener("keydown", (evento) => {
  // no interceptar teclas mientras se escribe en un campo de texto
  const escribiendo = ["INPUT", "TEXTAREA"].includes(document.activeElement.tagName);
  if (escribiendo) return;

  const accion = TECLA_A_ACCION[evento.key.toLowerCase()];
  if (accion) {
    evento.preventDefault();
    enviarAccion(accion);
  }
});

async function comprobarActualizacion() {
  try {
    const info = await fetch("/api/version").then((r) => r.json());
    if (info.hayNueva) {
      const aviso = document.createElement("div");
      aviso.style = "background:#f0a020;color:#161b22;padding:8px 16px;text-align:center;font-weight:600;font-size:0.85rem;";
      aviso.innerHTML = `Hay una versión nueva de KendoSTREAM disponible (${info.disponible}) — <a href="${info.url}" target="_blank" style="color:#161b22;">ver novedades</a>`;
      document.body.insertBefore(aviso, document.body.firstChild);
    }
  } catch (err) { /* sin conexión, no pasa nada */ }
}

// Textos que el panel necesita en i18n.js (español e inglés). Si falta alguno, se avisa en rojo.
const TEXTOS_NECESARIOS = [
  "aviso_sin_finalizar",
  "ayuda_decidido",
  "blanco_titulo",
  "cancelar",
  "cat_femenino",
  "cat_junior",
  "cat_masculino",
  "cat_otro",
  "categoria_label",
  "categoria_texto_placeholder",
  "club_placeholder",
  "conectado",
  "conectando",
  "config_enlace",
  "confirmar",
  "deshacer",
  "empate",
  "empates",
  "enc_cerrar",
  "enc_combate_en_curso",
  "enc_confirmar_cerrar",
  "enc_confirmar_iniciar",
  "enc_desempate",
  "enc_eliminatoria",
  "enc_empatado",
  "enc_en_curso",
  "enc_falta_nombres",
  "enc_fila_desempate",
  "enc_gana",
  "enc_grupos",
  "enc_iniciar",
  "enc_integrantes",
  "enc_integrantes_corto",
  "enc_necesita_desempate",
  "enc_siguiente",
  "encho",
  "equipo_blanco_titulo",
  "equipo_nombre_placeholder",
  "equipo_rojo_titulo",
  "fin_tiempo",
  "foto_label",
  "foto_sin",
  "gana_blanco",
  "gana_rojo",
  "hansoku_boton",
  "hantei_blanco",
  "hantei_pregunta",
  "hantei_rojo",
  "info_general_label",
  "info_general_placeholder",
  "intercambiar",
  "ippones",
  "logo_label",
  "logo_sin",
  "marca_agua",
  "mod_equipos",
  "mod_individual",
  "mod_otro",
  "modalidad_label",
  "modalidad_texto_placeholder",
  "modo_equipos",
  "motivo_descalificacion",
  "motivo_incomparecencia",
  "motivo_lesion",
  "motivo_otro",
  "nombre_placeholder",
  "organizador_enlace",
  "punto_tecnico",
  "reabrir",
  "reg_actual",
  "reg_apagado",
  "reg_aviso_error",
  "reg_aviso_pendientes",
  "reg_cerrar_lista",
  "reg_combate",
  "reg_combates",
  "reg_confirmar_detener",
  "reg_confirmar_detener_pendientes",
  "reg_confirmar_nuevo",
  "reg_continuar",
  "reg_detener",
  "reg_elegir",
  "reg_en_uso",
  "reg_err_generico",
  "reg_falta_nombre",
  "reg_ilegible",
  "reg_nuevo",
  "reg_registrando",
  "reg_sin_archivos",
  "reg_ultimo",
  "reiniciar_mismos",
  "reiniciar_todo",
  "rojo_titulo",
  "sin_conexion",
  "sufijo_encho",
  "sufijo_hantei",
  "tecnica_ganador",
  "tecnica_motivo",
  "torneo_label",
  "torneo_placeholder",
  "victoria_tecnica",
  "victorias"
];

function verificarTextos() {
  if (typeof TRADUCCIONES === "undefined") return;
  const faltan = [];
  ["es", "en"].forEach((idioma) => {
    const tabla = TRADUCCIONES[idioma] || {};
    TEXTOS_NECESARIOS.forEach((clave) => {
      if (tabla[clave] === undefined) faltan.push(idioma + ":" + clave);
    });
  });
  if (faltan.length === 0) return;
  console.error("KendoSTREAM: faltan textos en i18n.js:", faltan.join(", "));
  const aviso = document.createElement("div");
  aviso.style = "background:#E02424;color:#fff;padding:10px 16px;text-align:center;font-weight:600;font-size:0.9rem;";
  aviso.textContent = "⚠ Al archivo i18n.js del panel le faltan textos (" + faltan.length + "), así que algunos botones no funcionarán bien. Sustitúyelo por la versión de la Fase 5. Faltan, por ejemplo: " + faltan.slice(0, 6).join(", ") + (faltan.length > 6 ? "…" : "");
  document.body.insertBefore(aviso, document.body.firstChild);
}

verificarHtml();
verificarTextos();
comprobarActualizacion();
conectar();
cargarListasDeArchivos();
