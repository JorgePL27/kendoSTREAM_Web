// motor.js
// KendoSTREAM — © 2026 Jorge Pascual Lansac. Distribuido bajo PolyForm
// Noncommercial License 1.0.0 — ver LICENSE.txt en la raíz del proyecto.
//
// Lógica pura del combate. No sabe nada de red, WebSockets ni ficheros:
// solo recibe un estado y una acción, y devuelve el nuevo estado.
// Esto hace que sea fácil de testear y de razonar sobre ella.

function estadoInicial() {
  return {
    version: 1,
    evento: {
      nombreTorneo: "",
      logo: ""
    },
    infoGeneral: "",
    encho: false, // true cuando el combate está en Encho / Prórroga
    modoEquipos: false,
    categoria: { opcion: "masculino", textoPersonalizado: "" }, // opcion: 'masculino'|'femenino'|'junior'|'otro'
    modalidad: { opcion: "individual", textoPersonalizado: "" }, // opcion: 'individual'|'equipos'|'otro'
    configuracion: {
      disenoMarcador: "clasico", // identificador del diseño de overlay activo
      marcaAguaVisible: false,
      modoCampeonatoImportante: false, // activa categoría/modalidad arriba, fotos y logos de club
      idioma: "es" // idioma de la INTERFAZ DEL PANEL únicamente ('es'|'en'); el overlay no se traduce
    },
    equipos: {
      shiro: { nombre: "", victorias: 0, empates: 0, ippones: 0 },
      aka: { nombre: "", victorias: 0, empates: 0, ippones: 0 }
    },
    competidores: {
      shiro: crearCompetidorVacio(),
      aka: crearCompetidorVacio()
    }
  };
}

function crearCompetidorVacio() {
  return {
    nombre: "",
    club: "",
    puntos: [], // { tipo: 'men'|'kote'|'do'|'tsuki', origen: 'tecnica' } o { tipo:'ippon', origen:'hansoku' }
    hansoku: 0,
    foto: "", // nombre de archivo dentro de public/fotos-competidores/
    logoClub: "" // nombre de archivo dentro de public/logos-clubes/
  };
}

// Un combate termina al primer competidor que llegue a 2 puntos (ippon):
// a partir de ahí no se pueden anotar más puntos a ninguno de los dos lados.
function combateDecidido(estado) {
  return estado.competidores.shiro.puntos.length >= 2 || estado.competidores.aka.puntos.length >= 2;
}

// clona profundamente el estado (evita mutaciones accidentales compartidas)
function clonar(estado) {
  return JSON.parse(JSON.stringify(estado));
}

/**
 * Aplica una acción sobre el estado actual y devuelve el nuevo estado.
 * No modifica el estado recibido.
 *
 * Tipos de acción soportados:
 *  - PUNTO            { lado: 'shiro'|'aka', tecnica: 'men'|'kote'|'do'|'tsuki' }
 *  - HANSOKU          { lado }
 *  - QUITAR_ULTIMO_PUNTO   { lado }  (utilidad interna para deshacer manual si hiciera falta)
 *  - REINICIAR_COMBATE     { mantenerCompetidores: boolean }
 *  - INTERCAMBIAR_COMPETIDORES
 *  - EDITAR_COMPETIDOR     { lado, campo: 'nombre'|'club', valor }
 *  - EDITAR_INFO_GENERAL   { valor }
 *  - EDITAR_NOMBRE_TORNEO  { valor }
 *  - TOGGLE_MODO_EQUIPOS
 *  - EDITAR_EQUIPO         { lado, campo: 'nombre'|'victorias'|'ippones', valor }
 *  - CAMBIAR_DISENO_MARCADOR   { valor: identificador del diseño de overlay }
 *  - TOGGLE_MARCA_AGUA
 *  - TOGGLE_ENCHO
 *  - CAMBIAR_CATEGORIA        { opcion: 'masculino'|'femenino'|'junior'|'otro', textoPersonalizado }
 *  - CAMBIAR_MODALIDAD        { opcion: 'individual'|'equipos'|'otro', textoPersonalizado }
 *  - CAMBIAR_FOTO_COMPETIDOR  { lado, archivo: nombre de archivo en public/fotos-competidores/ }
 *  - CAMBIAR_LOGO_CLUB        { lado, archivo: nombre de archivo en public/logos-clubes/ }
 *  - TOGGLE_MODO_CAMPEONATO_IMPORTANTE
 *  - CAMBIAR_IDIOMA           { valor: 'es'|'en' — solo afecta a la interfaz del panel }
 *
 * Reglas del propio motor (no dependen de acciones externas):
 *  - Un combate se considera decidido en cuanto un competidor llega a 2 puntos;
 *    a partir de ahí, PUNTO y HANSOKU se ignoran para los dos lados hasta que
 *    se deshaga alguna acción o se reinicie el combate.
 */
function aplicarAccion(estadoActual, accion) {
  const estado = clonar(estadoActual);

  switch (accion.tipo) {
    case "PUNTO": {
      if (combateDecidido(estado)) return estado; // ya hay un competidor con 2 puntos: no se anota más
      const competidor = estado.competidores[accion.lado];
      competidor.puntos.push({ tipo: accion.tecnica, origen: "tecnica" });
      return estado;
    }

    case "HANSOKU": {
      if (combateDecidido(estado)) return estado; // combate ya decidido: no se registran más hansoku
      const lado = accion.lado;
      const rival = lado === "shiro" ? "aka" : "shiro";
      const competidor = estado.competidores[lado];
      competidor.hansoku += 1;

      // al segundo hansoku, el rival recibe un ippon automático
      if (competidor.hansoku === 2) {
        estado.competidores[rival].puntos.push({
          tipo: "ippon",
          origen: "hansoku"
        });
        competidor.hansoku = 0; // se resetea tras penalizar
      }
      return estado;
    }

    case "QUITAR_ULTIMO_PUNTO": {
      const competidor = estado.competidores[accion.lado];
      competidor.puntos.pop();
      return estado;
    }

    case "REINICIAR_COMBATE": {
      const nuevo = estadoInicial();
      nuevo.evento = estado.evento;
      nuevo.modoEquipos = estado.modoEquipos;
      nuevo.categoria = estado.categoria; // información del evento, no del combate: se mantiene
      nuevo.modalidad = estado.modalidad;
      nuevo.configuracion = estado.configuracion; // la configuración es global, no se reinicia con el combate
      nuevo.equipos = accion.mantenerCompetidores ? estado.equipos : estadoInicial().equipos;
      if (accion.mantenerCompetidores) {
        nuevo.competidores.shiro.nombre = estado.competidores.shiro.nombre;
        nuevo.competidores.shiro.club = estado.competidores.shiro.club;
        nuevo.competidores.shiro.foto = estado.competidores.shiro.foto;
        nuevo.competidores.shiro.logoClub = estado.competidores.shiro.logoClub;
        nuevo.competidores.aka.nombre = estado.competidores.aka.nombre;
        nuevo.competidores.aka.club = estado.competidores.aka.club;
        nuevo.competidores.aka.foto = estado.competidores.aka.foto;
        nuevo.competidores.aka.logoClub = estado.competidores.aka.logoClub;
      }
      return nuevo;
    }

    case "INTERCAMBIAR_COMPETIDORES": {
      const temp = estado.competidores.shiro;
      estado.competidores.shiro = estado.competidores.aka;
      estado.competidores.aka = temp;
      return estado;
    }

    case "EDITAR_COMPETIDOR": {
      estado.competidores[accion.lado][accion.campo] = accion.valor;
      return estado;
    }

    case "EDITAR_INFO_GENERAL": {
      estado.infoGeneral = accion.valor;
      return estado;
    }

    case "EDITAR_NOMBRE_TORNEO": {
      estado.evento.nombreTorneo = accion.valor;
      return estado;
    }

    case "TOGGLE_MODO_EQUIPOS": {
      estado.modoEquipos = !estado.modoEquipos;
      return estado;
    }

    case "EDITAR_EQUIPO": {
      estado.equipos[accion.lado][accion.campo] = accion.valor;
      return estado;
    }

    case "CAMBIAR_DISENO_MARCADOR": {
      estado.configuracion.disenoMarcador = accion.valor;
      return estado;
    }

    case "TOGGLE_MARCA_AGUA": {
      estado.configuracion.marcaAguaVisible = !estado.configuracion.marcaAguaVisible;
      return estado;
    }

    case "TOGGLE_ENCHO": {
      estado.encho = !estado.encho;
      return estado;
    }

    case "CAMBIAR_CATEGORIA": {
      estado.categoria = { opcion: accion.opcion, textoPersonalizado: accion.textoPersonalizado || "" };
      return estado;
    }

    case "CAMBIAR_MODALIDAD": {
      estado.modalidad = { opcion: accion.opcion, textoPersonalizado: accion.textoPersonalizado || "" };
      return estado;
    }

    case "CAMBIAR_FOTO_COMPETIDOR": {
      estado.competidores[accion.lado].foto = accion.archivo;
      return estado;
    }

    case "CAMBIAR_LOGO_CLUB": {
      estado.competidores[accion.lado].logoClub = accion.archivo;
      return estado;
    }

    case "TOGGLE_MODO_CAMPEONATO_IMPORTANTE": {
      estado.configuracion.modoCampeonatoImportante = !estado.configuracion.modoCampeonatoImportante;
      return estado;
    }

    case "CAMBIAR_IDIOMA": {
      estado.configuracion.idioma = accion.valor;
      return estado;
    }

    default:
      // acción desconocida: no se modifica el estado
      return estado;
  }
}

module.exports = { estadoInicial, aplicarAccion, clonar };
