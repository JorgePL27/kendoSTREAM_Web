# KendoSTREAM (v0.1 — esqueleto inicial)

© 2026 Jorge Pascual Lansac. Todos los derechos reservados salvo lo indicado en [LICENSE.txt](./LICENSE.txt).

Marcador y overlay de streaming para competiciones de kendo.

## Requisitos

- [Node.js](https://nodejs.org/en/download) (versión LTS)
- [OBS Studio](https://obsproject.com/download)

## Instalación

Desde una terminal, dentro de la carpeta del proyecto:

```bash
npm install
```

## Ejecución

```bash
npm start
```

Verás un mensaje como:

```
KendoSTREAM escuchando en http://localhost:3000
  Panel:   http://localhost:3000/panel
  Overlay: http://localhost:3000/overlay
```

- Abre el **panel** (`http://localhost:3000/panel`) en un navegador normal: es la interfaz que usará el operador.
- En OBS, añade una fuente **Browser Source** apuntando a `http://localhost:3000/overlay`, con fondo transparente activado.

## Estado actual (v0.1)

Ya funciona:

- Registro de puntos (Men, Kote, Do, Tsuki) por competidor.
- Gestión de Hansoku, con ippon automático al segundo hansoku.
- Edición en tiempo real de nombres, clubes e información general.
- Modo equipos (activable/desactivable).
- Deshacer última acción.
- Intercambiar competidores.
- Reiniciar combate (con o sin mantener competidores).
- Guardado automático del estado en `data/estado.json`.
- Atajos de teclado (ver tabla más abajo).
- Overlay en tiempo real vía WebSocket, compatible con OBS Browser Source.

Pendiente para siguientes iteraciones (fuera del alcance de esta primera versión, según el documento de definición):
cronómetro, gestión de pools/torneos, estadísticas, personalización avanzada (logo, etc.), empaquetado como ejecutable independiente.

## Atajos de teclado

| Tecla | Acción            |
|-------|--------------------|
| Q     | Men Blanco          |
| W     | Kote Blanco         |
| E     | Do Blanco           |
| R     | Tsuki Blanco        |
| A     | Hansoku Blanco      |
| U     | Men Rojo            |
| I     | Kote Rojo           |
| O     | Do Rojo             |
| P     | Tsuki Rojo          |
| L     | Hansoku Rojo        |
| Z     | Deshacer            |

## Estructura del proyecto

```
kendostream/
├── package.json
├── server.js            servidor Express + WebSocket
├── motor/
│   └── motor.js           lógica pura del combate
├── data/
│   └── estado.json         se genera automáticamente al arrancar
└── public/
    ├── panel/               interfaz del operador
    └── overlay/             overlay para OBS
```
