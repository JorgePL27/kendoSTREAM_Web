#!/bin/bash
echo "============================================"
echo "  Desinstalador de KendoSTREAM para Mac"
echo "============================================"
echo ""
echo "Esto elimina el icono del Escritorio y cualquier resto de"
echo "arranque automatico de versiones anteriores. NO borra la"
echo "carpeta del proyecto ni tus combates guardados."
echo ""
read -p "Pulsa Enter para continuar..."

if [ -f "$HOME/Library/LaunchAgents/com.kendostream.server.plist" ]; then
  launchctl unload "$HOME/Library/LaunchAgents/com.kendostream.server.plist" 2>/dev/null
  rm -f "$HOME/Library/LaunchAgents/com.kendostream.server.plist"
fi
rm -f "$HOME/Desktop/Abrir Panel KendoSTREAM.command"

echo ""
echo "Hecho. Si quieres tambien borrar la carpeta del proyecto,"
echo "hazlo ahora manualmente. Si el servidor sigue en marcha,"
echo "puedes cerrarlo buscando el proceso 'node' en el Monitor de Actividad."
echo ""
read -p "Pulsa Enter para cerrar..."
