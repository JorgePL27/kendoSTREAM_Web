// server.js
// KendoSTREAM — © 2026 Jorge Pascual Lansac. Distribuido bajo PolyForm
// Noncommercial License 1.0.0 — ver LICENSE.txt en la raíz del proyecto.
//
// Servidor local de KendoSTREAM.
// - Sirve el panel de control y el overlay como páginas web estáticas.
// - Mantiene el estado del combate en memoria.
// - Aplica las acciones del operador a través del motor (motor/motor.js).
// - Guarda automáticamente el estado en data/estado.json.
// - Difunde el estado actualizado a todos los clientes conectados (panel y overlay)
//   por WebSocket, para que se actualicen en tiempo real.

const path = require("path");
const fs = require("fs");
const express = require("express");
const { WebSocketServer } = require("ws");
const { estadoInicial, aplicarAccion, clonar } = require("./motor/motor");

const PUERTO = process.env.PUERTO || 3000;
const RUTA_ESTADO = path.join(__dirname, "data", "estado.json");
const LIMITE_HISTORIAL = 20; // nº de acciones que se pueden deshacer

// --- Estado en memoria ---
let estado = cargarEstadoDesdeDisco() || estadoInicial();
let historial = []; // pila de estados anteriores, para "Deshacer"

function cargarEstadoDesdeDisco() {
  try {
    const contenido = fs.readFileSync(RUTA_ESTADO, "utf-8");
    return JSON.parse(contenido);
  } catch (err) {
    return null; // no existe todavía o está corrupto: se usará el estado inicial
  }
}

function guardarEstadoEnDisco() {
  fs.mkdir(path.dirname(RUTA_ESTADO), { recursive: true }, () => {
    fs.writeFile(RUTA_ESTADO, JSON.stringify(estado, null, 2), (err) => {
      if (err) console.error("Error guardando el estado:", err.message);
    });
  });
}

function difundirEstado() {
  const mensaje = JSON.stringify({ tipo: "ESTADO", estado });
  wss.clients.forEach((cliente) => {
    if (cliente.readyState === cliente.OPEN) cliente.send(mensaje);
  });
}

// --- Express: servir el panel y el overlay ---
const app = express();
app.use(express.json());
app.use("/panel", express.static(path.join(__dirname, "public/panel")));
app.use("/overlay", express.static(path.join(__dirname, "public/overlay")));
app.use("/config", express.static(path.join(__dirname, "public/config")));
app.use("/assets", express.static(path.join(__dirname, "public/assets")));
app.use("/fotos-competidores", express.static(path.join(__dirname, "public/fotos-competidores")));
app.use("/logos-clubes", express.static(path.join(__dirname, "public/logos-clubes")));
app.get("/", (req, res) => res.redirect("/panel"));
app.use("/organizador", express.static(path.join(__dirname, "public/organizador")));
app.get("/api/torneo", (req, res) => {
  try {
    const contenido = fs.readFileSync(path.join(__dirname, "data/torneo.json"), "utf-8");
    res.json(JSON.parse(contenido));
  } catch (err) {
    res.json({ competidores: [], mostrarDan: true, cuadro: null });
  }
});
app.post("/api/torneo", (req, res) => {
  fs.mkdir(path.join(__dirname, "data"), { recursive: true }, () => {
    fs.writeFile(path.join(__dirname, "data/torneo.json"), JSON.stringify(req.body, null, 2), (err) => {
      if (err) return res.status(500).json({ error: "No se pudo guardar" });
      res.json({ ok: true });
    });
  });
});

// Extensiones de imagen admitidas al listar archivos disponibles
const EXTENSIONES_IMAGEN = [".png", ".jpg", ".jpeg", ".webp"];

function listarImagenes(carpeta) {
  try {
    return fs.readdirSync(carpeta)
      .filter((archivo) => EXTENSIONES_IMAGEN.includes(path.extname(archivo).toLowerCase()))
      .sort();
  } catch (err) {
    return []; // la carpeta no existe todavía: sin archivos disponibles
  }
}

app.get("/api/fotos-competidores", (req, res) => {
  res.json(listarImagenes(path.join(__dirname, "public/fotos-competidores")));
});

app.get("/api/logos-clubes", (req, res) => {
  res.json(listarImagenes(path.join(__dirname, "public/logos-clubes")));
});

// Diseños de overlay disponibles: se detectan automáticamente a partir de los
// archivos .css que haya en public/overlay/temas/. Así, un diseño nuevo (propio
// o personalizado para un club) solo requiere añadir el archivo ahí — no hay
// que tocar código para que aparezca en el desplegable de /config.
app.get("/api/temas", (req, res) => {
  try {
    const archivos = fs.readdirSync(path.join(__dirname, "public/overlay/temas"))
      .filter((archivo) => archivo.endsWith(".css"))
      .map((archivo) => archivo.replace(/\.css$/, ""))
      .sort();
    res.json(archivos);
  } catch (err) {
    res.json(["clasico"]); // último recurso: siempre debe existir al menos el clásico
  }
});

const servidorHttp = app.listen(PUERTO, () => {
  console.log(`KendoSTREAM escuchando en http://localhost:${PUERTO}`);
  console.log(`  Panel:   http://localhost:${PUERTO}/panel`);
  console.log(`  Overlay: http://localhost:${PUERTO}/overlay`);
});

// --- WebSocket: comunicación en tiempo real ---
const wss = new WebSocketServer({ server: servidorHttp });

wss.on("connection", (ws) => {
  // al conectar, enviamos el estado actual (panel u overlay recién abiertos)
  ws.send(JSON.stringify({ tipo: "ESTADO", estado }));

  ws.on("message", (mensajeBruto) => {
    let mensaje;
    try {
      mensaje = JSON.parse(mensajeBruto);
    } catch (err) {
      return; // mensaje mal formado, se ignora
    }

    if (mensaje.tipo === "ACCION") {
      if (mensaje.accion && mensaje.accion.tipo === "DESHACER") {
        if (historial.length > 0) {
          estado = historial.pop();
        }
      } else {
        historial.push(clonar(estado));
        if (historial.length > LIMITE_HISTORIAL) historial.shift();
        estado = aplicarAccion(estado, mensaje.accion);
      }

      guardarEstadoEnDisco();
      difundirEstado();
    }
  });
});
