// encuentros.test.js — pruebas de la Fase 5 (equipos). Se ejecutan con:  node --test

const test = require("node:test");
const assert = require("node:assert/strict");
const { estadoInicial, aplicarAccion, normalizarEstado } = require("./motor");

function aplicar(estado, ...acciones) {
  return acciones.reduce((e, a) => aplicarAccion(e, a), estado);
}
const punto = (lado, tecnica = "men") => ({ tipo: "PUNTO", lado, tecnica });
const FIN = { tipo: "FINALIZAR_COMBATE" };
const SIGUIENTE = { tipo: "SIGUIENTE_COMBATE" };
const nombre = (lado, valor) => ({ tipo: "EDITAR_EQUIPO", lado, campo: "nombre", valor });

function encuentro({ integrantes = 3, eliminatoria = false } = {}) {
  return aplicar(
    normalizarEstado(estadoInicial()),
    nombre("shiro", "Zaragoza"),
    nombre("aka", "Huesca"),
    { tipo: "INICIAR_ENCUENTRO", integrantes, eliminatoria }
  );
}

// Jugar y finalizar un combate. gana: "shiro" | "aka" | "empate"; perdedorPuntos: ippones del que pierde (0 o 1)
function jugar(estado, gana, perdedorPuntos = 0) {
  if (gana === "empate") return aplicarAccion(estado, FIN);
  const otro = gana === "shiro" ? "aka" : "shiro";
  const acciones = [];
  if (perdedorPuntos) acciones.push(punto(otro, "kote"));
  acciones.push(punto(gana, "men"), punto(gana, "do"), FIN);
  return aplicar(estado, ...acciones);
}
const marcador = (e) => ({ v: [e.equipos.shiro.victorias, e.equipos.aka.victorias], e: [e.equipos.shiro.empates, e.equipos.aka.empates], i: [e.equipos.shiro.ippones, e.equipos.aka.ippones] });

// ---------------------------------------------------------------- Iniciar

test("Iniciar encuentro: modo equipos, modalidad equipos, contadores a 0 y primer combate", () => {
  let e = aplicar(
    normalizarEstado(estadoInicial()),
    nombre("shiro", "Zaragoza"),
    nombre("aka", "Huesca"),
    { tipo: "EDITAR_EQUIPO", lado: "shiro", campo: "victorias", valor: 4 }, // restos de la edición manual
    { tipo: "INICIAR_ENCUENTRO", integrantes: 5, eliminatoria: true }
  );
  assert.equal(e.modoEquipos, true);
  assert.deepEqual(e.modalidad, { opcion: "equipos", textoPersonalizado: "" });
  assert.equal(e.encuentro.integrantes, 5);
  assert.equal(e.encuentro.eliminatoria, true);
  assert.equal(e.encuentro.estado, "en_curso");
  assert.match(e.encuentro.id, /^[0-9a-f-]{36}$/);
  assert.deepEqual(marcador(e), { v: [0, 0], e: [0, 0], i: [0, 0] });
  assert.deepEqual(e.combate.encuentro, { id: e.encuentro.id, posicion: 1, desempate: false });
  assert.equal(e.competidores.shiro.club, "Zaragoza"); // el club se rellena con el nombre del equipo
  assert.equal(e.competidores.aka.club, "Huesca");
});

test("Iniciar encuentro: solo 3 o 5 integrantes", () => {
  const base = normalizarEstado(estadoInicial());
  for (const n of [0, 1, 2, 4, 7, "x", null, undefined]) {
    assert.equal(aplicarAccion(base, { tipo: "INICIAR_ENCUENTRO", integrantes: n }).encuentro, null, `integrantes=${n}`);
  }
  assert.ok(aplicarAccion(base, { tipo: "INICIAR_ENCUENTRO", integrantes: 3 }).encuentro);
  assert.ok(aplicarAccion(base, { tipo: "INICIAR_ENCUENTRO", integrantes: "5" }).encuentro);
});

test("No se inicia un encuentro encima de un combate a medias, pero sí con uno finalizado o sin eventos", () => {
  const base = normalizarEstado(estadoInicial());
  const aMedias = aplicar(base, punto("shiro"));
  assert.equal(aplicarAccion(aMedias, { tipo: "INICIAR_ENCUENTRO", integrantes: 3 }).encuentro, null);
  const finalizado = aplicar(base, punto("shiro"), FIN);
  assert.ok(aplicarAccion(finalizado, { tipo: "INICIAR_ENCUENTRO", integrantes: 3 }).encuentro);
});

test("No se inicia un segundo encuentro mientras hay uno", () => {
  const e = encuentro();
  const otra = aplicarAccion(e, { tipo: "INICIAR_ENCUENTRO", integrantes: 5, eliminatoria: true });
  assert.equal(otra.encuentro.id, e.encuentro.id);
  assert.equal(otra.encuentro.integrantes, 3);
});

test("Si la modalidad es 'otro' con texto propio, se respeta", () => {
  const e = aplicar(
    normalizarEstado(estadoInicial()),
    { tipo: "CAMBIAR_MODALIDAD", opcion: "otro", textoPersonalizado: "Equipos mixtos" },
    { tipo: "INICIAR_ENCUENTRO", integrantes: 3 }
  );
  assert.deepEqual(e.modalidad, { opcion: "otro", textoPersonalizado: "Equipos mixtos" });
});

// ---------------------------------------------------------------- Contadores automáticos

test("Al finalizar cada combate se suman solos victorias, empates e ippones", () => {
  let e = encuentro({ integrantes: 5 });
  e = jugar(e, "shiro"); // 2 ippones para Blanco
  assert.deepEqual(marcador(e), { v: [1, 0], e: [0, 0], i: [2, 0] });
  e = aplicar(e, SIGUIENTE);
  e = jugar(e, "aka", 1); // Rojo gana 2-1
  assert.deepEqual(marcador(e), { v: [1, 1], e: [0, 0], i: [3, 2] });
  e = aplicar(e, SIGUIENTE);
  e = jugar(e, "empate");
  assert.deepEqual(marcador(e), { v: [1, 1], e: [1, 1], i: [3, 2] });
  assert.equal(e.encuentro.estado, "en_curso");
});

test("El combate finalizado cuenta ya, antes de pasar al siguiente", () => {
  let e = encuentro();
  assert.equal(e.equipos.shiro.victorias, 0);
  e = jugar(e, "aka");
  assert.equal(e.equipos.aka.victorias, 1);
});

test("Un combate a medias o decidido sin confirmar no cuenta", () => {
  let e = aplicar(encuentro(), punto("shiro"), punto("shiro", "do")); // decidido, sin finalizar
  assert.equal(e.equipos.shiro.victorias, 0);
  assert.equal(e.equipos.shiro.ippones, 0);
});

test("Hantei suma victoria con los ippones reales y la técnica cuenta como 2 ippones", () => {
  let e = encuentro({ integrantes: 5 });
  e = aplicar(e, punto("shiro"), punto("aka", "kote"), { tipo: "TOGGLE_ENCHO" }, { tipo: "FINALIZAR_COMBATE", decision: "aka" });
  assert.deepEqual(marcador(e), { v: [0, 1], e: [0, 0], i: [1, 1] }); // Hantei no añade puntos
  e = aplicar(e, SIGUIENTE, { tipo: "VICTORIA_TECNICA", ganador: "shiro", motivo: "lesion" }, FIN);
  assert.deepEqual(marcador(e), { v: [1, 1], e: [0, 0], i: [3, 1] });
});

test("Reabrir un combate retira su aportación; al finalizar de nuevo vuelve con el resultado corregido", () => {
  let e = encuentro();
  e = jugar(e, "shiro");
  assert.deepEqual(marcador(e).v, [1, 0]);
  e = aplicarAccion(e, { tipo: "REABRIR_COMBATE" });
  assert.deepEqual(marcador(e), { v: [0, 0], e: [0, 0], i: [0, 0] });
  e = aplicar(e, { tipo: "DESHACER" }, FIN); // queda 1-0 al tiempo: sigue ganando Blanco, con 1 ippon
  assert.deepEqual(marcador(e), { v: [1, 0], e: [0, 0], i: [1, 0] });
  assert.equal(e.encuentro.combates.length, 1); // no se duplicó
});

// ---------------------------------------------------------------- Ganador del encuentro

test("Gana el equipo con más victorias, cuando se han jugado todos los combates", () => {
  let e = encuentro({ integrantes: 3 });
  e = aplicar(jugar(e, "shiro"), SIGUIENTE);
  e = aplicar(jugar(e, "shiro"), SIGUIENTE);
  assert.equal(e.encuentro.estado, "en_curso"); // aún falta un combate
  assert.equal(e.encuentro.resultado, null);
  e = jugar(e, "aka");
  assert.equal(e.encuentro.estado, "finalizado");
  assert.deepEqual(e.encuentro.resultado, { ganador: "shiro", motivo: "victorias" });
});

test("Con las mismas victorias gana quien tenga más ippones", () => {
  let e = encuentro({ integrantes: 3 });
  e = aplicar(jugar(e, "shiro"), SIGUIENTE); // Blanco gana 2-0
  e = aplicar(jugar(e, "aka", 1), SIGUIENTE); // Rojo gana 2-1
  e = jugar(e, "empate");
  assert.deepEqual(marcador(e), { v: [1, 1], e: [1, 1], i: [3, 2] });
  assert.deepEqual(e.encuentro.resultado, { ganador: "shiro", motivo: "ippones" });
});

function empateTotal(opciones) {
  let e = encuentro(opciones);
  e = aplicar(jugar(e, "shiro"), SIGUIENTE); // 1-0 victorias, 2-0 ippones
  e = aplicar(jugar(e, "aka"), SIGUIENTE); // 1-1, 2-2
  return jugar(e, "empate");
}

test("En grupos, igualdad en victorias e ippones deja el encuentro empatado", () => {
  const e = empateTotal({ integrantes: 3, eliminatoria: false });
  assert.deepEqual(e.encuentro.resultado, { ganador: "empate", motivo: "empate" });
  assert.equal(e.encuentro.estado, "finalizado");
});

test("En eliminatoria, igualdad total pide un combate de desempate", () => {
  const e = empateTotal({ integrantes: 3, eliminatoria: true });
  assert.equal(e.encuentro.estado, "pendiente_desempate");
  assert.equal(e.encuentro.resultado, null);
});

test("El combate de desempate: empieza en encho, es el nº integrantes+1, no puede acabar en empate y decide", () => {
  let e = aplicar(empateTotal({ integrantes: 3, eliminatoria: true }), SIGUIENTE);
  assert.deepEqual(e.combate.encuentro, { id: e.encuentro.id, posicion: 4, desempate: true });
  assert.equal(e.encho, true);
  assert.equal(e.combate.requiereHantei, true);

  // no se puede cerrar con empate ni sin decisión
  const sinDecision = aplicarAccion(e, FIN);
  assert.equal(sinDecision.combate.resultado, null);
  const conEmpate = aplicarAccion(e, { tipo: "FINALIZAR_COMBATE", decision: "empate" });
  assert.equal(conEmpate.combate.resultado, null);

  // el primer punto decide
  const porPunto = aplicar(e, punto("aka", "kote"), FIN);
  assert.deepEqual(porPunto.encuentro.resultado, { ganador: "aka", motivo: "desempate" });
  assert.equal(porPunto.encuentro.estado, "finalizado");
  // ...o Hantei
  const porHantei = aplicarAccion(e, { tipo: "FINALIZAR_COMBATE", decision: "shiro" });
  assert.deepEqual(porHantei.encuentro.resultado, { ganador: "shiro", motivo: "desempate" });

  // el desempate decide, pero no suma a los contadores del equipo
  assert.deepEqual(marcador(porPunto), { v: [1, 1], e: [1, 1], i: [2, 2] });
});

test("Reabrir el combate de desempate devuelve el encuentro a 'pendiente_desempate'", () => {
  let e = aplicar(empateTotal({ integrantes: 3, eliminatoria: true }), SIGUIENTE, punto("aka"), FIN);
  assert.equal(e.encuentro.estado, "finalizado");
  e = aplicarAccion(e, { tipo: "REABRIR_COMBATE" });
  assert.equal(e.encuentro.estado, "pendiente_desempate");
  assert.equal(e.encuentro.resultado, null);
});

// ---------------------------------------------------------------- Siguiente combate

test("Siguiente combate: solo con el actual finalizado; sube la posición; cada equipo conserva su lado", () => {
  let e = encuentro({ integrantes: 5 });
  e = aplicar(e, { tipo: "EDITAR_COMPETIDOR", lado: "shiro", campo: "nombre", valor: "Ana" }, { tipo: "CAMBIAR_FOTO_COMPETIDOR", lado: "shiro", archivo: "ana.png" });
  const idPrimero = e.combate.id;

  const sinFinalizar = aplicarAccion(e, SIGUIENTE);
  assert.equal(sinFinalizar.combate.id, idPrimero); // no hace nada

  e = aplicar(jugar(e, "shiro"), SIGUIENTE);
  assert.notEqual(e.combate.id, idPrimero);
  assert.equal(e.combate.encuentro.posicion, 2);
  assert.equal(e.combate.eventos.length, 0);
  assert.equal(e.competidores.shiro.nombre, ""); // nuevo competidor
  assert.equal(e.competidores.shiro.foto, "");
  assert.equal(e.competidores.shiro.club, "Zaragoza"); // el club sigue siendo el del equipo
  assert.equal(e.competidores.aka.club, "Huesca");
  assert.equal(e.encho, false);
  assert.equal(e.equipos.shiro.nombre, "Zaragoza"); // los equipos no se tocan
  assert.equal(e.encuentro.combates.length, 1);
});

test("Con el encuentro finalizado ya no hay más combates", () => {
  let f = encuentro({ integrantes: 3 });
  f = aplicar(jugar(f, "shiro"), SIGUIENTE);
  f = aplicar(jugar(f, "shiro"), SIGUIENTE);
  f = jugar(f, "shiro");
  assert.equal(f.encuentro.estado, "finalizado");
  const id = f.combate.id;
  assert.equal(aplicarAccion(f, SIGUIENTE).combate.id, id);
  assert.equal(aplicarAccion(f, { tipo: "REINICIAR_COMBATE", mantenerCompetidores: false }).combate.id, id);
});

test("Reiniciar en un encuentro conserva equipos y encuentro; a medias repite la posición, finalizado pasa al siguiente", () => {
  let e = encuentro({ integrantes: 5 });
  e = aplicar(jugar(e, "shiro"), SIGUIENTE, punto("aka"), { tipo: "EDITAR_COMPETIDOR", lado: "aka", campo: "nombre", valor: "Bea" });
  const idEnc = e.encuentro.id;

  // a medias, mantener competidores: misma posición, mismo nombre, combate nuevo
  const idAntes = e.combate.id;
  let r = aplicarAccion(e, { tipo: "REINICIAR_COMBATE", mantenerCompetidores: true });
  assert.notEqual(r.combate.id, idAntes);
  assert.equal(r.combate.encuentro.posicion, 2);
  assert.equal(r.competidores.aka.nombre, "Bea");
  assert.equal(r.combate.eventos.length, 0);
  assert.equal(r.encuentro.id, idEnc);
  assert.equal(r.equipos.shiro.victorias, 1); // los contadores no se pierden
  assert.equal(r.equipos.shiro.nombre, "Zaragoza");

  // a medias, sin mantener: nombres vacíos, club del equipo
  r = aplicarAccion(e, { tipo: "REINICIAR_COMBATE", mantenerCompetidores: false });
  assert.equal(r.competidores.aka.nombre, "");
  assert.equal(r.competidores.aka.club, "Huesca");
  assert.equal(r.combate.encuentro.posicion, 2);

  // finalizado: avanza
  const fin = jugar(e, "aka");
  const sig = aplicarAccion(fin, { tipo: "REINICIAR_COMBATE", mantenerCompetidores: true });
  assert.equal(sig.combate.encuentro.posicion, 3);
});

// ---------------------------------------------------------------- Convivencia con lo manual

test("Con un encuentro en curso los contadores no se editan a mano, pero el nombre sí", () => {
  let e = encuentro();
  e = jugar(e, "shiro");
  const antes = marcador(e);
  e = aplicar(
    e,
    { tipo: "EDITAR_EQUIPO", lado: "shiro", campo: "victorias", valor: 9 },
    { tipo: "EDITAR_EQUIPO", lado: "aka", campo: "empates", valor: 9 },
    { tipo: "EDITAR_EQUIPO", lado: "aka", campo: "ippones", valor: 9 },
    nombre("aka", "Huesca B")
  );
  assert.deepEqual(marcador(e), antes);
  assert.equal(e.equipos.aka.nombre, "Huesca B");
});

test("Durante el encuentro no se apaga el modo equipos, ni se intercambian lados, ni se cambia categoría o modalidad", () => {
  const e = encuentro();
  assert.equal(aplicarAccion(e, { tipo: "TOGGLE_MODO_EQUIPOS" }).modoEquipos, true);
  const sinCambios = aplicar(
    e,
    { tipo: "INTERCAMBIAR_COMPETIDORES" },
    { tipo: "CAMBIAR_CATEGORIA", opcion: "femenino" },
    { tipo: "CAMBIAR_MODALIDAD", opcion: "individual" }
  );
  assert.equal(sinCambios.categoria.opcion, "masculino");
  assert.equal(sinCambios.modalidad.opcion, "equipos");
});

test("Cerrar el encuentro deja los contadores tal cual y vuelven a ser editables", () => {
  let e = encuentro({ integrantes: 3 });
  e = aplicar(jugar(e, "shiro"), SIGUIENTE);
  e = aplicarAccion(e, { tipo: "CERRAR_ENCUENTRO" });
  assert.equal(e.encuentro, null);
  assert.equal(e.combate.encuentro, null); // el combate a medias pasa a ser suelto
  assert.deepEqual(marcador(e).v, [1, 0]);
  e = aplicarAccion(e, { tipo: "EDITAR_EQUIPO", lado: "shiro", campo: "victorias", valor: 3 });
  assert.equal(e.equipos.shiro.victorias, 3);
  e = aplicarAccion(e, { tipo: "TOGGLE_MODO_EQUIPOS" });
  assert.equal(e.modoEquipos, false);
});

test("Cerrar el encuentro con el último combate finalizado conserva su referencia al encuentro", () => {
  let e = jugar(encuentro({ integrantes: 3 }), "shiro");
  const ref = e.combate.encuentro;
  e = aplicarAccion(e, { tipo: "CERRAR_ENCUENTRO" });
  assert.deepEqual(e.combate.encuentro, ref);
});

test("Después de cerrar se puede empezar otro encuentro, con contadores a cero", () => {
  let e = jugar(encuentro({ integrantes: 3 }), "shiro");
  e = aplicar(e, { tipo: "CERRAR_ENCUENTRO" }, nombre("shiro", "Teruel"), nombre("aka", "Soria"), { tipo: "INICIAR_ENCUENTRO", integrantes: 5, eliminatoria: true });
  assert.equal(e.encuentro.integrantes, 5);
  assert.deepEqual(marcador(e), { v: [0, 0], e: [0, 0], i: [0, 0] });
  assert.equal(e.competidores.shiro.club, "Teruel");
});

// ---------------------------------------------------------------- Persistencia y estados antiguos

test("El encuentro sobrevive a guardarse y leerse del disco", () => {
  let e = aplicar(jugar(encuentro({ integrantes: 5, eliminatoria: true }), "shiro"), SIGUIENTE, punto("aka"));
  const leido = normalizarEstado(JSON.parse(JSON.stringify(e)));
  assert.deepEqual(leido, e);
  assert.deepEqual(marcador(leido), marcador(e));
});

test("Un estado de la Fase 4 (sin 'encuentro') arranca sin errores y con encuentro nulo", () => {
  const e = normalizarEstado(estadoInicial());
  const viejo = JSON.parse(JSON.stringify(e));
  delete viejo.encuentro;
  delete viejo.combate.encuentro;
  const n = normalizarEstado(viejo);
  assert.equal(n.encuentro, null);
  assert.equal(n.combate.encuentro, null);
});

test("Acciones de encuentro sin encuentro no hacen nada ni fallan", () => {
  const e = normalizarEstado(estadoInicial());
  const antes = JSON.stringify(e);
  for (const a of [{ tipo: "SIGUIENTE_COMBATE" }, { tipo: "CERRAR_ENCUENTRO" }]) {
    assert.equal(JSON.stringify(aplicarAccion(e, a)), antes);
  }
});

test("El encuentro no se pierde al reabrir tras cerrar: el combate vuelve a ser suelto", () => {
  let e = jugar(encuentro({ integrantes: 3 }), "shiro");
  e = aplicar(e, { tipo: "CERRAR_ENCUENTRO" }, { tipo: "REABRIR_COMBATE" });
  assert.equal(e.combate.encuentro, null);
});

// ---------------------------------------------------------------- Nombres por combate y "Siguiente" en combates sueltos

test("Cada combate del encuentro guarda quién combatió y cómo terminó", () => {
  let e = encuentro({ integrantes: 3 });
  e = aplicar(e,
    { tipo: "EDITAR_COMPETIDOR", lado: "shiro", campo: "nombre", valor: "  A. Alonso " },
    { tipo: "EDITAR_COMPETIDOR", lado: "aka", campo: "nombre", valor: "C. Garín" },
    punto("aka", "kote"), punto("shiro"), { tipo: "TOGGLE_ENCHO" }, punto("shiro", "do"), FIN);
  assert.deepEqual(e.encuentro.combates[0].nombres, { shiro: "A. Alonso", aka: "C. Garín" });
  assert.equal(e.encuentro.combates[0].tipo, "encho");
  assert.equal(e.encuentro.combates[0].ganador, "shiro");
  assert.deepEqual(e.encuentro.combates[0].ippones, { shiro: 2, aka: 1 });

  // empate y victoria técnica
  e = aplicar(e, SIGUIENTE, FIN, SIGUIENTE, { tipo: "VICTORIA_TECNICA", ganador: "aka", motivo: "lesion" }, FIN);
  assert.equal(e.encuentro.combates[1].tipo, "empate");
  assert.equal(e.encuentro.combates[2].tipo, "tecnica");
  assert.equal(e.encuentro.combates[2].motivo, "lesion");
  assert.deepEqual(e.encuentro.combates[1].nombres, { shiro: "", aka: "" }); // sin nombres escritos
});

test("Reabrir y finalizar de nuevo actualiza los nombres de ese combate", () => {
  let e = aplicar(encuentro(), { tipo: "EDITAR_COMPETIDOR", lado: "shiro", campo: "nombre", valor: "Ana" }, punto("shiro"), FIN);
  assert.equal(e.encuentro.combates[0].nombres.shiro, "Ana");
  e = aplicar(e, { tipo: "REABRIR_COMBATE" }, { tipo: "EDITAR_COMPETIDOR", lado: "shiro", campo: "nombre", valor: "Ana M." }, FIN);
  assert.equal(e.encuentro.combates.length, 1);
  assert.equal(e.encuentro.combates[0].nombres.shiro, "Ana M.");
});

test("Siguiente combate (combate suelto): solo con el combate finalizado", () => {
  const base = aplicar(normalizarEstado(estadoInicial()), { tipo: "EDITAR_COMPETIDOR", lado: "shiro", campo: "nombre", valor: "Ana" }, punto("shiro"));
  const idAntes = base.combate.id;
  assert.equal(aplicarAccion(base, SIGUIENTE).combate.id, idAntes); // en curso: no hace nada
  const decidido = aplicar(base, punto("shiro", "do"));
  assert.equal(aplicarAccion(decidido, SIGUIENTE).combate.id, idAntes); // decidido sin confirmar: tampoco
});

test("Siguiente combate (combate suelto): vacía el combate y conserva torneo, categoría, modalidad, ajustes y contadores", () => {
  let e = aplicar(
    normalizarEstado(estadoInicial()),
    { tipo: "EDITAR_NOMBRE_TORNEO", valor: "Copa" },
    { tipo: "CAMBIAR_CATEGORIA", opcion: "femenino" },
    { tipo: "CAMBIAR_IDIOMA", valor: "en" },
    { tipo: "TOGGLE_MODO_EQUIPOS" },
    { tipo: "EDITAR_EQUIPO", lado: "shiro", campo: "victorias", valor: 2 },
    { tipo: "EDITAR_COMPETIDOR", lado: "shiro", campo: "nombre", valor: "Ana" },
    { tipo: "EDITAR_COMPETIDOR", lado: "shiro", campo: "club", valor: "Club A" },
    { tipo: "CAMBIAR_FOTO_COMPETIDOR", lado: "shiro", archivo: "ana.png" },
    { tipo: "EDITAR_INFO_GENERAL", valor: "Semifinal 1" },
    punto("shiro"), punto("shiro", "do"), FIN
  );
  const idAntes = e.combate.id;
  e = aplicarAccion(e, SIGUIENTE);
  assert.notEqual(e.combate.id, idAntes);
  assert.equal(e.combate.estado, "en_curso");
  assert.deepEqual(e.combate.eventos, []);
  assert.equal(e.combate.resultado, null);
  assert.equal(e.encho, false);
  // se vacía lo del combate
  assert.equal(e.competidores.shiro.nombre, "");
  assert.equal(e.competidores.shiro.club, "");
  assert.equal(e.competidores.shiro.foto, "");
  assert.equal(e.competidores.shiro.puntos.length, 0);
  assert.equal(e.infoGeneral, "");
  // se conserva lo demás
  assert.equal(e.evento.nombreTorneo, "Copa");
  assert.equal(e.categoria.opcion, "femenino");
  assert.equal(e.configuracion.idioma, "en");
  assert.equal(e.modoEquipos, true);
  assert.equal(e.equipos.shiro.victorias, 2);
});

test("Siguiente combate (combate suelto) no pisa el registro: el combate anterior conserva su id", () => {
  let e = aplicar(normalizarEstado(estadoInicial()), punto("shiro"), FIN);
  const idPrimero = e.combate.id;
  e = aplicar(e, SIGUIENTE, punto("aka"), FIN);
  assert.notEqual(e.combate.id, idPrimero);
});
