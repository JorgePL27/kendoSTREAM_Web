// overlay.js — el overlay es puramente de lectura: recibe estado y lo pinta.
// KendoSTREAM — © 2026 Jorge Pascual Lansac. Distribuido bajo PolyForm
// Noncommercial License 1.0.0 — ver LICENSE.txt en la raíz del proyecto.

const ICONOS = { men: "M", kote: "K", do: "D", tsuki: "T" };

// Etiquetas de categoría/modalidad/encho, una por idioma. El idioma se
// toma de estado.configuracion.idioma (el mismo que usa el panel), así
// que el overlay sigue este dato aunque su contenido normalmente no se
// traduzca — categoría y modalidad son valores fijos, no texto libre.
const ETIQUETAS = {
  es: {
    categoria: { masculino: "Masculino", femenino: "Femenino", junior: "Junior" },
    modalidad: { individual: "Individual", equipos: "Equipos" },
    encho: "ENCHO (PRÓRROGA)"
  },
  en: {
    categoria: { masculino: "Men", femenino: "Women", junior: "Junior" },
    modalidad: { individual: "Single", equipos: "Team" },
    encho: "ENCHO (OVERTIME)"
  }
};

function conectar() {
  const ws = new WebSocket(`ws://${location.host}`);
  ws.onmessage = (evento) => {
    const mensaje = JSON.parse(evento.data);
    if (mensaje.tipo === "ESTADO") render(mensaje.estado);
  };
  ws.onclose = () => setTimeout(conectar, 1500);
}

function etiquetaDe(idioma, tipo, campo) {
  if (campo.opcion === "otro") return campo.textoPersonalizado || "";
  const diccionario = ETIQUETAS[idioma] || ETIQUETAS.es;
  return diccionario[tipo][campo.opcion] || "";
}

function render(estado) {
  const temaDeseado = "temas/" + (estado.configuracion?.disenoMarcador || "clasico") + ".css";
  const enlaceTema = document.getElementById("temaCSS");
  if (enlaceTema.getAttribute("href") !== temaDeseado) {
    enlaceTema.setAttribute("href", temaDeseado);
  }

  document.getElementById("marcaAgua").hidden = !estado.configuracion?.marcaAguaVisible;
  document.getElementById("infoGeneral").textContent = estado.infoGeneral || "";
  const idioma = estado.configuracion?.idioma || "es";
  document.getElementById("badgeEncho").hidden = !estado.encho;
  document.getElementById("badgeEncho").textContent = (ETIQUETAS[idioma] || ETIQUETAS.es).encho;

  const modoCampeonato = !!estado.configuracion?.modoCampeonatoImportante;

  // Nombre del torneo: en modo normal vive dentro del marcador; en modo
  // Campeonato Importante sube a una cajita propia arriba del todo, y su
  // hueco original pasa a mostrar categoría/modalidad.
  document.getElementById("torneoSuperior").hidden = !modoCampeonato;
  document.getElementById("torneoSuperior").textContent = estado.evento.nombreTorneo || "";
  document.getElementById("nombreTorneo").hidden = modoCampeonato;
  document.getElementById("nombreTorneo").textContent = estado.evento.nombreTorneo || "";

  const categoriaModalidadEl = document.getElementById("categoriaModalidad");
  categoriaModalidadEl.hidden = !modoCampeonato;
  if (modoCampeonato) {
    const categoria = etiquetaDe(idioma, "categoria", estado.categoria);
    const modalidad = etiquetaDe(idioma, "modalidad", estado.modalidad);
    categoriaModalidadEl.textContent = [categoria, modalidad].filter(Boolean).join(" · ");
  }

  renderLado("shiro", estado.competidores.shiro, modoCampeonato);
  renderLado("aka", estado.competidores.aka, modoCampeonato);

  const bloqueEquipos = document.getElementById("equipos");
  bloqueEquipos.style.display = estado.modoEquipos ? "block" : "none";
  if (estado.modoEquipos) {
    document.getElementById("equipoShiroNombre").textContent = estado.equipos.shiro.nombre;
    document.getElementById("equipoShiroVictorias").textContent = estado.equipos.shiro.victorias;
    document.getElementById("equipoShiroEmpates").textContent = estado.equipos.shiro.empates;
    document.getElementById("equipoShiroIppones").textContent = estado.equipos.shiro.ippones;
    document.getElementById("equipoAkaNombre").textContent = estado.equipos.aka.nombre;
    document.getElementById("equipoAkaVictorias").textContent = estado.equipos.aka.victorias;
    document.getElementById("equipoAkaEmpates").textContent = estado.equipos.aka.empates;
    document.getElementById("equipoAkaIppones").textContent = estado.equipos.aka.ippones;

    renderLogoEquipo("Shiro", modoCampeonato && estado.competidores.shiro.logoClub);
    renderLogoEquipo("Aka", modoCampeonato && estado.competidores.aka.logoClub);
  }
}

function renderLogoEquipo(sufijo, archivoLogo) {
  const img = document.getElementById(`equipo${sufijo}Logo`);
  if (archivoLogo) {
    img.src = "/logos-clubes/" + encodeURIComponent(archivoLogo);
    img.hidden = false;
  } else {
    img.hidden = true;
    img.removeAttribute("src");
  }
}

function renderLado(lado, competidor, modoCampeonato) {
  const prefijo = lado === "shiro" ? "shiro" : "aka";
  document.getElementById(`${prefijo}Nombre`).textContent = competidor.nombre || "";
  document.getElementById(`${prefijo}Club`).textContent = competidor.club || "";

  const contenedorPuntos = document.getElementById(`${prefijo}Puntos`);
  contenedorPuntos.innerHTML = "";
  competidor.puntos.forEach((p) => {
    const span = document.createElement("span");
    span.className = "punto" + (p.origen === "hansoku" ? " hansoku-ippon" : "");
    span.textContent = p.origen === "hansoku" ? "H" : (ICONOS[p.tipo] || "?");
    contenedorPuntos.appendChild(span);
  });

  // Solo hace falta una marca de hansoku: al llegar a 2 se convierte
  // automáticamente en ippon y el contador vuelve a 0 (ver motor.js).
  const contenedorHansoku = document.getElementById(`${prefijo}Hansoku`);
  contenedorHansoku.innerHTML = "";
  contenedorHansoku.className = "hansoku-marcas";
  const marca = document.createElement("span");
  marca.className = "hansoku-marca" + (competidor.hansoku >= 1 ? " activa" : "");
  contenedorHansoku.appendChild(marca);

  // Foto del competidor + logo de club superpuesto (modo Campeonato Importante)
  const prefijoMayus = lado === "shiro" ? "Shiro" : "Aka";
  const contenedorFoto = document.getElementById(`foto${prefijoMayus}`);
  const imgFoto = document.getElementById(`foto${prefijoMayus}Img`);
  const imgLogo = document.getElementById(`logo${prefijoMayus}Img`);

  if (modoCampeonato && competidor.foto) {
    imgFoto.src = "/fotos-competidores/" + encodeURIComponent(competidor.foto);
    contenedorFoto.hidden = false;
  } else {
    contenedorFoto.hidden = true;
    imgFoto.removeAttribute("src");
  }

  if (modoCampeonato && competidor.logoClub) {
    imgLogo.src = "/logos-clubes/" + encodeURIComponent(competidor.logoClub);
    imgLogo.hidden = false;
  } else {
    imgLogo.hidden = true;
    imgLogo.removeAttribute("src");
  }
}

conectar();
