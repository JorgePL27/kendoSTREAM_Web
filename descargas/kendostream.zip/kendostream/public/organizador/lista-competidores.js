// lista-competidores.js
// KendoSTREAM — Organizador de torneos: datos de competidores y equipos.
//  - Guardar y cargar listas en un archivo .json (individual o por equipos).
//  - Validación de los integrantes de un equipo (3 o 5, con huecos permitidos).
// Lógica pura, sin DOM.

const FORMATO_LISTA_COMPETIDORES = "kendostream-lista-competidores";
const VERSION_LISTA_COMPETIDORES = 1;
const TAMANOS_EQUIPO = [3, 5];

// En un equipo de 3 puede faltar 1 integrante; en uno de 5, hasta 2.
function huecosPermitidosEquipo(tamano) {
  return tamano === 3 ? 1 : 2;
}

// Nombres de los puestos, en orden de combate (solo como ayuda visual).
function puestosEquipo(tamano) {
  return tamano === 3
    ? ["Senpo", "Chuken", "Taisho"]
    : ["Senpo", "Jiho", "Chuken", "Fukusho", "Taisho"];
}

/**
 * Normaliza los integrantes de un equipo. Es opcional: si todos los puestos
 * están en blanco (o el tamaño no es 3 ni 5) devuelve []. Si hay al menos un
 * nombre, devuelve un array de longitud "tamano" (los huecos son "") y lanza
 * Error si hay más huecos de los permitidos.
 */
function normalizarIntegrantes(integrantes, tamano) {
  if (!TAMANOS_EQUIPO.includes(tamano)) return [];
  const lista = [];
  for (let i = 0; i < tamano; i++) {
    const valor = Array.isArray(integrantes) && typeof integrantes[i] === "string" ? integrantes[i].trim() : "";
    lista.push(valor);
  }
  const rellenos = lista.filter(Boolean).length;
  if (rellenos === 0) return [];
  const huecos = tamano - rellenos;
  const maximo = huecosPermitidosEquipo(tamano);
  if (huecos > maximo) {
    throw new Error(`En un equipo de ${tamano} puede haber como máximo ${maximo} hueco${maximo > 1 ? "s" : ""} en blanco.`);
  }
  return lista;
}

/**
 * Convierte la lista en el texto del archivo .json.
 * opciones: { tipo: "individual" | "equipos", integrantesPorEquipo: 0 | 3 | 5 }
 * No guarda los ids (se reasignan al cargar) pero sí el orden y las marcas
 * de cabeza de serie.
 */
function serializarListaCompetidores(competidores, opciones = {}) {
  const tipo = opciones.tipo === "equipos" ? "equipos" : "individual";
  const datos = { formato: FORMATO_LISTA_COMPETIDORES, version: VERSION_LISTA_COMPETIDORES, tipo };

  if (tipo === "equipos") {
    datos.integrantesPorEquipo = TAMANOS_EQUIPO.includes(opciones.integrantesPorEquipo) ? opciones.integrantesPorEquipo : 0;
    datos.competidores = competidores.map((c) => ({
      nombre: c.nombre,
      club: c.club || "",
      cabezaDeSerie: !!c.cabezaDeSerie,
      integrantes: c.integrantes || []
    }));
  } else {
    datos.competidores = competidores.map((c) => ({
      nombre: c.nombre,
      club: c.club,
      dan: c.dan || "",
      cabezaDeSerie: !!c.cabezaDeSerie
    }));
  }
  return JSON.stringify(datos, null, 2);
}

/**
 * Lee y valida el texto de un archivo .json.
 * Devuelve { tipo, integrantesPorEquipo, competidores, avisos } con ids nuevos
 * (1..n); lanza Error con un mensaje claro si el archivo no es válido.
 * opciones: { limiteCabezasDeSerie } (por defecto 2)
 */
function leerListaCompetidores(texto, opciones = {}) {
  const limite = opciones.limiteCabezasDeSerie ?? 2;

  let datos;
  try {
    datos = JSON.parse(texto);
  } catch (err) {
    throw new Error("El archivo no es un JSON válido.");
  }

  if (!datos || typeof datos !== "object" || Array.isArray(datos) || datos.formato !== FORMATO_LISTA_COMPETIDORES) {
    throw new Error("Este archivo no parece una lista de competidores de KendoSTREAM.");
  }
  if (typeof datos.version !== "number" || datos.version > VERSION_LISTA_COMPETIDORES) {
    throw new Error("El archivo es de una versión más reciente que esta aplicación y no se puede cargar.");
  }
  const tipo = datos.tipo || "individual";
  if (tipo !== "individual" && tipo !== "equipos") {
    throw new Error(`Tipo de lista desconocido: "${tipo}".`);
  }
  if (!Array.isArray(datos.competidores) || datos.competidores.length === 0) {
    throw new Error("El archivo no contiene ningún competidor.");
  }

  const esEquipos = tipo === "equipos";
  let integrantesPorEquipo = 0;
  if (esEquipos) {
    integrantesPorEquipo = datos.integrantesPorEquipo ?? 0;
    if (integrantesPorEquipo !== 0 && !TAMANOS_EQUIPO.includes(integrantesPorEquipo)) {
      throw new Error("El nº de integrantes por equipo del archivo debe ser 3, 5 o no indicarse.");
    }
  }

  let cabezas = 0;
  let cabezasDescartadas = 0;
  const competidores = datos.competidores.map((c, i) => {
    const nombre = typeof c?.nombre === "string" ? c.nombre.trim() : "";
    const club = typeof c?.club === "string" ? c.club.trim() : "";
    if (!nombre || (!esEquipos && !club)) {
      throw new Error(esEquipos
        ? `El equipo nº ${i + 1} no tiene nombre.`
        : `El competidor nº ${i + 1} no tiene nombre o club.`);
    }
    let cabezaDeSerie = c.cabezaDeSerie === true;
    if (cabezaDeSerie) {
      if (cabezas >= limite) { cabezaDeSerie = false; cabezasDescartadas++; }
      else cabezas++;
    }

    if (!esEquipos) {
      const dan = c.dan == null ? "" : String(c.dan).trim();
      return { id: i + 1, nombre, club, dan, cabezaDeSerie };
    }
    let integrantes;
    try {
      integrantes = normalizarIntegrantes(c.integrantes, integrantesPorEquipo);
    } catch (err) {
      throw new Error(`El equipo nº ${i + 1} (${nombre}): ${err.message}`);
    }
    return { id: i + 1, nombre, club, dan: "", cabezaDeSerie, integrantes };
  });

  const avisos = [];
  if (cabezasDescartadas > 0) {
    avisos.push(`El archivo marcaba más de ${limite} cabezas de serie; se han conservado las ${limite} primeras.`);
  }
  return { tipo, integrantesPorEquipo, competidores, avisos };
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    serializarListaCompetidores,
    leerListaCompetidores,
    normalizarIntegrantes,
    huecosPermitidosEquipo,
    puestosEquipo
  };
}
