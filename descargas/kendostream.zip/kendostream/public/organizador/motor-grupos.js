// motor-grupos.js
// KendoSTREAM — Organizador de torneos: fase de grupos.
// Igual que motor-eliminatoria.js, es lógica pura: sin red ni DOM.

function calcularEstructuraGrupos(n) {
  if (n < 4) {
    throw new Error("Hacen falta al menos 4 competidores para poder formar grupos (mínimo 2 grupos de 2).");
  }
  const numGrupos = Math.max(2, Math.ceil(n / 4));
  const base = Math.floor(n / numGrupos);
  const sobrante = n % numGrupos;
  const tamanos = [];
  for (let i = 0; i < numGrupos; i++) tamanos.push(base + (i < sobrante ? 1 : 0));
  return { numGrupos, tamanos };
}

function validarClasificadosPorGrupo(clasificadosPorGrupo, tamanos) {
  const tamanoMinimo = Math.min(...tamanos);
  if (clasificadosPorGrupo < 1) {
    throw new Error("Tiene que clasificar al menos 1 competidor por grupo.");
  }
  if (clasificadosPorGrupo > tamanoMinimo) {
    throw new Error(`No puedes clasificar ${clasificadosPorGrupo} por grupo: el grupo más pequeño solo tiene ${tamanoMinimo} competidores.`);
  }
}

function mezclar(array) {
  const copia = array.slice();
  for (let i = copia.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copia[i], copia[j]] = [copia[j], copia[i]];
  }
  return copia;
}

function contarChoquesDeClubEnGrupos(grupos) {
  let choques = 0;
  grupos.forEach((grupo) => {
    for (let i = 0; i < grupo.length; i++) {
      for (let j = i + 1; j < grupo.length; j++) {
        if (grupo[i].club && grupo[j].club && grupo[i].club.trim().toLowerCase() === grupo[j].club.trim().toLowerCase()) {
          choques++;
        }
      }
    }
  });
  return choques;
}

function formarGrupos(competidores, estructura, opciones = {}) {
  const intentos = opciones.intentosAntiChoque || 300;
  const { numGrupos, tamanos } = estructura;

  if (competidores.length !== tamanos.reduce((a, b) => a + b, 0)) {
    throw new Error("El número de competidores no coincide con la estructura de grupos calculada.");
  }

  const cabezasDeSerie = competidores.filter((c) => c.cabezaDeSerie);
  const resto = mezclar(competidores.filter((c) => !c.cabezaDeSerie));

  function gruposVacios() {
    return tamanos.map(() => []);
  }

  const plantillaBase = gruposVacios();
  const cabezasColocadas = [];
  cabezasDeSerie.forEach((c, i) => {
    if (i < numGrupos) {
      plantillaBase[i].push(c);
      cabezasColocadas.push(c.id);
    }
  });
  const pendientes = [
    ...cabezasDeSerie.filter((c) => !cabezasColocadas.includes(c.id)),
    ...resto
  ];

  let mejorReparto = null;
  let mejorPuntuacion = Infinity;

  for (let intento = 0; intento < intentos; intento++) {
    const grupos = plantillaBase.map((g) => g.slice());
    const orden = mezclar(pendientes);
    let cursor = 0;
    for (let g = 0; g < numGrupos; g++) {
      while (grupos[g].length < tamanos[g]) {
        grupos[g].push(orden[cursor++]);
      }
    }
    const puntuacion = contarChoquesDeClubEnGrupos(grupos);
    if (puntuacion < mejorPuntuacion) {
      mejorPuntuacion = puntuacion;
      mejorReparto = grupos;
    }
    if (mejorPuntuacion === 0) break;
  }

  return { grupos: mejorReparto, choquesDeClub: mejorPuntuacion };
}

function generarCombatesGrupo(competidoresGrupo, idInicial) {
  const combates = [];
  let id = idInicial;
  for (let i = 0; i < competidoresGrupo.length; i++) {
    for (let j = i + 1; j < competidoresGrupo.length; j++) {
      combates.push({
        id: id++,
        compA: { id: competidoresGrupo[i].id, nombre: competidoresGrupo[i].nombre, club: competidoresGrupo[i].club },
        compB: { id: competidoresGrupo[j].id, nombre: competidoresGrupo[j].nombre, club: competidoresGrupo[j].club },
        ipponesA: null,
        ipponesB: null,
        ganadorId: null
      });
    }
  }
  return { combates, siguienteId: id };
}

function calcularClasificacion(competidoresGrupo, combates, clasificadosPorGrupo) {
  const stats = {};
  competidoresGrupo.forEach((c) => { stats[c.id] = { competidor: c, victorias: 0, ippones: 0, jugados: 0 }; });

  combates.forEach((combate) => {
    if (combate.ganadorId == null || combate.ipponesA == null || combate.ipponesB == null) return;
    stats[combate.compA.id].jugados++;
    stats[combate.compB.id].jugados++;
    stats[combate.compA.id].ippones += combate.ipponesA;
    stats[combate.compB.id].ippones += combate.ipponesB;
    if (combate.ganadorId === combate.compA.id) stats[combate.compA.id].victorias++;
    else if (combate.ganadorId === combate.compB.id) stats[combate.compB.id].victorias++;
  });

  const filas = Object.values(stats).sort((a, b) => {
    if (b.victorias !== a.victorias) return b.victorias - a.victorias;
    return b.ippones - a.ippones;
  });

  let empatePendiente = null;
  if (clasificadosPorGrupo && clasificadosPorGrupo < filas.length) {
    const ultimoQueClasifica = filas[clasificadosPorGrupo - 1];
    const primeroQueNoClasifica = filas[clasificadosPorGrupo];
    if (ultimoQueClasifica.victorias === primeroQueNoClasifica.victorias &&
        ultimoQueClasifica.ippones === primeroQueNoClasifica.ippones) {
      const valorVictorias = ultimoQueClasifica.victorias;
      const valorIppones = ultimoQueClasifica.ippones;
      empatePendiente = filas
        .filter((f) => f.victorias === valorVictorias && f.ippones === valorIppones)
        .map((f) => f.competidor);
    }
  }

  return {
    clasificacion: filas.map((f) => ({
      competidor: f.competidor,
      victorias: f.victorias,
      ippones: f.ippones,
      jugados: f.jugados
    })),
    empatePendiente
  };
}

function todosLosCombatesJugados(combates) {
  return combates.every((c) => c.ganadorId != null && c.ipponesA != null && c.ipponesB != null);
}

function siguientePotenciaDeDos(n) {
  let p = 1;
  while (p < n) p *= 2;
  return p;
}

function generarCruceDeGrupos(gruposConClasificacion, clasificadosPorGrupo) {
  const { generarEliminatoria, propagarGanadores, calcularNombresRondas } =
    typeof module !== "undefined" && module.exports ? require("./motor-eliminatoria") : window;

  if (clasificadosPorGrupo === 1) {
    const ganadores = gruposConClasificacion.map((g) => g.clasificacion[0].competidor);
    return generarEliminatoria(ganadores);
  }

  if (clasificadosPorGrupo !== 2) {
    throw new Error("El cruce automático entre grupos solo está resuelto para 1 o 2 clasificados por grupo.");
  }

  const G = gruposConClasificacion.length;
  const Gpad = siguientePotenciaDeDos(G);

  const primeros = gruposConClasificacion.map((g) => g.clasificacion[0].competidor);
  const segundos = gruposConClasificacion.map((g) => g.clasificacion[1].competidor);
  while (primeros.length < Gpad) primeros.push(null);
  while (segundos.length < Gpad) segundos.push(null);

  const combatesRonda1 = [];
  let idContador = 1;
  for (let i = 0; i < Gpad; i++) {
    const compA = primeros[i];
    const compB = segundos[Gpad - 1 - i];
    let ganadorId = null;
    if (compA && !compB) ganadorId = compA.id;
    if (compB && !compA) ganadorId = compB.id;
    combatesRonda1.push({
      id: idContador++,
      posicion: i,
      compA: compA ? { id: compA.id, nombre: compA.nombre, club: compA.club } : null,
      compB: compB ? { id: compB.id, nombre: compB.nombre, club: compB.club } : null,
      ganadorId
    });
  }

  const tamanoCuadro = Gpad * 2;
  const nombresRonda = calcularNombresRondas(tamanoCuadro);
  const rondas = [{ nombre: nombresRonda[0], combates: combatesRonda1 }];

  let numCombatesRondaAnterior = combatesRonda1.length;
  for (let r = 1; r < nombresRonda.length; r++) {
    const numCombates = numCombatesRondaAnterior / 2;
    const combates = [];
    for (let i = 0; i < numCombates; i++) {
      combates.push({ id: idContador++, posicion: i, compA: null, compB: null, ganadorId: null });
    }
    rondas.push({ nombre: nombresRonda[r], combates });
    numCombatesRondaAnterior = numCombates;
  }

  propagarGanadores(rondas);

  const numByesFantasma = tamanoCuadro - G * clasificadosPorGrupo;
  const choquesDeClub = combatesRonda1.filter((c) =>
    c.compA && c.compB && c.compA.club && c.compB.club &&
    c.compA.club.trim().toLowerCase() === c.compB.club.trim().toLowerCase()
  ).length;
  return { tamanoCuadro, numByes: numByesFantasma, choquesDeClubRonda1: choquesDeClub, rondas };
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    calcularEstructuraGrupos,
    validarClasificadosPorGrupo,
    formarGrupos,
    generarCombatesGrupo,
    calcularClasificacion,
    todosLosCombatesJugados,
    generarCruceDeGrupos,
    siguientePotenciaDeDos
  };
}