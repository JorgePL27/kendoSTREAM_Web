// organizador.js — interfaz del organizador de torneos (eliminatoria directa)
// KendoSTREAM — © 2026 Jorge Pascual Lansac. Distribuido bajo PolyForm
// Noncommercial License 1.0.0 — ver LICENSE.txt en la raíz del proyecto.

let competidores = [];
let cuadro = null; // resultado de generarEliminatoria(), o null si aún no se ha generado
let mostrarDan = true;
let siguienteIdCompetidor = 1;
let guardadoPendiente = null;
let formato = "eliminatoria"; // "eliminatoria" | "grupos"
let clasificadosPorGrupo = 2;
let estructuraGrupos = null;
let grupos = null; // array de { nombre, competidores, combates } una vez generados

// --- Persistencia sencilla contra el servidor (data/torneo.json) ---
async function cargarEstado() {
  try {
    const resp = await fetch("/api/torneo");
    if (!resp.ok) return;
    const datos = await resp.json();
    if (datos.competidores) competidores = datos.competidores;
    if (typeof datos.mostrarDan === "boolean") mostrarDan = datos.mostrarDan;
    if (datos.cuadro) cuadro = datos.cuadro;
    siguienteIdCompetidor = 1 + competidores.reduce((max, c) => Math.max(max, c.id), 0);
    document.getElementById("mostrarDan").checked = mostrarDan;
    renderListaCompetidores();
    if (cuadro) { document.getElementById("bloqueCuadro").hidden = false; renderCuadro(); }
    // dentro de cargarEstado(), junto a las demás lecturas:
    if (datos.formato) formato = datos.formato;
    if (typeof datos.clasificadosPorGrupo === "number") clasificadosPorGrupo = datos.clasificadosPorGrupo;
    if (datos.estructuraGrupos) estructuraGrupos = datos.estructuraGrupos;
    if (datos.grupos) grupos = datos.grupos;
    document.getElementById("campoClasificadosPorGrupo").value = clasificadosPorGrupo;
    document.querySelector(`input[name="formato"][value="${formato}"]`).checked = true;
    actualizarVisibilidadFormato();
    // if (grupos) { document.getElementById("bloqueGrupos").hidden = false; renderGrupos(); }
    document.querySelectorAll('input[name="formato"]').forEach((radio) => {
      radio.addEventListener("change", (evento) => {
        formato = evento.target.value;
        actualizarVisibilidadFormato();
        guardarEstado();
      });
    });

  } catch (err) {
    console.error("No se pudo cargar el estado guardado:", err.message);
  }
}

function guardarEstado() {
  const indicador = document.getElementById("estadoGuardado");
  indicador.textContent = "Guardando…";
  clearTimeout(guardadoPendiente);
  guardadoPendiente = setTimeout(async () => {
    try {
      await fetch("/api/torneo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ competidores, mostrarDan, cuadro, formato, clasificadosPorGrupo, estructuraGrupos, grupos })
      });
      indicador.textContent = "Guardado ✓";
      setTimeout(() => (indicador.textContent = ""), 1500);
    } catch (err) {
      indicador.textContent = "Sin guardar (sin conexión con el servidor)";
    }
  }, 400);
}

function actualizarVisibilidadFormato() {
  document.getElementById("campoClasificadosWrapper").hidden = formato !== "grupos";
}

document.getElementById("campoClasificadosPorGrupo").addEventListener("change", (evento) => {
  clasificadosPorGrupo = parseInt(evento.target.value, 10) || 1;
  guardarEstado();
});

// --- Generación de grupos ---
// document.getElementById("botonGenerarGrupos").addEventListener("click", () => {
//   const aviso = document.getElementById("avisoGenerarGrupos");
//   aviso.textContent = "";
//   if (competidores.length < 4) {
//     aviso.textContent = "Hacen falta al menos 4 competidores para formar grupos.";
//     return;
//   }
//   if (grupos && !confirm("Ya hay grupos generados. ¿Generarlos de nuevo? Se perderán los resultados marcados hasta ahora.")) {
//     return;
//   }
//   try {
//     estructuraGrupos = calcularEstructuraGrupos(competidores.length);
//     validarClasificadosPorGrupo(clasificadosPorGrupo, estructuraGrupos.tamanos);
//     const { grupos: gruposFormados, choquesDeClub } = formarGrupos(competidores, estructuraGrupos);

//     let idCombate = 1;
//     grupos = gruposFormados.map((competidoresGrupo, i) => {
//       const { combates, siguienteId } = generarCombatesGrupo(competidoresGrupo, idCombate);
//       idCombate = siguienteId;
//       return {
//         nombre: `Grupo ${String.fromCharCode(65 + i)}`,
//         competidores: competidoresGrupo,
//         combates
//       };
//     });

//     if (choquesDeClub > 0) {
//       aviso.textContent = `Grupos generados con ${choquesDeClub} coincidencia(s) de club inevitable(s).`;
//     }
//     cuadro = null;
//     document.getElementById("bloqueGrupos").hidden = false;
//     document.getElementById("bloqueCuadro").hidden = true;
//     renderGrupos();
//     guardarEstado();
//     document.getElementById("bloqueGrupos").scrollIntoView({ behavior: "smooth" });
//   } catch (err) {
//     aviso.textContent = err.message;
//   }
// });

// --- Render de los grupos: clasificación en vivo + calendario editable ---
function renderGrupos() {
  const contenedor = document.getElementById("contenedorGrupos");
  contenedor.innerHTML = "";

  let todoResuelto = true;

  grupos.forEach((grupo) => {
    const card = document.createElement("div");
    card.className = "grupo-card";

    const titulo = document.createElement("h3");
    titulo.textContent = `${grupo.nombre} (${grupo.competidores.length} competidores)`;
    card.appendChild(titulo);

    const resultado = calcularClasificacion(grupo.competidores, grupo.combates, clasificadosPorGrupo);
    card.appendChild(crearTablaClasificacion(resultado, clasificadosPorGrupo));

    if (resultado.empatePendiente) {
      todoResuelto = false;
      card.appendChild(crearAvisoEmpate(grupo, resultado.empatePendiente));
    } else if (!todosLosCombatesJugados(grupo.combates)) {
      todoResuelto = false;
    }

    const listaCombates = document.createElement("div");
    listaCombates.className = "lista-combates-grupo";
    grupo.combates.forEach((combate) => listaCombates.appendChild(crearFilaCombateGrupo(grupo, combate)));
    card.appendChild(listaCombates);

    contenedor.appendChild(card);
  });

  const botonCruce = document.getElementById("botonGenerarCruce");
  botonCruce.disabled = !todoResuelto;
  document.getElementById("avisoGenerarCruce").textContent = todoResuelto
    ? ""
    : "Faltan combates por jugar o empates por resolver.";
}

function crearTablaClasificacion(resultado, clasificadosPorGrupo) {
  const tabla = document.createElement("table");
  tabla.className = "tabla-clasificacion";
  tabla.innerHTML = `<thead><tr><th>Competidor</th><th class="centrado">V</th><th class="centrado">Ippones</th></tr></thead>`;
  const cuerpo = document.createElement("tbody");
  resultado.clasificacion.forEach((fila, i) => {
    const tr = document.createElement("tr");
    if (i < clasificadosPorGrupo) tr.classList.add("clasifica");
    if (resultado.empatePendiente && resultado.empatePendiente.some((c) => c.id === fila.competidor.id)) {
      tr.classList.add("empatado");
    }
    tr.innerHTML = `<td>${escaparHtml(fila.competidor.nombre)} <span class="club-mini">(${escaparHtml(fila.competidor.club)})</span></td><td class="centrado">${fila.victorias}</td><td class="centrado">${fila.ippones}</td>`;
    cuerpo.appendChild(tr);
  });
  tabla.appendChild(cuerpo);
  return tabla;
}

function crearAvisoEmpate(grupo, empatados) {
  const div = document.createElement("div");
  div.className = "aviso-empate";
  div.innerHTML = `<strong>Empate en el corte de clasificación</strong> entre ${empatados.map((c) => escaparHtml(c.nombre)).join(" y ")}. Se necesita un combate de desempate para decidir quién pasa.`;

  if (empatados.length === 2) {
    const botones = document.createElement("div");
    botones.className = "botones-desempate";
    empatados.forEach((competidor) => {
      const boton = document.createElement("button");
      boton.textContent = `Ganó ${competidor.nombre}`;
      boton.addEventListener("click", () => resolverDesempate(grupo, empatados, competidor.id));
      botones.appendChild(boton);
    });
    div.appendChild(botones);
  } else {
    div.innerHTML += " (más de 2 empatados — resuélvelo añadiendo manualmente ippones de desempate en los combates ya jugados entre ellos)";
  }
  return div;
}

function resolverDesempate(grupo, empatados, idGanador) {
  const [a, b] = empatados;
  const yaExiste = grupo.combates.find((c) =>
    ((c.compA.id === a.id && c.compB.id === b.id) || (c.compA.id === b.id && c.compB.id === a.id)) && c.esDesempate
  );
  if (yaExiste) {
    yaExiste.ganadorId = idGanador;
    yaExiste.ipponesA = yaExiste.compA.id === idGanador ? 1 : 0;
    yaExiste.ipponesB = yaExiste.compB.id === idGanador ? 1 : 0;
  } else {
    grupo.combates.push({
      id: Math.max(...grupo.combates.map((c) => c.id)) + 1,
      compA: { id: a.id, nombre: a.nombre, club: a.club },
      compB: { id: b.id, nombre: b.nombre, club: b.club },
      ipponesA: a.id === idGanador ? 1 : 0,
      ipponesB: b.id === idGanador ? 1 : 0,
      ganadorId: idGanador,
      esDesempate: true
    });
  }
  renderGrupos();
  guardarEstado();
}

function crearFilaCombateGrupo(grupo, combate) {
  const fila = document.createElement("div");
  fila.className = "fila-combate-grupo";

  const nombreA = document.createElement("span");
  nombreA.className = "nombre-combate";
  nombreA.textContent = combate.compA.nombre;
  if (combate.ganadorId === combate.compA.id) nombreA.classList.add("ganador");
  nombreA.addEventListener("click", () => { combate.ganadorId = combate.compA.id; renderGrupos(); guardarEstado(); });

  const ipponesA = document.createElement("input");
  ipponesA.type = "number"; ipponesA.min = "0";
  ipponesA.value = combate.ipponesA ?? "";
  ipponesA.addEventListener("change", (e) => { combate.ipponesA = e.target.value === "" ? null : parseInt(e.target.value, 10); renderGrupos(); guardarEstado(); });

  const vs = document.createElement("span");
  vs.className = "separador-vs";
  vs.textContent = "vs";

  const ipponesB = document.createElement("input");
  ipponesB.type = "number"; ipponesB.min = "0";
  ipponesB.value = combate.ipponesB ?? "";
  ipponesB.addEventListener("change", (e) => { combate.ipponesB = e.target.value === "" ? null : parseInt(e.target.value, 10); renderGrupos(); guardarEstado(); });

  const nombreB = document.createElement("span");
  nombreB.className = "nombre-combate derecha";
  nombreB.textContent = combate.compB.nombre;
  if (combate.ganadorId === combate.compB.id) nombreB.classList.add("ganador");
  nombreB.addEventListener("click", () => { combate.ganadorId = combate.compB.id; renderGrupos(); guardarEstado(); });

  fila.append(nombreA, ipponesA, vs, ipponesB, nombreB);
  return fila;
}

// --- Generar el cruce hacia la eliminatoria ---
document.getElementById("botonGenerarCruce").addEventListener("click", () => {
  const gruposConClasificacion = grupos.map((grupo) => ({
    nombre: grupo.nombre,
    clasificacion: calcularClasificacion(grupo.competidores, grupo.combates, clasificadosPorGrupo).clasificacion
  }));
  cuadro = generarCruceDeGrupos(gruposConClasificacion, clasificadosPorGrupo);
  document.getElementById("bloqueCuadro").hidden = false;
  renderCuadro();
  guardarEstado();
  document.getElementById("bloqueCuadro").scrollIntoView({ behavior: "smooth" });
});

// --- Gestión de la lista de competidores ---
function renderListaCompetidores() {
  const lista = document.getElementById("listaCompetidores");
  lista.innerHTML = "";
  competidores.forEach((c, i) => {
    const li = document.createElement("li");
    li.className = "fila-competidor";
    li.innerHTML = `
      <span class="nombre">${escaparHtml(c.nombre)}</span>
      <span class="club">${escaparHtml(c.club)}</span>
      ${c.dan ? `<span class="dan">${escaparHtml(c.dan)}</span>` : ""}
      ${c.cabezaDeSerie ? `<span class="etiqueta-cabeza">Cabeza de serie</span>` : ""}
      <span class="acciones-fila">
        <button type="button" data-accion="subir" title="Subir">↑</button>
        <button type="button" data-accion="bajar" title="Bajar">↓</button>
        <button type="button" data-accion="quitar" class="quitar" title="Quitar">✕</button>
      </span>
    `;
    li.querySelector('[data-accion="subir"]').addEventListener("click", () => moverCompetidor(i, -1));
    li.querySelector('[data-accion="bajar"]').addEventListener("click", () => moverCompetidor(i, 1));
    li.querySelector('[data-accion="quitar"]').addEventListener("click", () => quitarCompetidor(i));
    lista.appendChild(li);
  });
  actualizarDisponibilidadCabezaDeSerie();
}

const LIMITE_CABEZAS_DE_SERIE = 2;

function actualizarDisponibilidadCabezaDeSerie() {
  const numCabezas = competidores.filter((c) => c.cabezaDeSerie).length;
  const campo = document.getElementById("campoCabezaDeSerie");
  const alLimite = numCabezas >= LIMITE_CABEZAS_DE_SERIE;
  campo.disabled = alLimite;
  if (alLimite) campo.checked = false;
  campo.title = alLimite
    ? `Ya hay ${LIMITE_CABEZAS_DE_SERIE} cabezas de serie — quita una para poder marcar otra`
    : "";
}

function escaparHtml(texto) {
  const div = document.createElement("div");
  div.textContent = texto;
  return div.innerHTML;
}

function moverCompetidor(indice, delta) {
  const nuevo = indice + delta;
  if (nuevo < 0 || nuevo >= competidores.length) return;
  [competidores[indice], competidores[nuevo]] = [competidores[nuevo], competidores[indice]];
  renderListaCompetidores();
  guardarEstado();
}

function quitarCompetidor(indice) {
  competidores.splice(indice, 1);
  renderListaCompetidores();
  guardarEstado();
}

document.getElementById("formCompetidor").addEventListener("submit", (evento) => {
  evento.preventDefault();
  const nombre = document.getElementById("campoNombre").value.trim();
  const club = document.getElementById("campoClub").value.trim();
  const dan = document.getElementById("campoDan").value.trim();
  const cabezaDeSerie = document.getElementById("campoCabezaDeSerie").checked;
  if (!nombre || !club) return;

  competidores.push({ id: siguienteIdCompetidor++, nombre, club, dan, cabezaDeSerie });
  evento.target.reset();
  document.getElementById("campoNombre").focus();
  renderListaCompetidores();
  guardarEstado();
});

document.getElementById("mostrarDan").addEventListener("change", (evento) => {
  mostrarDan = evento.target.checked;
  if (cuadro) renderCuadro();
  guardarEstado();
});

document.getElementById("botonBorrarTodos").addEventListener("click", () => {
  if (competidores.length === 0) return;
  if (!confirm(`¿Borrar los ${competidores.length} competidores añadidos? Esto no afecta a un cuadro ya generado, solo a la lista.`)) return;
  competidores = [];
  renderListaCompetidores();
  guardarEstado();
});

// --- Generación del cuadro ---
// document.getElementById("botonGenerar").addEventListener("click", () => {
//   const aviso = document.getElementById("avisoGenerar");
//   aviso.textContent = "";
//   if (competidores.length < 2) {
//     aviso.textContent = "Hacen falta al menos 2 competidores.";
//     return;
//   }
//   if (cuadro && !confirm("Ya existe un cuadro generado. ¿Generarlo de nuevo? Se perderán los resultados marcados hasta ahora.")) {
//     return;
//   }
//   cuadro = generarEliminatoria(competidores);
//   document.getElementById("bloqueCuadro").hidden = false;
//   renderCuadro();
//   guardarEstado();
//   document.getElementById("bloqueCuadro").scrollIntoView({ behavior: "smooth" });
// });

document.getElementById("botonGenerarTorneo").addEventListener("click", () => {
  const aviso = document.getElementById("avisoGenerarTorneo");
  aviso.textContent = "";

  if (formato === "eliminatoria") {
    if (competidores.length < 2) { aviso.textContent = "Hacen falta al menos 2 competidores."; return; }
    cuadro = generarEliminatoria(competidores);
    document.getElementById("bloqueCuadro").hidden = false;
    renderCuadro();
    guardarEstado();
    document.getElementById("bloqueCuadro").scrollIntoView({ behavior: "smooth" });
    descargarPDFEliminatoria();
    return;
  }

  // formato === "grupos"
  if (competidores.length < 4) { aviso.textContent = "Hacen falta al menos 4 competidores para formar grupos."; return; }
  try {
    estructuraGrupos = calcularEstructuraGrupos(competidores.length);
    validarClasificadosPorGrupo(clasificadosPorGrupo, estructuraGrupos.tamanos);
    const { grupos: gruposFormados } = formarGrupos(competidores, estructuraGrupos);

    let idCombate = 1;
    grupos = gruposFormados.map((competidoresGrupo, i) => {
      const { combates, siguienteId } = generarCombatesGrupo(competidoresGrupo, idCombate);
      idCombate = siguienteId;
      return { nombre: `Grupo ${String.fromCharCode(65 + i)}`, competidores: competidoresGrupo, combates };
    });

    guardarEstado();
    descargarPDFPlantillaGrupos();
  } catch (err) {
    aviso.textContent = err.message;
  }
});

function descargarPDFEliminatoria() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ orientation: "landscape", unit: "pt", format: "a4" });
  const margen = 30;
  const anchoUtil = doc.internal.pageSize.getWidth() - margen * 2;
  const altoUtil = doc.internal.pageSize.getHeight() - margen * 2 - 30;

  doc.setFont("helvetica", "bold"); doc.setFontSize(16);
  doc.text("KendoSTREAM — Cuadro de eliminatoria directa", margen, margen);
  doc.setFontSize(9); doc.setFont("helvetica", "normal");
  doc.text(new Date().toLocaleDateString("es-ES"), margen, margen + 14);

  if (cuadro.tamanoCuadro > UMBRAL_DOBLE_ALA) dibujarCuadroDobleAla(doc, cuadro, margen, anchoUtil, altoUtil);
  else dibujarCuadroLineal(doc, cuadro, margen, anchoUtil, altoUtil);

  doc.save("cuadro-kendostream.pdf");
}

// Construye una versión "plantilla" del cruce entre grupos: en vez de
// competidores reales, cada hueco de la 1ª ronda lleva una etiqueta de
// texto ("1º Grupo A"), porque todavía no se sabe quién clasificará.
function generarPlantillaGrupos(grupos, clasificadosPorGrupo) {
  const G = grupos.length;
  const Gpad = siguientePotenciaDeDos(G);

  function etiqueta(posicion, nombreGrupo) {
    return { esEtiqueta: true, texto: `${posicion}º ${nombreGrupo}` };
  }

  const primeros = grupos.map((g) => etiqueta(1, g.nombre));
  const segundos = clasificadosPorGrupo >= 2 ? grupos.map((g) => etiqueta(2, g.nombre)) : [];
  while (primeros.length < Gpad) primeros.push(null);
  while (segundos.length < Gpad) segundos.push(null);

  const combatesRonda1 = [];
  let idContador = 1;
  for (let i = 0; i < Gpad; i++) {
    const compA = primeros[i];
    const compB = clasificadosPorGrupo >= 2 ? segundos[Gpad - 1 - i] : null;
    combatesRonda1.push({ id: idContador++, posicion: i, compA, compB, ganadorId: null });
  }

  const tamanoCuadro = Gpad * (clasificadosPorGrupo >= 2 ? 2 : 1);
  const nombresRonda = calcularNombresRondas(Math.max(tamanoCuadro, 2));
  const rondas = [{ nombre: nombresRonda[0], combates: combatesRonda1 }];
  let numCombatesRondaAnterior = combatesRonda1.length;
  for (let r = 1; r < nombresRonda.length; r++) {
    const numCombates = numCombatesRondaAnterior / 2;
    const combates = [];
    for (let i = 0; i < numCombates; i++) combates.push({ id: idContador++, posicion: i, compA: null, compB: null, ganadorId: null });
    rondas.push({ nombre: nombresRonda[r], combates });
    numCombatesRondaAnterior = numCombates;
  }
  return { tamanoCuadro, rondas };
}

function descargarPDFPlantillaGrupos() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ orientation: "landscape", unit: "pt", format: "a4" });
  const margen = 30;
  const anchoUtil = doc.internal.pageSize.getWidth() - margen * 2;

  doc.setFont("helvetica", "bold"); doc.setFontSize(16);
  doc.text("KendoSTREAM — Grupos y cruce (plantilla)", margen, margen);
  doc.setFontSize(9); doc.setFont("helvetica", "normal");
  doc.text(new Date().toLocaleDateString("es-ES"), margen, margen + 14);

  // 1) Grupos: solo la lista de competidores de cada uno.
  let y = margen + 40;
  const anchoColumnaGrupo = 150;
  let x = margen;
  grupos.forEach((grupo, i) => {
    if (i > 0 && i % Math.floor(anchoUtil / anchoColumnaGrupo) === 0) { x = margen; y += 130; }
    doc.setFont("helvetica", "bold"); doc.setFontSize(10);
    doc.text(grupo.nombre, x, y);
    doc.setFont("helvetica", "normal"); doc.setFontSize(8);
    grupo.competidores.forEach((c, j) => doc.text(`${c.nombre} (${c.club})`, x, y + 14 + j * 11, { maxWidth: anchoColumnaGrupo - 10 }));
    x += anchoColumnaGrupo;
  });

  // 2) Árbol con etiquetas, en una página nueva.
  doc.addPage();
  const altoUtilPagina2 = doc.internal.pageSize.getHeight() - margen * 2 - 30;
  doc.setFont("helvetica", "bold"); doc.setFontSize(14);
  doc.text("Cruce hacia la eliminatoria", margen, margen);

  const cuadroPlantilla = generarPlantillaGrupos(grupos, clasificadosPorGrupo);
  if (cuadroPlantilla.tamanoCuadro > UMBRAL_DOBLE_ALA) {
    dibujarCuadroDobleAla(doc, cuadroPlantilla, margen, anchoUtil, altoUtilPagina2);
  } else {
    dibujarCuadroLineal(doc, cuadroPlantilla, margen, anchoUtil, altoUtilPagina2);
  }

  doc.save("grupos-y-cruce-kendostream.pdf");
}

// --- Render del cuadro y marcado de ganadores ---
function renderCuadro() {
  const contenedor = document.getElementById("contenedorCuadro");
  contenedor.innerHTML = "";

  const info = document.getElementById("infoCuadro");
  const partes = [`${competidores.length} competidores`, `cuadro de ${cuadro.tamanoCuadro}`];
  if (cuadro.numByes > 0) partes.push(`${cuadro.numByes} bye${cuadro.numByes > 1 ? "s" : ""}`);
  partes.push(cuadro.choquesDeClubRonda1 === 0
    ? "sin coincidencias de club en la 1ª ronda"
    : `${cuadro.choquesDeClubRonda1} coincidencia(s) de club inevitable(s) en la 1ª ronda`);
  if (cuadro.tamanoCuadro > UMBRAL_DOBLE_ALA) {
    partes.push("el PDF se generará a doble ala, por ser un cuadro grande");
  }
  info.textContent = partes.join(" · ");

  cuadro.rondas.forEach((ronda) => {
    const columna = document.createElement("div");
    columna.className = "columna-ronda";
    const titulo = document.createElement("div");
    titulo.className = "titulo-ronda";
    titulo.textContent = ronda.nombre;
    columna.appendChild(titulo);

    ronda.combates.forEach((combate) => {
      if (esCombateBye(combate)) return; // el ganador ya aparece directo en la siguiente ronda
      columna.appendChild(crearCajaCombate(combate));
    });

    contenedor.appendChild(columna);
  });
}

// Un "combate bye" es aquel en el que un lado está vacío y el otro ya tiene
// el pase asegurado sin jugar — no aporta nada mostrarlo como caja aparte,
// mejor que la persona aparezca directamente en la ronda donde sí juega.
function esCombateBye(combate) {
  if (combate.compA?.esEtiqueta || combate.compB?.esEtiqueta) return false;
  const soloUnLadoLleno = (!!combate.compA) !== (!!combate.compB);
  return soloUnLadoLleno && !!combate.ganadorId;
}

function crearCajaCombate(combate) {
  const caja = document.createElement("div");
  caja.className = "caja-combate";
  caja.appendChild(crearSlot(combate, "compA"));
  caja.appendChild(crearSlot(combate, "compB"));
  return caja;
}

function crearSlot(combate, lado) {
  const competidor = combate[lado];
  const div = document.createElement("div");
  div.className = "slot-competidor";

  if (!competidor) {
    div.classList.add(combate.ganadorId ? "bye" : "vacio");
    div.textContent = combate.ganadorId ? "(bye)" : "";
    return div;
  }

  div.innerHTML = `<span>${escaparHtml(competidor.nombre)}${mostrarDan && competidor.dan ? ` <span class="club-mini">(${escaparHtml(competidor.dan)})</span>` : ""}</span><span class="club-mini">${escaparHtml(competidor.club)}</span>`;

  const otroLado = lado === "compA" ? "compB" : "compA";
  const hayRival = !!combate[otroLado];
  const esGanador = combate.ganadorId === competidor.id;

  if (esGanador) div.classList.add("ganador");
  if (hayRival) {
    div.classList.add("jugable");
    div.addEventListener("click", () => marcarGanador(combate, competidor.id));
  }
  return div;
}

function marcarGanador(combate, idGanador) {
  combate.ganadorId = idGanador;
  propagarGanadores(cuadro.rondas);
  renderCuadro();
  guardarEstado();
}

// --- Exportar a PDF ---
// Umbral a partir del cual el cuadro se divide en dos alas que convergen
// hacia el centro (más fácil de leer e imprimir que una fila larguísima).
const UMBRAL_DOBLE_ALA = 32;

document.getElementById("botonLimpiarCuadro").addEventListener("click", () => {
  if (!confirm("¿Borrar el cuadro generado? Los competidores de la lista no se eliminan — podrás generar uno nuevo cuando quieras.")) return;
  cuadro = null;
  document.getElementById("bloqueCuadro").hidden = true;
  guardarEstado();
});

document.getElementById("botonPDF").addEventListener("click", () => {
  if (!cuadro) return;
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ orientation: "landscape", unit: "pt", format: "a4" });

  const margen = 30;
  const anchoUtil = doc.internal.pageSize.getWidth() - margen * 2;
  const altoUtil = doc.internal.pageSize.getHeight() - margen * 2 - 30;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.text("KendoSTREAM — Cuadro de eliminatoria directa", margen, margen);
  doc.setFontSize(9);
  doc.setFont("helvetica", "normal");
  doc.text(new Date().toLocaleDateString("es-ES"), margen, margen + 14);

  if (cuadro.tamanoCuadro > UMBRAL_DOBLE_ALA) {
    dibujarCuadroDobleAla(doc, cuadro, margen, anchoUtil, altoUtil);
  } else {
    dibujarCuadroLineal(doc, cuadro, margen, anchoUtil, altoUtil);
  }

  doc.save("cuadro-kendostream.pdf");
});

/**
 * Dibuja una única caja de combate en la posición indicada, y devuelve su
 * posición (para poder conectar líneas después). Se usa tanto en el modo
 * lineal como en cada una de las dos alas del modo grande.
 */
function dibujarCajaCombatePDF(doc, combate, x, yCentro, anchoCaja, altoCaja, mostrarDan) {
  const yCaja = yCentro - altoCaja / 2;
  doc.setDrawColor(180);
  doc.roundedRect(x, yCaja, anchoCaja, altoCaja, 3, 3);
  doc.line(x, yCaja + altoCaja / 2, x + anchoCaja, yCaja + altoCaja / 2);

  doc.setFontSize(9);
  [combate.compA, combate.compB].forEach((competidor, i) => {
    doc.setFont("helvetica", competidor && combate.ganadorId === competidor.id ? "bold" : "normal");
    const texto = competidor
      ? (competidor.esEtiqueta ? competidor.texto : `${competidor.nombre}${mostrarDan && competidor.dan ? " (" + competidor.dan + ")" : ""} — ${competidor.club}`)
      : "";
    const yTexto = yCaja + (altoCaja / 2) * i + altoCaja / 4 + 3;
    doc.text(texto, x + 5, yTexto, { maxWidth: anchoCaja - 10 });
  });
}

function dibujarConectorPDF(doc, origenA, origenB, xLinea, xDestino, yDestino) {
  if (origenA && origenB) {
    doc.line(origenA.x, origenA.yCentro, xLinea, origenA.yCentro);
    doc.line(origenB.x, origenB.yCentro, xLinea, origenB.yCentro);
    doc.line(xLinea, origenA.yCentro, xLinea, origenB.yCentro);
    doc.line(xLinea, yDestino, xDestino, yDestino);
  } else if (origenA || origenB) {
    const origen = origenA || origenB;
    doc.line(origen.x, origen.yCentro, xDestino, yDestino);
  }
}

// --- Modo lineal: el que ya conocíamos, para cuadros de hasta 32 plazas ---
function dibujarCuadroLineal(doc, cuadro, margen, anchoUtil, altoUtil) {
  const numRondas = cuadro.rondas.length;
  const anchoColumna = anchoUtil / numRondas;
  const posicionesPrevias = {};

  cuadro.rondas.forEach((ronda, indiceRonda) => {
    const x = margen + indiceRonda * anchoColumna;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.text(ronda.nombre.toUpperCase(), x, margen + 40);

    const altoCombate = altoUtil / ronda.combates.length;
    const anchoCaja = anchoColumna - 24;

    ronda.combates.forEach((combate, indiceCombate) => {
      if (esCombateBye(combate)) return;

      const yCentro = margen + 55 + altoCombate * (indiceCombate + 0.5);
      const altoCaja = Math.min(altoCombate * 0.6, 46);
      dibujarCajaCombatePDF(doc, combate, x, yCentro, anchoCaja, altoCaja, mostrarDan);
      posicionesPrevias[`${indiceRonda}-${indiceCombate}`] = { x: x + anchoCaja, yCentro };

      if (indiceRonda > 0) {
        const origenA = posicionesPrevias[`${indiceRonda - 1}-${indiceCombate * 2}`];
        const origenB = posicionesPrevias[`${indiceRonda - 1}-${indiceCombate * 2 + 1}`];
        dibujarConectorPDF(doc, origenA, origenB, x - 12, x, yCentro);
      }
    });
  });
}

// --- Modo doble ala: para cuadros grandes (más de 32 plazas) ---
// Divide cada ronda (salvo la Final) en dos mitades — la primera mitad de
// competidores forma el ala izquierda, la segunda mitad el ala derecha —
// y las dibuja convergiendo hacia el centro de la página, donde queda la
// Final. Esto mantiene el mismo criterio de siembra y de propagación de
// ganadores; solo cambia cómo se reparte en la hoja para que quepa e
// imprima bien.
function dibujarCuadroDobleAla(doc, cuadro, margen, anchoUtil, altoUtil) {
  const rondasSinFinal = cuadro.rondas.slice(0, -1);
  const rondaFinal = cuadro.rondas[cuadro.rondas.length - 1];
  const numRondasAla = rondasSinFinal.length;
  const anchoColumna = anchoUtil / (numRondasAla * 2 + 1);

  const posiciones = {}; // clave: "izq|der - indiceRonda - indiceLocal"

  function mitad(ronda, lado) {
    const n = ronda.combates.length;
    return lado === "izq" ? ronda.combates.slice(0, n / 2) : ronda.combates.slice(n / 2);
  }

  ["izq", "der"].forEach((lado) => {
    rondasSinFinal.forEach((ronda, indiceRonda) => {
      const combatesAla = mitad(ronda, lado);
      const x = lado === "izq"
        ? margen + indiceRonda * anchoColumna
        : margen + anchoUtil - anchoColumna - indiceRonda * anchoColumna;
      const xTextoTitulo = lado === "izq" ? x : x;

      doc.setFont("helvetica", "bold");
      doc.setFontSize(8);
      doc.text(ronda.nombre.toUpperCase(), xTextoTitulo, margen + 40, { maxWidth: anchoColumna - 6 });

      const altoCombate = altoUtil / combatesAla.length;
      const anchoCaja = anchoColumna - 20;

      combatesAla.forEach((combate, indiceLocal) => {
        if (esCombateBye(combate)) return;

        const yCentro = margen + 55 + altoCombate * (indiceLocal + 0.5);
        const altoCaja = Math.min(altoCombate * 0.6, 40);
        const xCaja = lado === "izq" ? x : x + (anchoColumna - anchoCaja);
        dibujarCajaCombatePDF(doc, combate, xCaja, yCentro, anchoCaja, altoCaja, mostrarDan);

        // Guardamos el borde de la caja por el que "sale" la línea hacia la
        // siguiente ronda: en la izquierda es el borde derecho, en la
        // derecha es el borde izquierdo (hacia el centro en ambos casos).
        const xSalida = lado === "izq" ? xCaja + anchoCaja : xCaja;
        posiciones[`${lado}-${indiceRonda}-${indiceLocal}`] = { x: xSalida, yCentro };

        if (indiceRonda > 0) {
          const origenA = posiciones[`${lado}-${indiceRonda - 1}-${indiceLocal * 2}`];
          const origenB = posiciones[`${lado}-${indiceRonda - 1}-${indiceLocal * 2 + 1}`];
          const xLinea = lado === "izq" ? xCaja - 10 : xCaja + anchoCaja + 10;
          dibujarConectorPDF(doc, origenA, origenB, xLinea, xCaja + (lado === "izq" ? 0 : anchoCaja), yCentro);
        }
      });
    });
  });

  // La Final, centrada, alimentada por el último combate de cada ala.
  const xFinal = margen + numRondasAla * anchoColumna;
  const anchoCajaFinal = anchoColumna - 20;
  const yCentroFinal = margen + altoUtil / 2 + 27;
  const altoCajaFinal = 42;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.text(rondaFinal.nombre.toUpperCase(), xFinal, margen + 40, { maxWidth: anchoCajaFinal });

  if (!esCombateBye(rondaFinal.combates[0])) {
    dibujarCajaCombatePDF(doc, rondaFinal.combates[0], xFinal, yCentroFinal, anchoCajaFinal, altoCajaFinal, mostrarDan);

    const origenIzq = posiciones[`izq-${numRondasAla - 1}-0`];
    const origenDer = posiciones[`der-${numRondasAla - 1}-0`];
    if (origenIzq) doc.line(origenIzq.x, origenIzq.yCentro, xFinal, yCentroFinal);
    if (origenDer) doc.line(origenDer.x, origenDer.yCentro, xFinal + anchoCajaFinal, yCentroFinal);
  }
}

cargarEstado();
