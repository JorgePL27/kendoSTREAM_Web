// server.js
// KendoSTREAM — © 2026 Jorge Pascual Lansac. Distribuido bajo PolyForm
// Noncommercial License 1.0.0 — ver LICENSE.txt en la raíz del proyecto.
//
// Servidor local de KendoSTREAM.
// - Sirve el panel de control y el overlay como páginas web estáticas.
// - Mantiene el estado del combate en memoria.
// - Aplica las acciones del operador a través del motor (motor/motor.js).
// - Guarda automáticamente el estado en data/estado.json.
// - Difunde el estado actualizado a todos los clientes conectados (panel y overlay)
//   por WebSocket, para que se actualicen en tiempo real.

const path = require("path");
const fs = require("fs");
const express = require("express");
const { WebSocketServer } = require("ws");
const { estadoInicial, aplicarAccion, normalizarEstado } = require("./motor/motor");
const { crearRegistro } = require("./registro/registro");

const PUERTO = process.env.PUERTO || 3000;
const RUTA_ESTADO = path.join(__dirname, "data", "estado.json");

// --- Estado en memoria ---
// (Deshacer ya no usa un historial del servidor: lo gestiona el motor con el
// registro de eventos del combate, que viaja dentro del estado.)
let estado = arrancarEstado();

// Lee data/estado.json y lo adapta a la versión actual (un estado antiguo se
// completa, no se descarta). Si no existe o no sirve, empieza de cero.
function arrancarEstado() {
  try {
    return normalizarEstado(cargarEstadoDesdeDisco()) || estadoInicial();
  } catch (err) {
    console.error("No se pudo adaptar el estado guardado, se empieza de cero:", err.message);
    return estadoInicial();
  }
}

const packageJson = require("./package.json");
let infoVersion = { actual: packageJson.version, disponible: null, hayNueva: false };

// --- Registro de resultados (un JSON por evento; ver registro/registro.js) ---
// Es independiente del marcador: si falla, todo lo demás sigue funcionando.
const registro = crearRegistro({
  rutaAjustes: path.join(__dirname, "data", "ajustes.json"),
  carpetaRespaldo: path.join(__dirname, "data", "respaldo"),
  version: packageJson.version,
  alCambiar: () => difundirRegistro()
});

// Compara versiones tipo "2.0", "2.0.0" o "2.1.3" por partes numéricas.
// Devuelve true solo si "disponible" es estrictamente mayor que "actual".
function esMasNueva(disponible, actual) {
  const aNumeros = (v) => String(v).split(".").map((n) => parseInt(n, 10) || 0);
  const a = aNumeros(disponible);
  const b = aNumeros(actual);
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    const x = a[i] || 0;
    const y = b[i] || 0;
    if (x !== y) return x > y;
  }
  return false;
}

function comprobarVersionEnLinea() {
  const https = require("https");
  const peticion = https.get("https://kendostream.com/version.json", { timeout: 4000 }, (res) => {
    let datos = "";
    res.on("data", (trozo) => (datos += trozo));
    res.on("end", () => {
      try {
        const info = JSON.parse(datos);
        infoVersion = {
          actual: packageJson.version,
          disponible: info.version,
          hayNueva: esMasNueva(info.version, packageJson.version),
          url: info.url || "https://kendostream.com/novedades.html"
        };
      } catch (err) { /* respuesta inválida, se ignora sin más */ }
    });
  });
  peticion.on("error", () => {}); // sin internet: no pasa nada, sigue como siempre
  peticion.on("timeout", () => peticion.destroy());
}
comprobarVersionEnLinea(); // se comprueba una vez, al arrancar el servidor

function cargarEstadoDesdeDisco() {
  try {
    const contenido = fs.readFileSync(RUTA_ESTADO, "utf-8");
    return JSON.parse(contenido);
  } catch (err) {
    return null; // no existe todavía o está corrupto: se usará el estado inicial
  }
}

function guardarEstadoEnDisco() {
  fs.mkdir(path.dirname(RUTA_ESTADO), { recursive: true }, () => {
    fs.writeFile(RUTA_ESTADO, JSON.stringify(estado, null, 2), (err) => {
      if (err) console.error("Error guardando el estado:", err.message);
    });
  });
}

function difundirEstado() {
  const mensaje = JSON.stringify({ tipo: "ESTADO", estado });
  wss.clients.forEach((cliente) => {
    if (cliente.readyState === cliente.OPEN) cliente.send(mensaje);
  });
}

// El estado del registro viaja aparte del estado del combate: lo ve el panel, nunca el overlay.
function difundirRegistro() {
  const mensaje = JSON.stringify({ tipo: "REGISTRO", registro: registro.estado() });
  wss.clients.forEach((cliente) => {
    if (cliente.readyState === cliente.OPEN) cliente.send(mensaje);
  });
}

// --- Express: servir el panel y el overlay ---
const app = express();
app.use(express.json());
app.use("/panel", express.static(path.join(__dirname, "public/panel")));
app.use("/overlay", express.static(path.join(__dirname, "public/overlay")));
app.use("/config", express.static(path.join(__dirname, "public/config")));
app.use("/assets", express.static(path.join(__dirname, "public/assets")));
app.use("/fotos-competidores", express.static(path.join(__dirname, "public/fotos-competidores")));
app.use("/logos-clubes", express.static(path.join(__dirname, "public/logos-clubes")));
app.get("/", (req, res) => res.redirect("/panel"));
app.use("/organizador", express.static(path.join(__dirname, "public/organizador")));
app.get("/api/torneo", (req, res) => {
  try {
    const contenido = fs.readFileSync(path.join(__dirname, "data/torneo.json"), "utf-8");
    res.json(JSON.parse(contenido));
  } catch (err) {
    res.json({ competidores: [], mostrarDan: true, cuadro: null });
  }
});
app.post("/api/torneo", (req, res) => {
  fs.mkdir(path.join(__dirname, "data"), { recursive: true }, () => {
    fs.writeFile(path.join(__dirname, "data/torneo.json"), JSON.stringify(req.body, null, 2), (err) => {
      if (err) return res.status(500).json({ error: "No se pudo guardar" });
      res.json({ ok: true });
    });
  });
});

// Extensiones de imagen admitidas al listar archivos disponibles
const EXTENSIONES_IMAGEN = [".png", ".jpg", ".jpeg", ".webp"];

function listarImagenes(carpeta) {
  try {
    return fs.readdirSync(carpeta)
      .filter((archivo) => EXTENSIONES_IMAGEN.includes(path.extname(archivo).toLowerCase()))
      .sort();
  } catch (err) {
    return []; // la carpeta no existe todavía: sin archivos disponibles
  }
}

app.get("/api/fotos-competidores", (req, res) => {
  res.json(listarImagenes(path.join(__dirname, "public/fotos-competidores")));
});

app.get("/api/logos-clubes", (req, res) => {
  res.json(listarImagenes(path.join(__dirname, "public/logos-clubes")));
});

// Diseños de overlay disponibles: se detectan automáticamente a partir de los
// archivos .css que haya en public/overlay/temas/. Así, un diseño nuevo (propio
// o personalizado para un club) solo requiere añadir el archivo ahí — no hay
// que tocar código para que aparezca en el desplegable de /config.
app.get("/api/temas", (req, res) => {
  try {
    const archivos = fs.readdirSync(path.join(__dirname, "public/overlay/temas"))
      .filter((archivo) => archivo.endsWith(".css"))
      .map((archivo) => archivo.replace(/\.css$/, ""))
      .sort();
    res.json(archivos);
  } catch (err) {
    res.json(["clasico"]); // último recurso: siempre debe existir al menos el clásico
  }
});

app.get("/api/version", (req, res) => res.json(infoVersion));

// --- API del registro de resultados ---
// Elegir la carpeta (y probarla) solo se permite desde este mismo ordenador:
// cambia dónde escribe el programa en el disco.
function soloLocal(req, res, next) {
  const ip = req.socket.remoteAddress || "";
  if (ip === "127.0.0.1" || ip === "::1" || ip === "::ffff:127.0.0.1") return next();
  res.status(403).json({ ok: false, codigo: "solo_local", mensaje: "Esto solo se puede hacer desde el ordenador donde corre KendoSTREAM." });
}

function responder(res, accion) {
  try {
    res.json(Object.assign({ ok: true }, accion()));
  } catch (err) {
    res.status(err.codigo ? 400 : 500).json({ ok: false, codigo: err.codigo || "error", mensaje: err.message, detalle: err.detalle || null });
  }
}

app.get("/api/registro", (req, res) => res.json(registro.estado()));
app.get("/api/registro/archivos", (req, res) => responder(res, () => registro.listarArchivos()));
app.post("/api/registro/nuevo", (req, res) =>
  // el nombre del evento sale del propio estado del torneo, no del navegador
  responder(res, () => registro.nuevo({ nombre: estado.evento.nombreTorneo }))
);
app.post("/api/registro/continuar", (req, res) =>
  responder(res, () => registro.continuar({ archivo: req.body.archivo, ultimo: req.body.ultimo === true }))
);
app.post("/api/registro/detener", (req, res) => responder(res, () => registro.detener()));
app.post("/api/registro/probar-carpeta", soloLocal, (req, res) =>
  res.json(registro.probarCarpeta(req.body.carpeta))
);
app.get("/api/ajustes", (req, res) => res.json(registro.ajustes()));
app.post("/api/ajustes", soloLocal, (req, res) =>
  responder(res, () => registro.guardarCarpeta(req.body.carpeta))
);

const servidorHttp = app.listen(PUERTO, () => {
  console.log(`KendoSTREAM escuchando en http://localhost:${PUERTO}`);
  console.log(`  Panel:   http://localhost:${PUERTO}/panel`);
  console.log(`  Overlay: http://localhost:${PUERTO}/overlay`);
});

// --- WebSocket: comunicación en tiempo real ---
const wss = new WebSocketServer({ server: servidorHttp });

wss.on("connection", (ws) => {
  // al conectar, enviamos el estado actual (panel u overlay recién abiertos)
  ws.send(JSON.stringify({ tipo: "ESTADO", estado }));
  ws.send(JSON.stringify({ tipo: "REGISTRO", registro: registro.estado() }));

  ws.on("message", (mensajeBruto) => {
    let mensaje;
    try {
      mensaje = JSON.parse(mensajeBruto);
    } catch (err) {
      return; // mensaje mal formado, se ignora
    }

    if (mensaje.tipo === "ACCION") {
      const accion = mensaje.accion;
      if (!accion || typeof accion.tipo !== "string") return; // acción mal formada, se ignora

      const yaFinalizado = !!(estado.combate && estado.combate.resultado);
      try {
        estado = aplicarAccion(estado, accion); // DESHACER también lo resuelve el motor
      } catch (err) {
        console.error("Error aplicando la acción", accion.tipo + ":", err.message);
        return; // el estado anterior sigue intacto
      }

      guardarEstadoEnDisco();
      difundirEstado();

      // Al finalizar un combate se guarda en el registro (si está activo).
      // Reabrir y volver a finalizar sobrescribe el mismo registro (mismo id).
      if (accion.tipo === "FINALIZAR_COMBATE" && !yaFinalizado && estado.combate.resultado) {
        registro.guardarCombate(estado);
      }
    }
  });
});

// --- Cierre limpio: Ctrl+C, cierre de la terminal o parada del sistema ---
// Deja escrito el último estado y el registro, y libera el archivo de resultados.
let cerrando = false;
function cerrarLimpio(senal) {
  if (cerrando) return;
  cerrando = true;
  console.log(`\nCerrando KendoSTREAM (${senal})…`);
  try {
    fs.mkdirSync(path.dirname(RUTA_ESTADO), { recursive: true });
    fs.writeFileSync(RUTA_ESTADO, JSON.stringify(estado, null, 2));
  } catch (err) {
    console.error("No se pudo guardar el estado al cerrar:", err.message);
  }
  try {
    registro.cerrar();
  } catch (err) {
    console.error("No se pudo cerrar el registro:", err.message);
  }
  process.exit(0);
}
["SIGINT", "SIGTERM", "SIGHUP", "SIGBREAK"].forEach((senal) => {
  try { process.on(senal, () => cerrarLimpio(senal)); } catch (err) { /* señal no disponible en este sistema */ }
});
