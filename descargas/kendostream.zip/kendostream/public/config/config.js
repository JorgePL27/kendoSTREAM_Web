// config.js — página de configuración del organizador
// KendoSTREAM — © 2026 Jorge Pascual Lansac. Distribuido bajo PolyForm
// Noncommercial License 1.0.0 — ver LICENSE.txt en la raíz del proyecto.

// Nombres "bonitos" para diseños conocidos; cualquier otro archivo .css que
// aparezca en public/overlay/temas/ (por ejemplo, uno personalizado para un
// club) se muestra igualmente, con su nombre de archivo tal cual.
const NOMBRES_DISENO = {
  clasico: "Clásico (por defecto)",
  kendostream: "KendoSTREAM"
};

let ws;
const selectorDiseno = document.getElementById("selectorDiseno");
const estadoGuardadoDiseno = document.getElementById("estadoGuardadoDiseno");
const checkboxCampeonato = document.getElementById("modoCampeonato");
const estadoGuardadoCampeonato = document.getElementById("estadoGuardadoCampeonato");
const selectorIdioma = document.getElementById("selectorIdioma");
const estadoGuardadoIdioma = document.getElementById("estadoGuardadoIdioma");

function mostrarGuardado(el) {
  el.textContent = "Guardado — se aplica al instante.";
  setTimeout(() => (el.textContent = ""), 2500);
}

async function cargarDisenosDisponibles() {
  try {
    const disenos = await fetch("/api/temas").then((r) => r.json());
    const valorActual = selectorDiseno.value;
    selectorDiseno.innerHTML = "";
    disenos.forEach((id) => {
      const opcion = document.createElement("option");
      opcion.value = id;
      opcion.textContent = NOMBRES_DISENO[id] || id;
      selectorDiseno.appendChild(opcion);
    });
    if (valorActual) selectorDiseno.value = valorActual;
  } catch (err) {
    console.error("No se pudieron cargar los diseños disponibles:", err.message);
  }
}

function conectar() {
  ws = new WebSocket(`ws://${location.host}`);
  ws.onmessage = (evento) => {
    const mensaje = JSON.parse(evento.data);
    if (mensaje.tipo === "ESTADO") {
      selectorDiseno.value = mensaje.estado.configuracion.disenoMarcador;
      checkboxCampeonato.checked = mensaje.estado.configuracion.modoCampeonatoImportante;
      selectorIdioma.value = mensaje.estado.configuracion.idioma || "es";
      aplicarIdioma(mensaje.estado.configuracion.idioma || "es");
    }
  };
  ws.onclose = () => setTimeout(conectar, 1500);
}

function enviarAccion(accion) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ tipo: "ACCION", accion }));
  }
}

selectorDiseno.addEventListener("change", () => {
  enviarAccion({ tipo: "CAMBIAR_DISENO_MARCADOR", valor: selectorDiseno.value });
  mostrarGuardado(estadoGuardadoDiseno);
});

checkboxCampeonato.addEventListener("change", () => {
  enviarAccion({ tipo: "TOGGLE_MODO_CAMPEONATO_IMPORTANTE" });
  mostrarGuardado(estadoGuardadoCampeonato);
});

selectorIdioma.addEventListener("change", () => {
  enviarAccion({ tipo: "CAMBIAR_IDIOMA", valor: selectorIdioma.value });
  mostrarGuardado(estadoGuardadoIdioma);
});

cargarDisenosDisponibles();
conectar();
