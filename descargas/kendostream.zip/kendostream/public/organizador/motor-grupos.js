// motor-grupos.js
// KendoSTREAM — Organizador de torneos: fase de grupos.
// Igual que motor-eliminatoria.js, es lógica pura: sin red ni DOM.

function siguientePotenciaDeDos(n) {
  let p = 1;
  while (p < n) p *= 2;
  return p;
}

function mezclar(array, aleatorio = Math.random) {
  const copia = array.slice();
  for (let i = copia.length - 1; i > 0; i--) {
    const j = Math.floor(aleatorio() * (i + 1));
    [copia[i], copia[j]] = [copia[j], copia[i]];
  }
  return copia;
}

// Funciones del motor de eliminatoria: con require en Node, globales en el navegador.
function dependenciasEliminatoria() {
  return typeof module !== "undefined" && module.exports ? require("./motor-eliminatoria") : window;
}

// ---------------------------------------------------------------------------
// Estructura de grupos
// ---------------------------------------------------------------------------

// Huecos (byes) que tendría el cuadro eliminatorio con esta cantidad de grupos.
function huecosDelCuadro(numGrupos, clasificadosPorGrupo) {
  const plazas = numGrupos * clasificadosPorGrupo;
  return siguientePotenciaDeDos(plazas) - plazas;
}

// Con 2 clasificados por grupo, los byes solo pueden ser para 1.º de grupo si
// hay como máximo tantos byes como grupos. Con 1 clasificado siempre se cumple.
function cruceEvitaByesASegundos(numGrupos, clasificadosPorGrupo) {
  if (clasificadosPorGrupo !== 2) return true;
  const huecosPorAla = siguientePotenciaDeDos(numGrupos) - numGrupos;
  return huecosPorAla * 2 <= numGrupos;
}

/**
 * Elige cuántos grupos formar y de qué tamaño.
 *  - Tamaños permitidos: 4, 3 y, como máximo, UN grupo de 2 (salvo n = 4,
 *    donde la única opción es 2 grupos de 2).
 *  - Prioridad: 1) que ningún 2.º tenga que saltarse la 1.ª ronda,
 *    2) cuadro eliminatorio con el mínimo de huecos,
 *    3) grupos lo más cercanos posible a 3, 4) menos grupos.
 * Devuelve { numGrupos, tamanos, huecosCuadro, evitaByesASegundos }.
 */
function calcularEstructuraGrupos(n, clasificadosPorGrupo = 2) {
  if (n < 4) {
    throw new Error("Hacen falta al menos 4 competidores para poder formar grupos (mínimo 2 grupos).");
  }

  function candidatas(maxGruposDeDos) {
    const lista = [];
    for (let g = 2; g <= Math.floor(n / 2); g++) {
      for (let dos = 0; dos <= Math.min(g, maxGruposDeDos); dos++) {
        const resto = g - dos;            // grupos de 3 o de 4
        const suma = n - 2 * dos;         // competidores en esos grupos
        const cuatros = suma - 3 * resto; // 4a + 3b = 3(a+b) + a
        const treses = resto - cuatros;
        if (cuatros < 0 || treses < 0) continue;
        const tamanos = [...Array(cuatros).fill(4), ...Array(treses).fill(3), ...Array(dos).fill(2)];
        lista.push({ numGrupos: g, tamanos });
      }
    }
    return lista;
  }

  let lista = candidatas(1);
  if (lista.length === 0) lista = candidatas(Infinity); // n = 4
  // Si el nº de clasificados lo permite, descartamos grupos más pequeños que eso.
  const suficientes = lista.filter((c) => Math.min(...c.tamanos) >= clasificadosPorGrupo);
  if (suficientes.length > 0) lista = suficientes;

  const puntuada = lista.map((c) => ({
    ...c,
    huecosCuadro: huecosDelCuadro(c.numGrupos, clasificadosPorGrupo),
    evitaByesASegundos: cruceEvitaByesASegundos(c.numGrupos, clasificadosPorGrupo),
    desviacion: c.tamanos.reduce((acc, t) => acc + Math.abs(t - 3), 0)
  }));

  puntuada.sort((a, b) =>
    (a.evitaByesASegundos === b.evitaByesASegundos ? 0 : a.evitaByesASegundos ? -1 : 1) ||
    a.huecosCuadro - b.huecosCuadro ||
    a.desviacion - b.desviacion ||
    a.numGrupos - b.numGrupos
  );

  const mejor = puntuada[0];
  return {
    numGrupos: mejor.numGrupos,
    tamanos: mejor.tamanos,
    huecosCuadro: mejor.huecosCuadro,
    evitaByesASegundos: mejor.evitaByesASegundos
  };
}

function validarClasificadosPorGrupo(clasificadosPorGrupo, tamanos) {
  const tamanoMinimo = Math.min(...tamanos);
  if (clasificadosPorGrupo < 1) {
    throw new Error("Tiene que clasificar al menos 1 competidor por grupo.");
  }
  if (clasificadosPorGrupo > tamanoMinimo) {
    throw new Error(`No puedes clasificar ${clasificadosPorGrupo} por grupo: el grupo más pequeño solo tiene ${tamanoMinimo} competidores.`);
  }
}

// ---------------------------------------------------------------------------
// Reparto de competidores en grupos
// ---------------------------------------------------------------------------

function contarChoquesDeClubEnGrupos(grupos) {
  let choques = 0;
  grupos.forEach((grupo) => {
    for (let i = 0; i < grupo.length; i++) {
      for (let j = i + 1; j < grupo.length; j++) {
        if (grupo[i].club && grupo[j].club && grupo[i].club.trim().toLowerCase() === grupo[j].club.trim().toLowerCase()) {
          choques++;
        }
      }
    }
  });
  return choques;
}

/**
 * opciones: { evitarMismoClub (por defecto true), intentosAntiChoque, aleatorio }
 * Con evitarMismoClub = false se hace un único reparto aleatorio.
 */
function formarGrupos(competidores, estructura, opciones = {}) {
  const evitarMismoClub = opciones.evitarMismoClub !== false;
  const aleatorio = opciones.aleatorio || Math.random;
  const intentos = evitarMismoClub ? (opciones.intentosAntiChoque || 300) : 1;
  const { numGrupos, tamanos } = estructura;

  if (competidores.length !== tamanos.reduce((a, b) => a + b, 0)) {
    throw new Error("El número de competidores no coincide con la estructura de grupos calculada.");
  }

  const cabezasDeSerie = competidores.filter((c) => c.cabezaDeSerie);
  const resto = mezclar(competidores.filter((c) => !c.cabezaDeSerie), aleatorio);

  const plantillaBase = tamanos.map(() => []);
  const cabezasColocadas = [];
  cabezasDeSerie.forEach((c, i) => {
    if (i < numGrupos) {
      plantillaBase[i].push(c);
      cabezasColocadas.push(c.id);
    }
  });
  const pendientes = [
    ...cabezasDeSerie.filter((c) => !cabezasColocadas.includes(c.id)),
    ...resto
  ];

  let mejorReparto = null;
  let mejorPuntuacion = Infinity;

  for (let intento = 0; intento < intentos; intento++) {
    const grupos = plantillaBase.map((g) => g.slice());
    const orden = mezclar(pendientes, aleatorio);
    let cursor = 0;
    for (let g = 0; g < numGrupos; g++) {
      while (grupos[g].length < tamanos[g]) {
        grupos[g].push(orden[cursor++]);
      }
    }
    const puntuacion = contarChoquesDeClubEnGrupos(grupos);
    if (puntuacion < mejorPuntuacion) {
      mejorPuntuacion = puntuacion;
      mejorReparto = grupos;
    }
    if (mejorPuntuacion === 0) break;
  }

  return { grupos: mejorReparto, choquesDeClub: mejorPuntuacion };
}

function generarCombatesGrupo(competidoresGrupo, idInicial) {
  const combates = [];
  let id = idInicial;
  for (let i = 0; i < competidoresGrupo.length; i++) {
    for (let j = i + 1; j < competidoresGrupo.length; j++) {
      combates.push({
        id: id++,
        compA: { id: competidoresGrupo[i].id, nombre: competidoresGrupo[i].nombre, club: competidoresGrupo[i].club },
        compB: { id: competidoresGrupo[j].id, nombre: competidoresGrupo[j].nombre, club: competidoresGrupo[j].club },
        ipponesA: null,
        ipponesB: null,
        ganadorId: null
      });
    }
  }
  return { combates, siguienteId: id };
}

function calcularClasificacion(competidoresGrupo, combates, clasificadosPorGrupo) {
  const stats = {};
  competidoresGrupo.forEach((c) => { stats[c.id] = { competidor: c, victorias: 0, ippones: 0, jugados: 0 }; });

  combates.forEach((combate) => {
    if (combate.ganadorId == null || combate.ipponesA == null || combate.ipponesB == null) return;
    stats[combate.compA.id].jugados++;
    stats[combate.compB.id].jugados++;
    stats[combate.compA.id].ippones += combate.ipponesA;
    stats[combate.compB.id].ippones += combate.ipponesB;
    if (combate.ganadorId === combate.compA.id) stats[combate.compA.id].victorias++;
    else if (combate.ganadorId === combate.compB.id) stats[combate.compB.id].victorias++;
  });

  const filas = Object.values(stats).sort((a, b) => {
    if (b.victorias !== a.victorias) return b.victorias - a.victorias;
    return b.ippones - a.ippones;
  });

  let empatePendiente = null;
  if (clasificadosPorGrupo && clasificadosPorGrupo < filas.length) {
    const ultimoQueClasifica = filas[clasificadosPorGrupo - 1];
    const primeroQueNoClasifica = filas[clasificadosPorGrupo];
    if (ultimoQueClasifica.victorias === primeroQueNoClasifica.victorias &&
        ultimoQueClasifica.ippones === primeroQueNoClasifica.ippones) {
      const valorVictorias = ultimoQueClasifica.victorias;
      const valorIppones = ultimoQueClasifica.ippones;
      empatePendiente = filas
        .filter((f) => f.victorias === valorVictorias && f.ippones === valorIppones)
        .map((f) => f.competidor);
    }
  }

  return {
    clasificacion: filas.map((f) => ({
      competidor: f.competidor,
      victorias: f.victorias,
      ippones: f.ippones,
      jugados: f.jugados
    })),
    empatePendiente
  };
}

function todosLosCombatesJugados(combates) {
  return combates.every((c) => c.ganadorId != null && c.ipponesA != null && c.ipponesB != null);
}

// ---------------------------------------------------------------------------
// Cruce de grupos hacia la eliminatoria (2 clasificados por grupo)
// ---------------------------------------------------------------------------

/**
 * Planifica la 1.ª ronda del cuadro como "plazas" abstractas, sin competidores:
 * { puesto: 1|2, grupo: índice de grupo } o null (bye).
 *
 * Reglas:
 *  - El cuadro se divide en dos alas. En el ala 1 están los 1.º de la primera
 *    mitad de grupos y los 2.º de la segunda mitad; en el ala 2, al revés. Así
 *    el 1.º y el 2.º de un mismo grupo solo pueden reencontrarse en la final.
 *  - Los byes (huecos) se reparten a partes iguales entre las dos alas y van
 *    siempre a 1.º de grupo (los primeros de cada ala). Si no hay suficientes
 *    1.º para todos los byes (no ocurre con una estructura bien elegida), los
 *    sobrantes van a 2.º y se indica en byesASegundos.
 *  - Los combates se emparejan 1.º contra 2.º de otro grupo (el 1.º del primer
 *    grupo contra el 2.º del último de su ala, etc.).
 *
 * Devuelve { tamanoCuadro, numByes, byesASegundos, partidos: [{ a, b }] }
 */
function planificarCruceDeGrupos(numGrupos, clasificadosPorGrupo = 2) {
  if (clasificadosPorGrupo !== 2) {
    throw new Error("El cruce automático entre grupos solo está resuelto para 2 clasificados por grupo.");
  }
  if (numGrupos < 2) throw new Error("Hacen falta al menos 2 grupos para generar el cruce.");

  const { generarOrdenSiembra } = dependenciasEliminatoria();
  const G = numGrupos;
  const Gpad = siguientePotenciaDeDos(G);
  const huecosPorAla = Gpad - G;
  const combatesPorAla = Gpad / 2;
  const mitad = Math.floor(G / 2);

  const indices = (desde, hasta) => {
    const r = [];
    for (let i = desde; i < hasta; i++) r.push(i);
    return r;
  };
  const gruposIzq = indices(0, mitad);
  const gruposDer = indices(mitad, G);

  function armarAla(gruposPrimeros, gruposSegundos) {
    const primeros = gruposPrimeros.map((grupo) => ({ puesto: 1, grupo }));
    const segundos = gruposSegundos.map((grupo) => ({ puesto: 2, grupo }));

    const conBye = primeros.slice(0, huecosPorAla);
    let segundosDisponibles = segundos;
    if (conBye.length < huecosPorAla) {
      const faltan = huecosPorAla - conBye.length;
      conBye.push(...segundos.slice(0, faltan));
      segundosDisponibles = segundos.slice(faltan);
    }
    const primerosJuegan = primeros.slice(Math.min(huecosPorAla, primeros.length));
    const segundosInvertidos = segundosDisponibles.slice().reverse();

    const partidos = conBye.map((plaza) => ({ a: plaza, b: null }));
    const emparejables = Math.min(primerosJuegan.length, segundosInvertidos.length);
    for (let j = 0; j < emparejables; j++) {
      partidos.push({ a: primerosJuegan[j], b: segundosInvertidos[j] });
    }
    const sobrantes = [...primerosJuegan.slice(emparejables), ...segundosInvertidos.slice(emparejables)];
    for (let k = 0; k < sobrantes.length; k += 2) {
      partidos.push({ a: sobrantes[k], b: sobrantes[k + 1] });
    }

    // Sin byes, se mantiene el orden natural (1.º del grupo A arriba, etc.).
    // Con byes, se separan los combates con bye para que no coincidan juntos.
    if (huecosPorAla === 0) return partidos;
    const colocados = new Array(partidos.length);
    generarOrdenSiembra(partidos.length).forEach((rango, posicion) => {
      colocados[posicion] = partidos[rango - 1];
    });
    return colocados;
  }

  const partidos = [
    ...armarAla(gruposIzq, gruposDer),
    ...armarAla(gruposDer, gruposIzq)
  ];

  const numByes = partidos.filter((p) => p.a && !p.b).length;
  const byesASegundos = partidos.filter((p) => p.a && !p.b && p.a.puesto === 2).length;
  return { tamanoCuadro: Gpad * 2, numByes, byesASegundos, partidos };
}

/**
 * opciones: { evitarMismoClub, aleatorio } — solo se usan con 1 clasificado
 * por grupo (con 2, el cruce es fijo y no se sortea).
 */
function generarCruceDeGrupos(gruposConClasificacion, clasificadosPorGrupo, opciones = {}) {
  const { generarEliminatoria, propagarGanadores, calcularNombresRondas } = dependenciasEliminatoria();

  if (clasificadosPorGrupo === 1) {
    const ganadores = gruposConClasificacion.map((g) => g.clasificacion[0].competidor);
    return generarEliminatoria(ganadores, {
      evitarMismoClub: opciones.evitarMismoClub,
      aleatorio: opciones.aleatorio
    });
  }

  if (clasificadosPorGrupo !== 2) {
    throw new Error("El cruce automático entre grupos solo está resuelto para 1 o 2 clasificados por grupo.");
  }

  const plan = planificarCruceDeGrupos(gruposConClasificacion.length, 2);

  function competidorDe(plaza) {
    if (!plaza) return null;
    const c = gruposConClasificacion[plaza.grupo].clasificacion[plaza.puesto - 1].competidor;
    return { id: c.id, nombre: c.nombre, club: c.club, dan: c.dan };
  }

  let idContador = 1;
  const combatesRonda1 = plan.partidos.map((partido, i) => {
    const compA = competidorDe(partido.a);
    const compB = competidorDe(partido.b);
    let ganadorId = null;
    if (compA && !compB) ganadorId = compA.id;
    if (compB && !compA) ganadorId = compB.id;
    return { id: idContador++, posicion: i, compA, compB, ganadorId };
  });

  const nombresRonda = calcularNombresRondas(plan.tamanoCuadro);
  const rondas = [{ nombre: nombresRonda[0], combates: combatesRonda1 }];

  let numCombatesRondaAnterior = combatesRonda1.length;
  for (let r = 1; r < nombresRonda.length; r++) {
    const numCombates = numCombatesRondaAnterior / 2;
    const combates = [];
    for (let i = 0; i < numCombates; i++) {
      combates.push({ id: idContador++, posicion: i, compA: null, compB: null, ganadorId: null });
    }
    rondas.push({ nombre: nombresRonda[r], combates });
    numCombatesRondaAnterior = numCombates;
  }

  propagarGanadores(rondas);

  const choquesDeClub = combatesRonda1.filter((c) =>
    c.compA && c.compB && c.compA.club && c.compB.club &&
    c.compA.club.trim().toLowerCase() === c.compB.club.trim().toLowerCase()
  ).length;

  return {
    tamanoCuadro: plan.tamanoCuadro,
    numByes: plan.numByes,
    byesASegundos: plan.byesASegundos,
    choquesDeClubRonda1: choquesDeClub,
    rondas
  };
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    calcularEstructuraGrupos,
    validarClasificadosPorGrupo,
    formarGrupos,
    generarCombatesGrupo,
    calcularClasificacion,
    todosLosCombatesJugados,
    planificarCruceDeGrupos,
    generarCruceDeGrupos,
    siguientePotenciaDeDos
  };
}
