// lista-competidores.test.js — pruebas de guardar/cargar listas (node --test)
const test = require("node:test");
const assert = require("node:assert/strict");
const {
  serializarListaCompetidores,
  leerListaCompetidores,
  normalizarIntegrantes,
  huecosPermitidosEquipo,
  puestosEquipo
} = require("./lista-competidores");

const lista = [
  { id: 7, nombre: "Ana", club: "Madrid Kendo", dan: "3 dan", cabezaDeSerie: true },
  { id: 9, nombre: "Luis", club: "Sevilla", dan: "", cabezaDeSerie: false },
  { id: 12, nombre: "Marta", club: "Madrid Kendo", cabezaDeSerie: true }
];

function archivo(parche) {
  return JSON.stringify({ formato: "kendostream-lista-competidores", version: 1, tipo: "individual", competidores: [{ nombre: "A", club: "X" }], ...parche });
}

test("ida y vuelta: conserva orden, dan y cabezas de serie; reasigna ids", () => {
  const { tipo, competidores, avisos } = leerListaCompetidores(serializarListaCompetidores(lista));
  assert.equal(tipo, "individual");
  assert.deepEqual(avisos, []);
  assert.deepEqual(competidores, [
    { id: 1, nombre: "Ana", club: "Madrid Kendo", dan: "3 dan", cabezaDeSerie: true },
    { id: 2, nombre: "Luis", club: "Sevilla", dan: "", cabezaDeSerie: false },
    { id: 3, nombre: "Marta", club: "Madrid Kendo", dan: "", cabezaDeSerie: true }
  ]);
});

test("el archivo incluye formato, versión y tipo, y no guarda ids", () => {
  const datos = JSON.parse(serializarListaCompetidores(lista));
  assert.equal(datos.formato, "kendostream-lista-competidores");
  assert.equal(datos.version, 1);
  assert.equal(datos.tipo, "individual");
  assert.ok(datos.competidores.every((c) => !("id" in c)));
});

test("rechaza archivos inválidos con mensajes claros", () => {
  assert.throws(() => leerListaCompetidores("esto no es json"), /JSON válido/);
  assert.throws(() => leerListaCompetidores("[]"), /no parece una lista/);
  assert.throws(() => leerListaCompetidores(JSON.stringify({ competidores: [] })), /no parece una lista/);
  assert.throws(() => leerListaCompetidores(archivo({ version: 99 })), /versión más reciente/);
  assert.throws(() => leerListaCompetidores(archivo({ tipo: "otro" })), /desconocido/);
  assert.throws(() => leerListaCompetidores(archivo({ competidores: [] })), /ningún competidor/);
  assert.throws(() => leerListaCompetidores(archivo({ competidores: [{ nombre: "A", club: "X" }, { nombre: " ", club: "Y" }] })), /nº 2/);
});

test("sin campo tipo se asume individual; limpia espacios y acepta dan numérico", () => {
  const texto = JSON.stringify({
    formato: "kendostream-lista-competidores", version: 1,
    competidores: [{ nombre: "  Ana ", club: " Club ", dan: 2 }]
  });
  const { competidores } = leerListaCompetidores(texto);
  assert.deepEqual(competidores, [{ id: 1, nombre: "Ana", club: "Club", dan: "2", cabezaDeSerie: false }]);
});

test("si hay más cabezas de serie que el límite, conserva las primeras y avisa", () => {
  const texto = archivo({ competidores: [1, 2, 3].map((n) => ({ nombre: `N${n}`, club: "X", cabezaDeSerie: true })) });
  const { competidores, avisos } = leerListaCompetidores(texto, { limiteCabezasDeSerie: 2 });
  assert.deepEqual(competidores.map((c) => c.cabezaDeSerie), [true, true, false]);
  assert.equal(avisos.length, 1);
});

// ---------------------------------------------------------------------------
// Equipos
// ---------------------------------------------------------------------------
test("huecos permitidos y puestos por tamaño de equipo", () => {
  assert.equal(huecosPermitidosEquipo(3), 1);
  assert.equal(huecosPermitidosEquipo(5), 2);
  assert.equal(puestosEquipo(3).length, 3);
  assert.equal(puestosEquipo(5).length, 5);
});

test("normalizarIntegrantes: opcional, y respeta los huecos permitidos", () => {
  assert.deepEqual(normalizarIntegrantes(["", "", ""], 3), []);        // sin nombres: vale
  assert.deepEqual(normalizarIntegrantes(undefined, 5), []);
  assert.deepEqual(normalizarIntegrantes(["A", "B", "C"], 3), ["A", "B", "C"]);
  assert.deepEqual(normalizarIntegrantes(["A", "", "C"], 3), ["A", "", "C"]); // 1 hueco en equipo de 3
  assert.throws(() => normalizarIntegrantes(["A", "", ""], 3), /máximo 1 hueco /);
  assert.deepEqual(normalizarIntegrantes([" A ", "B", "", "D", ""], 5), ["A", "B", "", "D", ""]); // 2 huecos en equipo de 5
  assert.throws(() => normalizarIntegrantes(["A", "B", "", "", ""], 5), /máximo 2 huecos/);
  assert.deepEqual(normalizarIntegrantes(["A", "B"], 0), []);          // sin tamaño indicado
});

const equipos = [
  { id: 4, nombre: "Madrid A", club: "Madrid Kendo", dan: "", cabezaDeSerie: true, integrantes: ["A", "B", "C"] },
  { id: 5, nombre: "Sevilla", club: "", dan: "", cabezaDeSerie: false, integrantes: [] },
  { id: 6, nombre: "Madrid B", club: "Madrid Kendo", dan: "", cabezaDeSerie: false, integrantes: ["D", "", "F"] }
];

test("equipos: ida y vuelta conserva tipo, tamaño, integrantes (con huecos) y club opcional", () => {
  const texto = serializarListaCompetidores(equipos, { tipo: "equipos", integrantesPorEquipo: 3 });
  const datos = JSON.parse(texto);
  assert.equal(datos.tipo, "equipos");
  assert.equal(datos.integrantesPorEquipo, 3);
  assert.ok(datos.competidores.every((c) => !("id" in c) && !("dan" in c)));

  const r = leerListaCompetidores(texto);
  assert.equal(r.tipo, "equipos");
  assert.equal(r.integrantesPorEquipo, 3);
  assert.deepEqual(r.competidores, [
    { id: 1, nombre: "Madrid A", club: "Madrid Kendo", dan: "", cabezaDeSerie: true, integrantes: ["A", "B", "C"] },
    { id: 2, nombre: "Sevilla", club: "", dan: "", cabezaDeSerie: false, integrantes: [] },
    { id: 3, nombre: "Madrid B", club: "Madrid Kendo", dan: "", cabezaDeSerie: false, integrantes: ["D", "", "F"] }
  ]);
});

test("equipos: el club es opcional pero el nombre no; valida integrantes y tamaño", () => {
  const base = { formato: "kendostream-lista-competidores", version: 1, tipo: "equipos", integrantesPorEquipo: 3 };
  assert.throws(() => leerListaCompetidores(JSON.stringify({ ...base, competidores: [{ nombre: "" }] })), /equipo nº 1 no tiene nombre/);
  assert.throws(() => leerListaCompetidores(JSON.stringify({ ...base, integrantesPorEquipo: 4, competidores: [{ nombre: "X" }] })), /3, 5/);
  assert.throws(() => leerListaCompetidores(JSON.stringify({ ...base, competidores: [{ nombre: "X", integrantes: ["A", "", ""] }] })), /equipo nº 1 \(X\).*máximo 1 hueco/);
  const sinNombres = leerListaCompetidores(JSON.stringify({ ...base, integrantesPorEquipo: 0, competidores: [{ nombre: "X", integrantes: ["A", "B", "C"] }] }));
  assert.deepEqual(sinNombres.competidores[0].integrantes, []);
});
