# Changelog — KendoSTREAM

## v2.0

Primera versión que va más allá del marcador en directo: KendoSTREAM
incorpora un **Organizador de torneos**, hasta ahora fuera del alcance
del proyecto según el propio documento de definición inicial.

### Organizador de torneos (nuevo)
- Nueva sección `/organizador`, enlazada desde el panel junto a Configuración.
- **Eliminatoria directa**: siembra estándar en serpentina, byes
  priorizados a cabezas de serie (máximo 2), mejor esfuerzo automático
  para evitar coincidencias de club en la 1ª ronda.
- **Fase de grupos + Eliminatoria**: tamaño de grupo calculado
  automáticamente (2-4 competidores, lo más parecido a 4 posible); nº de
  clasificados por grupo configurable por el organizador; reparto en
  grupos evitando coincidencias de club y separando cabezas de serie.
- Cruce entre grupos por siembra en serpentina (1º del primer grupo
  contra 2º del último, etc.), verificado matemáticamente para
  garantizar que dos clasificados del mismo grupo original solo puedan
  volver a encontrarse en la Final — funciona para cualquier número de
  grupos, no solo potencias de 2.
- Clasificación en vivo por grupo (victorias, luego ippones), con
  detección automática de empates en el corte de clasificación y
  resolución mediante combate de desempate.
- Botón único **"Generar Torneo"**: según el formato elegido, genera y
  descarga automáticamente el PDF correspondiente — el cuadro completo
  en eliminatoria directa, o los grupos (solo competidores) + el cruce
  con huecos tipo "1º Grupo A" / "2º Grupo D" en formato grupos.
- PDF a **doble ala** automático para cuadros de más de 32 plazas (dos
  mitades del cuadro convergiendo hacia el centro), pensado para que
  se pueda imprimir y leer bien en cuadros grandes.
- Los byes ya no se muestran como combate: el competidor con bye
  aparece directo en la ronda donde juega de verdad.
- Guardado automático en el propio servidor (`data/torneo.json`).

### Pendiente
- Formato suizo: queda para una fase futura aparte, dada su complejidad.
- La pantalla de gestión de resultados de grupo (calendario editable,
  ippones, desempates) está construida y funcional, pero se mantiene
  oculta por ahora hasta integrarla de forma más sólida con el panel
  en directo — sin perder el trabajo ya hecho.

## v1.3.1
- Retirado instalar.bat (el instalador de doble clic para Windows) — quedaba desaconsejado en la práctica por los bloqueos de Smart App Control, y mantenerlo generaba 
  confusión sin aportar una vía fiable. El método de comandos de terminal (apartado 3.1 del manual) es ahora la única vía documentada para Windows.
- Manual actualizado: eliminada la sección del instalador de doble clic, simplificados los apartados de solución de problemas relacionados.

## v1.3
- Nuevos diseños de overlay, "Neón" y "Samurai".
- Medidas del overlay actualizadas en Clásico y KendoSTREAM (fotos, logos, tipografía y elementos en general, más grandes).

## v1.2

### Diseño "Campeonato Importante"
- Nuevo modo, activable desde `/config`, compatible con los dos diseños de overlay existentes (Clásico y KendoSTREAM).
- Categoría (Masculino/Femenino/Junior/Otro) y Modalidad (Individual/Equipos/Otro), editables desde el panel, mostradas en el overlay.
- El nombre del torneo pasa a una cajita propia en la parte superior de la pantalla cuando este modo está activo.
- Fotos de competidores y logos de club/selección: el organizador los coloca en `public/fotos-competidores/` y `public/logos-clubes/`, y se eligen desde desplegables en el panel. El logo se superpone sobre la foto y también aparece junto al nombre en la tabla de equipos.

### Reglas del combate
- Límite de 2 puntos por combate: al llegar un competidor a 2 puntos (ippon), se bloquean los botones de punto y hansoku de ambos lados hasta deshacer o reiniciar.
- Marca de hansoku reducida a una sola (al segundo hansoku se convierte automáticamente en ippon).

### Configuración y diseños
- El desplegable de diseños de `/config` detecta automáticamente los archivos disponibles en `public/overlay/temas/` — un diseño nuevo (propio o personalizado para un club) solo requiere añadir el archivo, sin tocar código.
- Página de configuración reorganizada en filas de 3 columnas.

### Otros
- Texto del indicador "ENCHO" ampliado a "ENCHO (PRÓRROGA)".
- Separador central del diseño KendoSTREAM simplificado a una línea recta (se quitó un recorte angular que generaba un artefacto visual).
- Corregido: los campos del modo Campeonato Importante en el panel (categoría, modalidad, foto, logo) ahora se ocultan correctamente cuando el modo está desactivado (antes se mostraban siempre, por un conflicto de CSS).
- Nombre del torneo / categoría-modalidad del diseño KendoSTREAM: cambiado de texto con contorno a un cuadro de fondo sólido, para que se lea bien sobre cualquier vídeo de fondo.
- **Paquete de idiomas del panel** (español/inglés), seleccionable desde `/config`. Solo traduce la interfaz del panel — el overlay no se traduce, ya que su contenido lo escribe el propio operador.
- Manual ampliado: uso del diseño Campeonato Importante, idioma del panel, y nueva sección explicando cómo añadir el marcador a vídeos ya grabados (no solo en directo).

---

## v1.1

### Identidad de marca
- Integrado el logo real de KendoSTREAM (favicon en panel/overlay/configuración, cabecera del panel, marca de agua en el overlay).
- Icono `.ico` propio para el acceso directo de Windows.
- Panel de control rediseñado con la paleta e identidad de marca (negro `#0D1117`, rojo `#E02424`, gris `#6B7280`, blanco `#F2F2F2`; tipografías Orbitron/Montserrat).

### Nuevo diseño de marcador
- Segundo diseño de overlay ("KendoSTREAM"): fondo oscuro, cortes angulados, tipografía de marca — inspirado en el manual de identidad, manteniendo el sistema de iconos M/K/D/T.
- El diseño original se renombra "Clásico" y se mantiene como predeterminado, sin cambios.
- Nueva página de configuración del organizador (`/config`) con un desplegable para elegir el diseño activo, pensada para poder añadir más diseños en el futuro sin tocar nada más.

### Funcionalidad del marcador
- Marca de agua del logo, activable/desactivable desde el panel.
- Indicador visual de **Encho / Prórroga**, activable desde el panel, con insignia destacada en el overlay (ambos diseños).
- Campo **Empates** añadido a cada equipo (junto a Victorias e Ippones).
- Bloque de equipos rediseñado como **tabla** (nombres en filas, Victorias/Empates/Ippones en columnas) en ambos diseños de overlay.

### Correcciones
- El bloque de equipos ahora se oculta correctamente al desactivar el modo equipos (antes quedaba visible por un conflicto de CSS).
- El nombre del torneo, que se guardaba pero no se mostraba, ahora aparece en el overlay.
- "Reiniciar combate completo" ahora borra también los datos de equipos (antes se mantenían).
- Contraste de las marcas de hansoku corregido en el lado Aka del diseño KendoSTREAM (se perdían por ser rojo sobre rojo).
- Nombre del torneo con contorno y mayor tamaño en el diseño KendoSTREAM, para que se lea sobre cualquier fondo de vídeo.
- Marca de agua ligeramente más grande, para que el logo se distinga mejor.

### Instalación y distribución
- **Cambio importante**: la instalación en Windows pasa a hacerse mediante comandos de terminal (`npm install` / `npm start`) como método principal, en vez de un instalador de doble clic — los sistemas de seguridad modernos de Windows (Smart App Control) bloquean cualquier script sin firma digital de pago, sin excepción.
- Se mantiene un acceso directo opcional (sin script propio, apunta directamente a `cmd.exe`) para no repetir los comandos cada vez, y el instalador de doble clic sigue disponible como atajo rápido para equipos sin restricciones estrictas.
- Arranque automático al encender el ordenador eliminado por completo (evita conflictos con antivirus): el servidor solo se inicia cuando el usuario lo pide.
- Desinstaladores añadidos para Windows y Mac.
- `LICENSE.txt` (PolyForm Noncommercial License 1.0.0) y avisos de copyright añadidos en todo el código fuente.
- Manual de instalación ampliado significativamente: configuración de OBS paso a paso, solución de problemas (antivirus, Smart App Control, fallos de `npm install`), página de configuración, acceso desde móvil/tablet, uso en pabellón.

---

## v1.0

Versión inicial: panel de control y overlay para retransmisiones de kendo.

- Registro de puntos (Men, Kote, Do, Tsuki) y gestión de Hansoku, con ippon automático al segundo hansoku.
- Distinción entre ippon por técnica e ippon por hansoku.
- Modo equipos (activable), edición en tiempo real de nombres/clubes/información general.
- Deshacer, reiniciar combate, intercambiar competidores.
- Sincronización en tiempo real por WebSocket entre panel y overlay, con guardado automático en JSON.
- Atajos de teclado, diseño responsive del panel.
- Overlay compatible con OBS (Browser Source, fondo transparente).
- Instaladores iniciales para Windows y Mac, manual de instalación básico.
