// panel.js — lógica del panel de control del operador
// KendoSTREAM — © 2026 Jorge Pascual Lansac. Distribuido bajo PolyForm
// Noncommercial License 1.0.0 — ver LICENSE.txt en la raíz del proyecto.

const ICONOS = { men: "M", kote: "K", do: "D", tsuki: "T", ippon: "IP" };

let ws;
let estadoActual = null;
let escribiendoEnCampo = false; // evita que el render pise lo que el operador está tecleando
let idiomaActual = "es";

function conectar() {
  ws = new WebSocket(`ws://${location.host}`);

  ws.onopen = () => marcarConexion(true);
  ws.onclose = () => {
    marcarConexion(false);
    setTimeout(conectar, 1500); // reintento automático si se pierde la conexión
  };
  ws.onerror = () => marcarConexion(false);

  ws.onmessage = (evento) => {
    const mensaje = JSON.parse(evento.data);
    if (mensaje.tipo === "ESTADO") {
      estadoActual = mensaje.estado;
      if (!escribiendoEnCampo) render();
    }
  };
}

function marcarConexion(ok) {
  const t = TRADUCCIONES[idiomaActual] || TRADUCCIONES.es;
  const el = document.getElementById("estadoConexion");
  el.textContent = ok ? t.conectado : t.sin_conexion;
  el.className = "estado-conexion " + (ok ? "ok" : "error");
}

function enviarAccion(accion) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ tipo: "ACCION", accion }));
  }
}

function render() {
  if (!estadoActual) return;
  const e = estadoActual;

  idiomaActual = e.configuracion.idioma || "es";
  aplicarIdioma(idiomaActual);

  setValor("nombreTorneo", e.evento.nombreTorneo);
  setValor("infoGeneral", e.infoGeneral);
  document.getElementById("modoEquipos").checked = e.modoEquipos;
  document.getElementById("bloqueEquipos").hidden = !e.modoEquipos;
  document.getElementById("marcaAgua").checked = e.configuracion.marcaAguaVisible;
  document.getElementById("encho").checked = e.encho;

  const modoCampeonato = e.configuracion.modoCampeonatoImportante;
  document.getElementById("bloqueCampeonato").style.display = modoCampeonato ? "flex" : "none";
  document.querySelectorAll(".campo-campeonato").forEach((el) => (el.style.display = modoCampeonato ? "flex" : "none"));

  setValor("categoriaOpcion", e.categoria.opcion);
  document.getElementById("categoriaTexto").hidden = e.categoria.opcion !== "otro";
  setValor("categoriaTexto", e.categoria.textoPersonalizado);
  setValor("modalidadOpcion", e.modalidad.opcion);
  document.getElementById("modalidadTexto").hidden = e.modalidad.opcion !== "otro";
  setValor("modalidadTexto", e.modalidad.textoPersonalizado);

  // Combate decidido (un competidor ya tiene 2 puntos): se desactivan los
  // botones de punto y hansoku de los dos lados hasta deshacer o reiniciar.
  const decidido = e.competidores.shiro.puntos.length >= 2 || e.competidores.aka.puntos.length >= 2;
  document.querySelectorAll(".botones-tecnica button, .boton-hansoku").forEach((boton) => {
    boton.disabled = decidido;
  });

  ["shiro", "aka"].forEach((lado) => {
    const comp = e.competidores[lado];
    const raiz = document.querySelector(`.competidor-${lado}`);
    setValor(raiz.querySelector(".competidor-nombre"), comp.nombre);
    setValor(raiz.querySelector(".competidor-club"), comp.club);
    setValor(raiz.querySelector(".competidor-foto"), comp.foto);
    setValor(raiz.querySelector(".competidor-logo"), comp.logoClub);
    raiz.querySelector(".contador-hansoku").textContent = comp.hansoku;

    const contenedor = raiz.querySelector(".puntos-registrados");
    contenedor.innerHTML = "";
    comp.puntos.forEach((p) => {
      const span = document.createElement("span");
      span.className = "punto-icono" + (p.origen === "hansoku" ? " hansoku" : "");
      span.textContent = ICONOS[p.tipo] || "?";
      span.title = p.origen === "hansoku" ? "Ippon por hansoku" : p.tipo;
      contenedor.appendChild(span);
    });

    const editorEquipo = document.querySelector(`.equipo-editor[data-lado="${lado}"]`);
    setValor(editorEquipo.querySelector(".equipo-nombre"), e.equipos[lado].nombre);
    setValor(editorEquipo.querySelector(".equipo-victorias"), e.equipos[lado].victorias);
    setValor(editorEquipo.querySelector(".equipo-empates"), e.equipos[lado].empates);
    setValor(editorEquipo.querySelector(".equipo-ippones"), e.equipos[lado].ippones);
  });
}

function setValor(idOrEl, valor) {
  const el = typeof idOrEl === "string" ? document.getElementById(idOrEl) : idOrEl;
  if (document.activeElement !== el) el.value = valor ?? "";
}

// --- Listas de fotos y logos disponibles (las coloca el organizador en las
// carpetas public/fotos-competidores/ y public/logos-clubes/) ---
async function cargarListasDeArchivos() {
  try {
    const [fotos, logos] = await Promise.all([
      fetch("/api/fotos-competidores").then((r) => r.json()),
      fetch("/api/logos-clubes").then((r) => r.json())
    ]);
    document.querySelectorAll(".competidor-foto").forEach((select) => rellenarOpciones(select, fotos));
    document.querySelectorAll(".competidor-logo").forEach((select) => rellenarOpciones(select, logos));
    if (estadoActual) render(); // vuelve a marcar el valor seleccionado ahora que ya hay opciones
  } catch (err) {
    console.error("No se pudieron cargar las listas de fotos/logos:", err.message);
  }
}

function rellenarOpciones(select, archivos) {
  const valorActual = select.value;
  const primeraOpcion = select.querySelector("option[value='']");
  select.innerHTML = "";
  if (primeraOpcion) select.appendChild(primeraOpcion);
  archivos.forEach((archivo) => {
    const opcion = document.createElement("option");
    opcion.value = archivo;
    opcion.textContent = archivo;
    select.appendChild(opcion);
  });
  select.value = valorActual;
}

// --- Listeners de botones de puntos y hansoku ---
document.querySelectorAll(".botones-tecnica button").forEach((boton) => {
  boton.addEventListener("click", () => {
    const lado = boton.closest(".competidor").dataset.lado;
    enviarAccion({ tipo: "PUNTO", lado, tecnica: boton.dataset.tecnica });
  });
});

document.querySelectorAll(".boton-hansoku").forEach((boton) => {
  boton.addEventListener("click", () => {
    enviarAccion({ tipo: "HANSOKU", lado: boton.dataset.lado });
  });
});

// --- Controles generales ---
document.getElementById("botonDeshacer").addEventListener("click", () => {
  enviarAccion({ tipo: "DESHACER" });
});

document.getElementById("botonIntercambiar").addEventListener("click", () => {
  if (confirm((TRADUCCIONES[idiomaActual] || TRADUCCIONES.es).confirmar_intercambiar)) {
    enviarAccion({ tipo: "INTERCAMBIAR_COMPETIDORES" });
  }
});

document.getElementById("botonReiniciarMismos").addEventListener("click", () => {
  if (confirm((TRADUCCIONES[idiomaActual] || TRADUCCIONES.es).confirmar_reiniciar_mismos)) {
    enviarAccion({ tipo: "REINICIAR_COMBATE", mantenerCompetidores: true });
  }
});

document.getElementById("botonReiniciarTodo").addEventListener("click", () => {
  if (confirm((TRADUCCIONES[idiomaActual] || TRADUCCIONES.es).confirmar_reiniciar_todo)) {
    enviarAccion({ tipo: "REINICIAR_COMBATE", mantenerCompetidores: false });
  }
});

// --- Campos de texto / edición en tiempo real ---
function conectarCampoTexto(id, construirAccion) {
  const el = document.getElementById(id);
  el.addEventListener("focus", () => (escribiendoEnCampo = true));
  el.addEventListener("blur", () => (escribiendoEnCampo = false));
  el.addEventListener("input", () => enviarAccion(construirAccion(el.value)));
}

conectarCampoTexto("nombreTorneo", (valor) => ({ tipo: "EDITAR_NOMBRE_TORNEO", valor }));
conectarCampoTexto("infoGeneral", (valor) => ({ tipo: "EDITAR_INFO_GENERAL", valor }));

document.getElementById("modoEquipos").addEventListener("change", () => {
  enviarAccion({ tipo: "TOGGLE_MODO_EQUIPOS" });
});

document.getElementById("marcaAgua").addEventListener("change", () => {
  enviarAccion({ tipo: "TOGGLE_MARCA_AGUA" });
});

document.getElementById("encho").addEventListener("change", () => {
  enviarAccion({ tipo: "TOGGLE_ENCHO" });
});

function enviarCategoria() {
  enviarAccion({
    tipo: "CAMBIAR_CATEGORIA",
    opcion: document.getElementById("categoriaOpcion").value,
    textoPersonalizado: document.getElementById("categoriaTexto").value
  });
}
function enviarModalidad() {
  enviarAccion({
    tipo: "CAMBIAR_MODALIDAD",
    opcion: document.getElementById("modalidadOpcion").value,
    textoPersonalizado: document.getElementById("modalidadTexto").value
  });
}
document.getElementById("categoriaOpcion").addEventListener("change", enviarCategoria);
document.getElementById("categoriaTexto").addEventListener("focus", () => (escribiendoEnCampo = true));
document.getElementById("categoriaTexto").addEventListener("blur", () => (escribiendoEnCampo = false));
document.getElementById("categoriaTexto").addEventListener("input", enviarCategoria);
document.getElementById("modalidadOpcion").addEventListener("change", enviarModalidad);
document.getElementById("modalidadTexto").addEventListener("focus", () => (escribiendoEnCampo = true));
document.getElementById("modalidadTexto").addEventListener("blur", () => (escribiendoEnCampo = false));
document.getElementById("modalidadTexto").addEventListener("input", enviarModalidad);

["shiro", "aka"].forEach((lado) => {
  const raiz = document.querySelector(`.competidor-${lado}`);
  const nombreEl = raiz.querySelector(".competidor-nombre");
  const clubEl = raiz.querySelector(".competidor-club");

  [nombreEl, clubEl].forEach((el) => {
    el.addEventListener("focus", () => (escribiendoEnCampo = true));
    el.addEventListener("blur", () => (escribiendoEnCampo = false));
  });

  nombreEl.addEventListener("input", () =>
    enviarAccion({ tipo: "EDITAR_COMPETIDOR", lado, campo: "nombre", valor: nombreEl.value })
  );
  clubEl.addEventListener("input", () =>
    enviarAccion({ tipo: "EDITAR_COMPETIDOR", lado, campo: "club", valor: clubEl.value })
  );

  const fotoEl = raiz.querySelector(".competidor-foto");
  fotoEl.addEventListener("change", () =>
    enviarAccion({ tipo: "CAMBIAR_FOTO_COMPETIDOR", lado, archivo: fotoEl.value })
  );
  const logoEl = raiz.querySelector(".competidor-logo");
  logoEl.addEventListener("change", () =>
    enviarAccion({ tipo: "CAMBIAR_LOGO_CLUB", lado, archivo: logoEl.value })
  );

  const editorEquipo = document.querySelector(`.equipo-editor[data-lado="${lado}"]`);
  const campoEquipo = {
    ".equipo-nombre": "nombre",
    ".equipo-victorias": "victorias",
    ".equipo-empates": "empates",
    ".equipo-ippones": "ippones"
  };
  Object.entries(campoEquipo).forEach(([selector, campo]) => {
    const el = editorEquipo.querySelector(selector);
    el.addEventListener("focus", () => (escribiendoEnCampo = true));
    el.addEventListener("blur", () => (escribiendoEnCampo = false));
    el.addEventListener("input", () =>
      enviarAccion({ tipo: "EDITAR_EQUIPO", lado, campo, valor: el.value })
    );
  });
});

// --- Atajos de teclado ---
const TECLA_A_ACCION = {
  q: { tipo: "PUNTO", lado: "shiro", tecnica: "men" },
  w: { tipo: "PUNTO", lado: "shiro", tecnica: "kote" },
  e: { tipo: "PUNTO", lado: "shiro", tecnica: "do" },
  r: { tipo: "PUNTO", lado: "shiro", tecnica: "tsuki" },
  a: { tipo: "HANSOKU", lado: "shiro" },
  u: { tipo: "PUNTO", lado: "aka", tecnica: "men" },
  i: { tipo: "PUNTO", lado: "aka", tecnica: "kote" },
  o: { tipo: "PUNTO", lado: "aka", tecnica: "do" },
  p: { tipo: "PUNTO", lado: "aka", tecnica: "tsuki" },
  l: { tipo: "HANSOKU", lado: "aka" },
  z: { tipo: "DESHACER" }
};

document.addEventListener("keydown", (evento) => {
  // no interceptar teclas mientras se escribe en un campo de texto
  const escribiendo = ["INPUT", "TEXTAREA"].includes(document.activeElement.tagName);
  if (escribiendo) return;

  const accion = TECLA_A_ACCION[evento.key.toLowerCase()];
  if (accion) {
    evento.preventDefault();
    enviarAccion(accion);
  }
});

conectar();
cargarListasDeArchivos();
