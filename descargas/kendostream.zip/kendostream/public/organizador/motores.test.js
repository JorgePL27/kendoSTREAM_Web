// motores.test.js — pruebas de lógica del organizador (node --test)
const test = require("node:test");
const assert = require("node:assert/strict");

const {
  generarEliminatoria,
  generarOrdenSiembra,
  siguientePotenciaDeDos
} = require("./motor-eliminatoria");
const {
  calcularEstructuraGrupos,
  formarGrupos,
  planificarCruceDeGrupos,
  generarCruceDeGrupos
} = require("./motor-grupos");

// Generador pseudoaleatorio con semilla, para que las pruebas sean repetibles.
function crearAleatorio(semilla) {
  let a = semilla >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function crearCompetidores(clubs) {
  return clubs.map((club, i) => ({ id: i + 1, nombre: `C${i + 1}`, club, dan: "", cabezaDeSerie: false }));
}

// ---------------------------------------------------------------------------
test("generarOrdenSiembra: orden clásico", () => {
  assert.deepEqual(generarOrdenSiembra(8), [1, 8, 4, 5, 2, 7, 3, 6]);
});

// ---------------------------------------------------------------------------
// (b) Estructura de grupos
// ---------------------------------------------------------------------------
test("calcularEstructuraGrupos: casos concretos", () => {
  const casos = {
    4: [2, 2],
    5: [3, 2],
    6: [3, 3],
    7: [4, 3],
    8: [4, 4],
    9: [3, 3, 3],
    10: [4, 3, 3],
    11: [3, 3, 3, 2],
    12: [3, 3, 3, 3],   // 4 grupos de 3, no 3 de 4
    13: [4, 3, 3, 3],
    14: [4, 4, 3, 3],
    15: [4, 4, 4, 3],
    16: [4, 4, 4, 4],
    24: [3, 3, 3, 3, 3, 3, 3, 3]
  };
  for (const [n, esperado] of Object.entries(casos)) {
    assert.deepEqual(calcularEstructuraGrupos(Number(n), 2).tamanos, esperado, `n = ${n}`);
  }
});

test("calcularEstructuraGrupos: invariantes para 4..64 competidores", () => {
  for (let n = 4; n <= 64; n++) {
    const e = calcularEstructuraGrupos(n, 2);
    assert.equal(e.tamanos.reduce((a, b) => a + b, 0), n, `suma, n = ${n}`);
    assert.equal(e.tamanos.length, e.numGrupos);
    assert.ok(e.numGrupos >= 2, `al menos 2 grupos, n = ${n}`);
    e.tamanos.forEach((t) => assert.ok(t >= 2 && t <= 4, `tamaño ${t}, n = ${n}`));
    const gruposDeDos = e.tamanos.filter((t) => t === 2).length;
    assert.ok(gruposDeDos <= (n === 4 ? 2 : 1), `como máximo un grupo de 2, n = ${n}`);
  }
});

test("calcularEstructuraGrupos: cuadro sin huecos siempre que exista una estructura válida", () => {
  [5, 6, 7, 8, 11, 12, 13, 14, 15, 16, 24].forEach((n) => {
    assert.equal(calcularEstructuraGrupos(n, 2).huecosCuadro, 0, `n = ${n}`);
  });
});

// ---------------------------------------------------------------------------
// (c) Byes del cruce de grupos: solo para 1.º de grupo
// ---------------------------------------------------------------------------
test("planificarCruceDeGrupos: cada plaza aparece una vez y los byes son solo de 1.º cuando se puede", () => {
  for (let G = 2; G <= 16; G++) {
    const plan = planificarCruceDeGrupos(G, 2);
    const plazas = plan.partidos.flatMap((p) => [p.a, p.b]).filter(Boolean);
    assert.equal(plazas.length, 2 * G, `G = ${G}`);
    assert.equal(new Set(plazas.map((p) => `${p.puesto}-${p.grupo}`)).size, 2 * G, `sin repetidos, G = ${G}`);
    assert.equal(plan.partidos.length, siguientePotenciaDeDos(G), `combates de 1.ª ronda, G = ${G}`);

    const byesEsperados = 2 * (siguientePotenciaDeDos(G) - G);
    assert.equal(plan.numByes, byesEsperados, `nº de byes, G = ${G}`);
    if (byesEsperados <= G) {
      assert.equal(plan.byesASegundos, 0, `ningún 2.º con bye, G = ${G}`);
    } else {
      assert.equal(plan.byesASegundos, byesEsperados - G, `byes a 2.º inevitables, G = ${G}`);
    }
  }
});

test("planificarCruceDeGrupos: 1.º y 2.º del mismo grupo en alas opuestas y nunca se cruzan en 1.ª ronda", () => {
  for (let G = 2; G <= 16; G++) {
    const plan = planificarCruceDeGrupos(G, 2);
    const mitadCombates = plan.partidos.length / 2;
    const ala = {};
    plan.partidos.forEach((p, i) => {
      [p.a, p.b].filter(Boolean).forEach((plaza) => {
        ala[`${plaza.puesto}-${plaza.grupo}`] = i < mitadCombates ? 0 : 1;
      });
      if (p.a && p.b) assert.notEqual(p.a.grupo, p.b.grupo, `mismo grupo en 1.ª ronda, G = ${G}`);
    });
    for (let g = 0; g < G; g++) {
      assert.notEqual(ala[`1-${g}`], ala[`2-${g}`], `grupo ${g}, G = ${G}`);
    }
  }
});

test("planificarCruceDeGrupos: con potencia de 2 se mantiene el cruce clásico (1.º A - 2.º último)", () => {
  const plan = planificarCruceDeGrupos(4, 2);
  const texto = plan.partidos.map((p) => `${p.a.puesto}${"ABCD"[p.a.grupo]}-${p.b.puesto}${"ABCD"[p.b.grupo]}`);
  assert.deepEqual(texto, ["1A-2D", "1B-2C", "1C-2B", "1D-2A"]);
});

test("generarCruceDeGrupos: con 3 grupos no pasa un 1.º y un 2.º directos (el fallo detectado)", () => {
  const grupos = ["A", "B", "C"].map((letra, g) => ({
    nombre: `Grupo ${letra}`,
    clasificacion: [
      { competidor: { id: 10 + g, nombre: `1${letra}`, club: `x${g}` } },
      { competidor: { id: 20 + g, nombre: `2${letra}`, club: `y${g}` } }
    ]
  }));
  const cuadro = generarCruceDeGrupos(grupos, 2);
  assert.equal(cuadro.tamanoCuadro, 8);
  assert.equal(cuadro.numByes, 2);
  assert.equal(cuadro.byesASegundos, 0);

  const ronda1 = cuadro.rondas[0].combates;
  const conBye = ronda1.filter((c) => (c.compA === null) !== (c.compB === null));
  assert.equal(conBye.length, 2);
  conBye.forEach((c) => {
    const ganador = c.compA || c.compB;
    assert.ok(ganador.id >= 10 && ganador.id < 20, "el bye es de un 1.º");
    assert.equal(c.ganadorId, ganador.id);
  });
  // Los que pasan por bye ya aparecen en cuartos/semis.
  const idsRonda2 = cuadro.rondas[1].combates.flatMap((c) => [c.compA, c.compB]).filter(Boolean).map((c) => c.id);
  conBye.forEach((c) => assert.ok(idsRonda2.includes((c.compA || c.compB).id)));
});

test("generarCruceDeGrupos: 12 competidores → 4 grupos de 3 → cuadro de 8 sin byes", () => {
  const estructura = calcularEstructuraGrupos(12, 2);
  const competidores = crearCompetidores(Array(12).fill("").map((_, i) => `club${i}`));
  const { grupos } = formarGrupos(competidores, estructura, { aleatorio: crearAleatorio(1) });
  const gruposClasif = grupos.map((g, i) => ({
    nombre: `G${i}`,
    clasificacion: g.map((competidor) => ({ competidor }))
  }));
  const cuadro = generarCruceDeGrupos(gruposClasif, 2);
  assert.equal(cuadro.tamanoCuadro, 8);
  assert.equal(cuadro.numByes, 0);
});

// ---------------------------------------------------------------------------
// (a) Evitar cruces del mismo club
// ---------------------------------------------------------------------------
function choquesPrimeraRonda(cuadro) {
  return cuadro.rondas[0].combates.filter((c) =>
    c.compA && c.compB && c.compA.club === c.compB.club
  ).length;
}

test("generarEliminatoria: con la opción activada evita cruces de club; desactivada, no lo intenta", () => {
  const competidores = crearCompetidores(["A", "A", "B", "B", "C", "C", "D", "D"]);
  let desactivadoConChoque = false;
  for (let semilla = 1; semilla <= 40; semilla++) {
    const con = generarEliminatoria(competidores, { evitarMismoClub: true, aleatorio: crearAleatorio(semilla) });
    assert.equal(choquesPrimeraRonda(con), 0, `semilla ${semilla}`);
    assert.equal(con.evitarMismoClub, true);

    const sin = generarEliminatoria(competidores, { evitarMismoClub: false, aleatorio: crearAleatorio(semilla) });
    assert.equal(sin.evitarMismoClub, false);
    if (choquesPrimeraRonda(sin) > 0) desactivadoConChoque = true;
  }
  assert.ok(desactivadoConChoque, "con la opción desactivada debería haber choques en alguna semilla");
});

test("generarEliminatoria: por defecto la opción está activada", () => {
  const competidores = crearCompetidores(["A", "A", "B", "B"]);
  const cuadro = generarEliminatoria(competidores, { aleatorio: crearAleatorio(3) });
  assert.equal(cuadro.evitarMismoClub, true);
  assert.equal(choquesPrimeraRonda(cuadro), 0);
});

test("formarGrupos: con la opción activada reparte sin coincidencias de club si es posible", () => {
  // 12 competidores de 4 clubs (3 de cada uno) en 4 grupos de 3: cabe un reparto sin choques.
  const competidores = crearCompetidores(["A", "A", "A", "B", "B", "B", "C", "C", "C", "D", "D", "D"]);
  const estructura = calcularEstructuraGrupos(12, 2);
  for (let semilla = 1; semilla <= 20; semilla++) {
    const r = formarGrupos(competidores, estructura, { evitarMismoClub: true, aleatorio: crearAleatorio(semilla) });
    assert.equal(r.choquesDeClub, 0, `semilla ${semilla}`);
    assert.deepEqual(r.grupos.map((g) => g.length), estructura.tamanos);
  }
});

test("formarGrupos: con la opción desactivada hace un único reparto (puede haber choques)", () => {
  const competidores = crearCompetidores(["A", "A", "A", "B", "B", "B", "C", "C", "C", "D", "D", "D"]);
  const estructura = calcularEstructuraGrupos(12, 2);
  let hayChoques = false;
  for (let semilla = 1; semilla <= 20; semilla++) {
    const r = formarGrupos(competidores, estructura, { evitarMismoClub: false, aleatorio: crearAleatorio(semilla) });
    assert.deepEqual(r.grupos.map((g) => g.length), estructura.tamanos);
    if (r.choquesDeClub > 0) hayChoques = true;
  }
  assert.ok(hayChoques);
});

test("formarGrupos: las cabezas de serie van a grupos distintos", () => {
  const competidores = crearCompetidores(Array(12).fill("").map((_, i) => `club${i}`));
  competidores[0].cabezaDeSerie = true;
  competidores[5].cabezaDeSerie = true;
  const r = formarGrupos(competidores, calcularEstructuraGrupos(12, 2), { aleatorio: crearAleatorio(9) });
  const gruposConCabeza = r.grupos.filter((g) => g.some((c) => c.cabezaDeSerie)).length;
  assert.equal(gruposConCabeza, 2);
});
