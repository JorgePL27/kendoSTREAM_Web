// registro.js
// KendoSTREAM — © 2026 Jorge Pascual Lansac. Distribuido bajo PolyForm
// Noncommercial License 1.0.0 — ver LICENSE.txt en la raíz del proyecto.
//
// Registro de resultados: guarda los combates finalizados en un JSON por
// evento (esquema v1 del documento de definición, §5 y §6).
//
// - Independiente del marcador: si algo falla aquí, el marcador sigue igual.
// - Escritura segura: archivo temporal + renombrado, más una copia espejo en
//   data/respaldo/. Si la carpeta de resultados falla, el combate queda
//   pendiente (en memoria y en la copia espejo) y se reintenta solo.
// - Un archivo solo lo usa una instancia a la vez (archivo .lock con el PID).
// - Todo es síncrono a propósito: cada combate escribe un JSON pequeño y así
//   no hay escrituras cruzadas ni se pierde la última al cerrar con Ctrl+C.

const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");

const ESQUEMA = 1;

class ErrorRegistro extends Error {
  constructor(codigo, mensaje, detalle) {
    super(mensaje);
    this.codigo = codigo;
    this.detalle = detalle || null;
  }
}

// ---------------------------------------------------------------------------
// Utilidades
// ---------------------------------------------------------------------------

function carpetaPorDefecto() {
  return path.join(os.homedir(), "Documents", "KendoSTREAM-resultados");
}

// Una ruta relativa se entiende desde la carpeta personal del usuario.
function resolverCarpeta(texto) {
  let t = recortar(texto);
  if (!t) return carpetaPorDefecto();
  if (t === "~" || t.startsWith("~/") || t.startsWith("~\\")) t = path.join(os.homedir(), t.slice(1));
  if (!path.isAbsolute(t)) t = path.join(os.homedir(), t);
  return path.normalize(t);
}

function recortar(texto) {
  return String(texto === null || texto === undefined ? "" : texto).trim();
}

function quitarAcentos(texto) {
  return String(texto || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function normalizarTexto(texto) {
  return quitarAcentos(texto).toLowerCase().trim().replace(/\s+/g, " ");
}

function slug(texto) {
  const s = quitarAcentos(texto)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60)
    .replace(/-+$/g, "");
  return s || "sin-nombre";
}

// Fecha del ordenador, AAAA-MM-DD
function fechaLocal(fecha = new Date()) {
  const dos = (n) => String(n).padStart(2, "0");
  return `${fecha.getFullYear()}-${dos(fecha.getMonth() + 1)}-${dos(fecha.getDate())}`;
}

function clonar(valor) {
  return JSON.parse(JSON.stringify(valor));
}

// Escribe en un temporal, lo fuerza a disco y lo renombra: el archivo final
// nunca queda a medias.
function escribirAtomico(ruta, texto) {
  const temporal = ruta + ".tmp";
  try {
    const fd = fs.openSync(temporal, "w");
    try {
      fs.writeSync(fd, texto, 0, "utf8");
      fs.fsyncSync(fd);
    } finally {
      fs.closeSync(fd);
    }
    fs.renameSync(temporal, ruta);
  } catch (err) {
    try { fs.unlinkSync(temporal); } catch (e) { /* no había temporal */ }
    throw err;
  }
}

// ---------------------------------------------------------------------------
// Bloqueo: un archivo, una instancia
// ---------------------------------------------------------------------------

function pidVivo(pid) {
  if (!Number.isInteger(pid) || pid <= 0) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch (err) {
    return err.code === "EPERM"; // existe pero no es nuestro
  }
}

// true si otra instancia viva está usando el archivo
function bloqueoAjeno(ruta) {
  let info;
  try {
    info = JSON.parse(fs.readFileSync(ruta + ".lock", "utf8"));
  } catch (err) {
    return false; // sin bloqueo, o ilegible (se considera abandonado)
  }
  if (!info || info.pid === process.pid) return false;
  return pidVivo(info.pid);
}

function adquirirBloqueo(ruta) {
  fs.writeFileSync(ruta + ".lock", JSON.stringify({ pid: process.pid, desde: new Date().toISOString() }));
}

function liberarBloqueo(ruta) {
  try {
    const info = JSON.parse(fs.readFileSync(ruta + ".lock", "utf8"));
    if (info && info.pid !== process.pid) return; // no es nuestro: no se toca
    fs.unlinkSync(ruta + ".lock");
  } catch (err) { /* ya no existía */ }
}

// ---------------------------------------------------------------------------
// Contenido del archivo
// ---------------------------------------------------------------------------

function crearArchivoVacio({ nombre, fecha, version }) {
  return {
    esquema: ESQUEMA,
    programa: { nombre: "KendoSTREAM", version },
    evento: { id: crypto.randomUUID(), nombre: recortar(nombre), fecha },
    competiciones: []
  };
}

function validarDatos(datos) {
  const ilegible = { ok: false, codigo: "ilegible", mensaje: "El archivo no tiene el formato de KendoSTREAM." };
  if (!datos || typeof datos !== "object" || Array.isArray(datos)) return ilegible;
  if (typeof datos.esquema !== "number") return ilegible;
  if (datos.esquema > ESQUEMA) {
    return { ok: false, codigo: "esquema_nuevo", mensaje: "El archivo se creó con una versión más nueva de KendoSTREAM." };
  }
  if (!datos.evento || typeof datos.evento !== "object" || !Array.isArray(datos.competiciones)) return ilegible;
  for (const competicion of datos.competiciones) {
    if (!competicion || !Array.isArray(competicion.combates)) return ilegible;
  }
  return { ok: true };
}

function contarCombates(datos) {
  return datos.competiciones.reduce((total, c) => total + c.combates.length, 0);
}

function leerArchivo(ruta) {
  let datos;
  try {
    datos = JSON.parse(fs.readFileSync(ruta, "utf8"));
  } catch (err) {
    if (err.code === "ENOENT") throw new ErrorRegistro("no_existe", "El archivo ya no existe.");
    throw new ErrorRegistro("ilegible", "No se puede leer el archivo.", err.message);
  }
  const valido = validarDatos(datos);
  if (!valido.ok) throw new ErrorRegistro(valido.codigo, valido.mensaje);
  return datos;
}

function categoriaParaRegistro(campo) {
  return { opcion: campo.opcion, texto: campo.opcion === "otro" ? recortar(campo.textoPersonalizado) : "" };
}

// Dos combates son de la misma competición si comparten categoría y modalidad
// (y, en equipos, el número de integrantes: un encuentro de 3 y uno de 5 no se mezclan)
function claveCompeticion(categoria, modalidad, integrantes) {
  const parte = (c) => `${c.opcion}|${c.opcion === "otro" ? normalizarTexto(c.texto) : ""}`;
  return parte(categoria) + "/" + parte(modalidad) + "/" + (integrantes || 0);
}

// Datos del encuentro por equipos tal y como se guardan en competiciones[].encuentros
function encuentroParaRegistro(estado) {
  const enc = estado.encuentro;
  return {
    id: enc.id,
    shiro: { nombre: recortar(estado.equipos.shiro.nombre) },
    aka: { nombre: recortar(estado.equipos.aka.nombre) },
    integrantes: enc.integrantes,
    eliminatoria: enc.eliminatoria === true,
    resultado: enc.resultado ? { ganador: enc.resultado.ganador, motivo: enc.resultado.motivo } : null
  };
}

// Convierte el estado del motor (con el combate finalizado) al formato del §6
function combateParaRegistro(estado, { numero, fecha }) {
  const c = estado.combate;
  return {
    id: c.id,
    numero,
    fecha,
    pista: c.pista || 1,
    ronda: recortar(estado.infoGeneral),
    shiro: { nombre: recortar(estado.competidores.shiro.nombre), club: recortar(estado.competidores.shiro.club) },
    aka: { nombre: recortar(estado.competidores.aka.nombre), club: recortar(estado.competidores.aka.club) },
    encho: estado.encho === true || c.eventos.some((e) => e.encho === true),
    eventos: clonar(c.eventos),
    marcador: {
      shiro: estado.competidores.shiro.puntos.length,
      aka: estado.competidores.aka.puntos.length
    },
    resultado: clonar(c.resultado),
    encuentro: c.encuentro
      ? { id: c.encuentro.id, posicion: c.encuentro.posicion, desempate: c.encuentro.desempate === true }
      : null
  };
}

// ---------------------------------------------------------------------------
// Registro (una instancia por servidor)
// ---------------------------------------------------------------------------

/**
 * opciones:
 *  - rutaAjustes:     data/ajustes.json (carpeta de resultados y último archivo)
 *  - carpetaRespaldo: data/respaldo (copia espejo)
 *  - version:         versión del programa, se guarda en el archivo
 *  - alCambiar:       se llama cuando cambia el estado del registro (para avisar al panel)
 *  - reintentoMs:     cada cuánto se reintenta una escritura fallida
 */
function crearRegistro(opciones) {
  const { rutaAjustes, carpetaRespaldo, version = "0.0.0", alCambiar = () => {}, reintentoMs = 5000 } = opciones;

  // sesion: { ruta, archivo, datos, pendientes:Set, error }
  let sesion = null;
  let temporizador = null;

  // --- Ajustes ---
  function leerAjustes() {
    try {
      const a = JSON.parse(fs.readFileSync(rutaAjustes, "utf8"));
      return a && typeof a === "object" && !Array.isArray(a) ? a : {};
    } catch (err) {
      return {};
    }
  }

  function guardarAjustes(parcial) {
    const nuevo = Object.assign(leerAjustes(), parcial);
    fs.mkdirSync(path.dirname(rutaAjustes), { recursive: true });
    escribirAtomico(rutaAjustes, JSON.stringify(nuevo, null, 2));
    return nuevo;
  }

  function carpeta() {
    return resolverCarpeta(leerAjustes().carpetaResultados);
  }

  function ajustes() {
    return { carpeta: carpeta(), defecto: carpetaPorDefecto() };
  }

  function guardarCarpeta(texto) {
    const resuelta = resolverCarpeta(texto);
    guardarAjustes({ carpetaResultados: resuelta });
    alCambiar();
    return { carpeta: resuelta };
  }

  function probarCarpeta(texto) {
    const dir = resolverCarpeta(texto);
    let creada = false;
    try {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        creada = true;
      }
      if (!fs.statSync(dir).isDirectory()) {
        return { ok: false, codigo: "no_carpeta", carpeta: dir, mensaje: "Esa ruta existe, pero no es una carpeta." };
      }
      const prueba = path.join(dir, `.kendostream-prueba-${process.pid}.tmp`);
      fs.writeFileSync(prueba, "ok");
      fs.unlinkSync(prueba);
      return { ok: true, creada, carpeta: dir, mensaje: creada ? "Carpeta creada y lista." : "La carpeta existe y se puede escribir." };
    } catch (err) {
      return { ok: false, codigo: "no_escribible", carpeta: dir, mensaje: "No se puede escribir en esa carpeta.", detalle: err.message };
    }
  }

  // --- Estado para el panel ---
  function infoUltimo() {
    const ruta = leerAjustes().ultimoRegistro;
    if (!ruta || !fs.existsSync(ruta)) return null;
    if (sesion && sesion.ruta === ruta) return null; // ya es el activo
    return { archivo: path.basename(ruta), carpeta: path.dirname(ruta) };
  }

  function estado() {
    return {
      activo: sesion !== null,
      archivo: sesion ? sesion.archivo : null,
      combates: sesion ? contarCombates(sesion.datos) : 0,
      pendientes: sesion ? sesion.pendientes.size : 0,
      error: sesion ? sesion.error : null,
      carpeta: carpeta(),
      ultimo: infoUltimo()
    };
  }

  // --- Escritura ---
  function programarReintento() {
    if (temporizador || reintentoMs <= 0) return;
    temporizador = setTimeout(() => {
      temporizador = null;
      if (sesion && sesion.error) {
        intentarEscribir();
        alCambiar();
      }
    }, reintentoMs);
    if (temporizador.unref) temporizador.unref();
  }

  // Reescribe el JSON entero. Devuelve true si el archivo principal quedó al día.
  function intentarEscribir() {
    const texto = JSON.stringify(sesion.datos, null, 2);

    // 1) Copia espejo: es la red de seguridad si la carpeta de resultados falla.
    try {
      fs.mkdirSync(carpetaRespaldo, { recursive: true });
      escribirAtomico(path.join(carpetaRespaldo, sesion.archivo), texto);
    } catch (err) {
      console.error("No se pudo escribir la copia de respaldo:", err.message);
    }

    // 2) Archivo principal. Si la carpeta se ha borrado, no se vuelve a crear:
    //    se avisa para que el operador lo vea.
    try {
      if (!fs.existsSync(path.dirname(sesion.ruta))) {
        throw new ErrorRegistro("carpeta_no_existe", "La carpeta de resultados no existe.");
      }
      escribirAtomico(sesion.ruta, texto);
      sesion.error = null;
      sesion.pendientes.clear();
      return true;
    } catch (err) {
      sesion.error = {
        codigo: err.codigo || "escritura",
        mensaje: err.codigo ? err.message : "No se puede escribir en la carpeta de resultados.",
        detalle: err.codigo ? null : err.message
      };
      programarReintento();
      return false;
    }
  }

  // --- Sesión ---
  function cerrarSesion() {
    if (!sesion) return { pendientes: 0 };
    if (sesion.error) intentarEscribir(); // último intento antes de soltar el archivo
    const pendientes = sesion.pendientes.size;
    liberarBloqueo(sesion.ruta);
    if (temporizador) clearTimeout(temporizador);
    temporizador = null;
    sesion = null;
    return { pendientes };
  }

  function nombreLibre(dir, fecha, nombre) {
    const base = `${fecha}_${slug(nombre)}`;
    let candidato = `${base}.json`;
    for (let i = 2; fs.existsSync(path.join(dir, candidato)) || fs.existsSync(path.join(dir, candidato + ".lock")); i++) {
      candidato = `${base}-${i}.json`;
    }
    return candidato;
  }

  function nuevo({ nombre }) {
    const dir = carpeta();
    try {
      fs.mkdirSync(dir, { recursive: true });
    } catch (err) {
      throw new ErrorRegistro("carpeta_no_existe", "No se puede crear la carpeta de resultados.", err.message);
    }
    const fecha = fechaLocal();
    const archivo = nombreLibre(dir, fecha, nombre);
    const ruta = path.join(dir, archivo);

    cerrarSesion();
    adquirirBloqueo(ruta);
    sesion = {
      ruta,
      archivo,
      datos: crearArchivoVacio({ nombre, fecha, version }),
      pendientes: new Set(),
      error: null
    };
    if (!intentarEscribir()) {
      const error = sesion.error;
      liberarBloqueo(ruta);
      if (temporizador) clearTimeout(temporizador);
      temporizador = null;
      sesion = null;
      throw new ErrorRegistro(error.codigo, error.mensaje, error.detalle);
    }
    guardarAjustes({ ultimoRegistro: ruta });
    alCambiar();
    return estado();
  }

  // Continuar con un archivo de la carpeta ({ archivo }) o con el último usado ({ ultimo: true })
  function continuar({ archivo, ultimo }) {
    let ruta;
    if (ultimo) {
      ruta = leerAjustes().ultimoRegistro;
      if (!ruta) throw new ErrorRegistro("no_existe", "No hay un último archivo.");
    } else {
      if (typeof archivo !== "string" || path.basename(archivo) !== archivo || !archivo.endsWith(".json")) {
        throw new ErrorRegistro("ilegible", "Nombre de archivo no válido.");
      }
      ruta = path.join(carpeta(), archivo);
    }
    if (sesion && sesion.ruta === ruta) return estado();

    const datos = leerArchivo(ruta);
    if (bloqueoAjeno(ruta)) {
      throw new ErrorRegistro("en_uso", "Otra instancia de KendoSTREAM está usando ese archivo.");
    }

    cerrarSesion();
    adquirirBloqueo(ruta);
    sesion = { ruta, archivo: path.basename(ruta), datos, pendientes: new Set(), error: null };
    guardarAjustes({ ultimoRegistro: ruta });
    alCambiar();
    return estado();
  }

  function detener() {
    const { pendientes } = cerrarSesion();
    alCambiar();
    return { pendientes };
  }

  // Lista los archivos de la carpeta con su estado (legible / en uso)
  function listarArchivos() {
    const dir = carpeta();
    let nombres;
    try {
      nombres = fs.readdirSync(dir);
    } catch (err) {
      return { carpeta: dir, existe: false, archivos: [] };
    }
    const archivos = [];
    for (const nombre of nombres) {
      if (!nombre.endsWith(".json")) continue;
      const ruta = path.join(dir, nombre);
      let modificado = 0;
      try { modificado = fs.statSync(ruta).mtimeMs; } catch (err) { continue; }
      const actual = !!(sesion && sesion.ruta === ruta);

      let datos = null;
      let parseado = true;
      try {
        datos = JSON.parse(fs.readFileSync(ruta, "utf8"));
      } catch (err) {
        parseado = false;
      }

      if (!parseado) {
        // solo se enseñan los ilegibles que parecen nuestros (AAAA-MM-DD_...)
        if (/^\d{4}-\d{2}-\d{2}_/.test(nombre)) {
          archivos.push({ archivo: nombre, ok: false, codigo: "ilegible", enUso: false, actual, modificado });
        }
        continue;
      }
      if (!datos || typeof datos !== "object" || typeof datos.esquema !== "number") continue; // otro tipo de JSON

      const valido = validarDatos(datos);
      const fila = { archivo: nombre, ok: valido.ok, enUso: !actual && bloqueoAjeno(ruta), actual, modificado };
      if (valido.ok) {
        fila.evento = recortar(datos.evento.nombre);
        fila.fecha = datos.evento.fecha || "";
        fila.combates = contarCombates(datos);
      } else {
        fila.codigo = valido.codigo;
      }
      archivos.push(fila);
    }
    archivos.sort((a, b) => b.modificado - a.modificado);
    return { carpeta: dir, existe: true, archivos };
  }

  // --- Guardar un combate finalizado ---
  // Nunca lanza: un fallo aquí no puede afectar al marcador.
  function guardarCombate(estadoMotor) {
    try {
      if (!sesion) return { guardado: false, motivo: "registro_apagado" };
      const combate = estadoMotor.combate;
      if (!combate || !combate.resultado) return { guardado: false, motivo: "sin_resultado" };

      const datos = sesion.datos;
      const categoria = categoriaParaRegistro(estadoMotor.categoria);
      const modalidad = categoriaParaRegistro(estadoMotor.modalidad);
      // ¿el combate es de un encuentro por equipos que sigue abierto?
      const deEncuentro = !!(combate.encuentro && estadoMotor.encuentro && estadoMotor.encuentro.id === combate.encuentro.id);
      const integrantes = deEncuentro ? estadoMotor.encuentro.integrantes : null;
      const clave = claveCompeticion(categoria, modalidad, integrantes);

      // ¿Ya estaba registrado este combate (Reabrir y volver a finalizar)?
      let previo = null;
      let competicionPrevia = null;
      for (const c of datos.competiciones) {
        const encontrado = c.combates.find((b) => b.id === combate.id);
        if (encontrado) {
          previo = encontrado;
          competicionPrevia = c;
          break;
        }
      }

      let competicion = datos.competiciones.find((c) => claveCompeticion(c.categoria, c.modalidad, c.integrantesEquipo) === clave);
      if (!competicion) {
        competicion = {
          id: crypto.randomUUID(),
          categoria,
          modalidad,
          integrantesEquipo: integrantes,
          podio: { primero: null, segundo: null, terceros: [], origen: null },
          combates: [],
          encuentros: []
        };
        datos.competiciones.push(competicion);
      }

      if (previo && competicionPrevia === competicion) {
        // mismo registro: se sobrescribe en su sitio, con su número y fecha
        const indice = competicion.combates.indexOf(previo);
        competicion.combates[indice] = combateParaRegistro(estadoMotor, { numero: previo.numero, fecha: previo.fecha });
      } else {
        if (previo) {
          // cambió de categoría/modalidad al reabrir: se mueve
          competicionPrevia.combates.splice(competicionPrevia.combates.indexOf(previo), 1);
          const vacia =
            competicionPrevia.combates.length === 0 &&
            competicionPrevia.encuentros.length === 0 &&
            !competicionPrevia.podio.primero &&
            !competicionPrevia.podio.segundo;
          if (vacia) datos.competiciones.splice(datos.competiciones.indexOf(competicionPrevia), 1);
        }
        const numero = competicion.combates.reduce((m, b) => Math.max(m, b.numero || 0), 0) + 1;
        const fecha = previo ? previo.fecha : fechaLocal();
        competicion.combates.push(combateParaRegistro(estadoMotor, { numero, fecha }));
      }

      // el encuentro (equipos, integrantes, resultado) se guarda y se actualiza con cada combate
      if (deEncuentro) {
        const registroEncuentro = encuentroParaRegistro(estadoMotor);
        const indice = competicion.encuentros.findIndex((x) => x.id === registroEncuentro.id);
        if (indice >= 0) competicion.encuentros[indice] = registroEncuentro;
        else competicion.encuentros.push(registroEncuentro);
      }

      sesion.pendientes.add(combate.id);
      const ok = intentarEscribir();
      alCambiar();
      return { guardado: ok };
    } catch (err) {
      console.error("Error registrando el combate:", err.message);
      return { guardado: false, motivo: "error", detalle: err.message };
    }
  }

  // Cierre del servidor (Ctrl+C, cierre de la terminal): deja todo escrito y libera el archivo
  function cerrar() {
    cerrarSesion();
  }

  return {
    ajustes,
    guardarCarpeta,
    probarCarpeta,
    estado,
    listarArchivos,
    nuevo,
    continuar,
    detener,
    guardarCombate,
    cerrar
  };
}

module.exports = {
  crearRegistro,
  ErrorRegistro,
  ESQUEMA,
  slug,
  fechaLocal,
  carpetaPorDefecto,
  resolverCarpeta,
  combateParaRegistro,
  validarDatos
};
